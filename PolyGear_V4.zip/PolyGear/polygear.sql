/* =========================================================
   CSDL PolyGear - Website ban phu kien dien thoai
   SQL Server
   ========================================================= */
IF DB_ID('polygear') IS NOT NULL
BEGIN
    ALTER DATABASE [polygear] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [polygear];
END
GO

CREATE DATABASE [polygear];
GO

USE [polygear];
GO

-- =========================================================
-- Bang danh muc phu kien (op lung, cap sac, tai nghe, ...)
-- =========================================================
CREATE TABLE dbo.categories (
    id     INT IDENTITY(1,1) PRIMARY KEY,
    name   NVARCHAR(250) NOT NULL,
    active BIT DEFAULT 1
);

-- =========================================================
-- Bang thuong hieu (Samsung, Apple, Baseus, Anker, ...)
-- =========================================================
CREATE TABLE dbo.brands (
    id     INT IDENTITY(1,1) PRIMARY KEY,
    name   NVARCHAR(250) NOT NULL,
    active BIT DEFAULT 1
);

-- =========================================================
-- Bang san pham (phu kien dien thoai)
-- quantity: so luong ton kho, tru dan khi co hoa don "finish"
-- =========================================================
CREATE TABLE dbo.products (
    id             INT IDENTITY(1,1) PRIMARY KEY,
    category_id    INT NULL,
    brand_id       INT NULL,
    name           NVARCHAR(250) NOT NULL,
    price          INT NULL,
    quantity       INT NOT NULL DEFAULT 0,
    image          NVARCHAR(250) NULL,
    description    NVARCHAR(MAX) NULL,
    active         BIT DEFAULT 1,
    discount_price INT NULL,               -- gia flash sale (NULL = khong giam gia)
    is_flash_sale  BIT NOT NULL DEFAULT 0,  -- co dang chay flash sale tren trang chu hay khong
    CONSTRAINT FK_products_categories FOREIGN KEY (category_id) REFERENCES dbo.categories(id),
    CONSTRAINT FK_products_brands FOREIGN KEY (brand_id) REFERENCES dbo.brands(id)
);

-- =========================================================
-- Bang tai khoan (Quan tri / Nhan vien / Khach hang)
-- role = 0: Khach hang, role = 1: Quan tri vien (toan quyen), role = 2: Nhan vien (quyen han che)
-- reset_token / reset_token_expiry: phuc vu chuc nang "Quen mat khau"
-- =========================================================
CREATE TABLE dbo.users (
    id                 INT IDENTITY(1,1) PRIMARY KEY,
    email              VARCHAR(100) UNIQUE NOT NULL,
    password           VARCHAR(255) NOT NULL,
    full_name          NVARCHAR(60) NULL,
    phone              VARCHAR(10) NULL,
    role               INT NOT NULL DEFAULT 0,
    active             BIT DEFAULT 1,
    reset_token        VARCHAR(100) NULL,
    reset_token_expiry BIGINT NULL
);

-- =========================================================
-- Bang the thanh vien / khach hang than thiet (neu dung)
-- =========================================================
CREATE TABLE dbo.cards (
    id     INT IDENTITY(1,1) PRIMARY KEY,
    code   INT NOT NULL,
    status BIT NULL
);

-- =========================================================
-- Bang hoa don (don hang cua khach hang)
-- status: waiting / finish / cancel
-- receiver_*: thong tin nguoi nhan hang, dung de in hoa don
-- =========================================================
-- status: waiting (Cho xac nhan) / preparing (Dang chuan bi) / shipping (Dang giao)
--         / delivered (Da giao) / cancel (Da huy)
CREATE TABLE dbo.bills (
    id               INT IDENTITY(1,1) PRIMARY KEY,
    user_id          INT NULL,
    card_id          INT NULL,
    code             VARCHAR(30) NOT NULL,
    created_at       DATETIME NULL,
    total            INT NULL,
    status           VARCHAR(20) NULL,
    receiver_name    NVARCHAR(60) NULL,
    receiver_phone   VARCHAR(10) NULL,
    receiver_address NVARCHAR(255) NULL,
    voucher_code     VARCHAR(30) NULL,
    discount_amount  INT NOT NULL DEFAULT 0,
    shipping_method  NVARCHAR(100) NULL,
    shipping_fee     INT NOT NULL DEFAULT 0,
    CONSTRAINT FK_bills_users FOREIGN KEY (user_id) REFERENCES dbo.users(id),
    CONSTRAINT FK_bills_cards FOREIGN KEY (card_id) REFERENCES dbo.cards(id)
);

-- =========================================================
-- Bang chi tiet hoa don
-- =========================================================
CREATE TABLE dbo.bill_details (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    bill_id    INT NULL,
    product_id INT NULL,
    quantity   INT NULL,
    price      INT NULL,
    CONSTRAINT FK_billdetails_bills FOREIGN KEY (bill_id) REFERENCES dbo.bills(id),
    CONSTRAINT FK_billdetails_products FOREIGN KEY (product_id) REFERENCES dbo.products(id)
);

-- =========================================================
-- Bang danh sach yeu thich (wishlist) cua khach hang
-- =========================================================
CREATE TABLE dbo.wishlists (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    user_id    INT NOT NULL,
    product_id INT NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_wishlists_users FOREIGN KEY (user_id) REFERENCES dbo.users(id),
    CONSTRAINT FK_wishlists_products FOREIGN KEY (product_id) REFERENCES dbo.products(id),
    CONSTRAINT UQ_wishlist_user_product UNIQUE (user_id, product_id)
);

-- =========================================================
-- Bang danh gia / binh luan san pham
-- =========================================================
CREATE TABLE dbo.reviews (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    product_id INT NOT NULL,
    user_id    INT NOT NULL,
    rating     INT NOT NULL,
    comment    NVARCHAR(1000) NULL,
    created_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_reviews_products FOREIGN KEY (product_id) REFERENCES dbo.products(id),
    CONSTRAINT FK_reviews_users FOREIGN KEY (user_id) REFERENCES dbo.users(id),
    CONSTRAINT CK_reviews_rating CHECK (rating BETWEEN 1 AND 5)
);

-- =========================================================
-- Bang ma giam gia (voucher / coupon)
-- discount_percent hoac discount_amount (dung mot trong hai)
-- =========================================================
CREATE TABLE dbo.vouchers (
    id               INT IDENTITY(1,1) PRIMARY KEY,
    code             VARCHAR(30) UNIQUE NOT NULL,
    description      NVARCHAR(250) NULL,
    discount_percent INT NULL,
    discount_amount  INT NULL,
    min_order_value  INT NOT NULL DEFAULT 0,
    max_discount     INT NULL,
    quantity         INT NOT NULL DEFAULT 0,
    used_count       INT NOT NULL DEFAULT 0,
    start_date       DATETIME NULL,
    end_date         DATETIME NULL,
    active           BIT NOT NULL DEFAULT 1
);
GO

-- =========================================================
-- Du lieu mau: thuong hieu
-- =========================================================
SET IDENTITY_INSERT dbo.brands ON;
INSERT INTO dbo.brands (id, name, active) VALUES
 (1, N'Samsung', 1),
 (2, N'Apple', 1),
 (3, N'Baseus', 1),
 (4, N'Anker', 1),
 (5, N'Ugreen', 1);
SET IDENTITY_INSERT dbo.brands OFF;
GO

-- =========================================================
-- Du lieu mau: danh muc phu kien
-- =========================================================
SET IDENTITY_INSERT dbo.categories ON;
INSERT INTO dbo.categories (id, name, active) VALUES
 (1, N'Ốp lưng điện thoại', 1),
 (2, N'Cáp sạc', 1),
 (3, N'Sạc dự phòng', 1),
 (4, N'Tai nghe', 1),
 (5, N'Kính cường lực', 1),
 (6, N'Giá đỡ điện thoại', 1);
SET IDENTITY_INSERT dbo.categories OFF;
GO

-- =========================================================
-- Du lieu mau: san pham
-- =========================================================
SET IDENTITY_INSERT dbo.products ON;
INSERT INTO dbo.products (id, category_id, brand_id, name, price, quantity, image, description, active) VALUES
 (1, 1, 2, N'Ốp lưng silicon chống sốc iPhone 15', 89000,  50, NULL, N'Chất liệu silicon mềm, chống va đập tốt', 1),
 (2, 1, 1, N'Ốp lưng trong suốt Samsung Galaxy S24', 69000, 40, NULL, N'Trong suốt, giữ nguyên vẻ đẹp máy', 1),
 (3, 2, 3, N'Cáp sạc nhanh USB-C to USB-C 100W', 149000, 60, NULL, N'Hỗ trợ sạc nhanh, dài 1m', 1),
 (4, 2, 2, N'Cáp Lightning MFi chính hãng', 199000, 35, NULL, N'Chuẩn MFi, bền bỉ, dài 1m', 1),
 (5, 3, 4, N'Sạc dự phòng 10000mAh', 350000, 25, NULL, N'Nhỏ gọn, sạc nhanh 2 chiều', 1),
 (6, 4, 3, N'Tai nghe Bluetooth TWS', 450000, 20, NULL, N'Chống ồn, pin 24h', 1),
 (7, 5, 5, N'Kính cường lực chống trầy 9H', 45000, 100, NULL, N'Độ cứng 9H, chống trầy xước', 1),
 (8, 6, 4, N'Giá đỡ điện thoại để bàn', 79000, 30, NULL, N'Gấp gọn, để bàn hoặc xe hơi', 1);
SET IDENTITY_INSERT dbo.products OFF;
GO

-- Danh dau vai san pham dang chay Flash Sale tren trang chu (demo)
UPDATE dbo.products SET discount_price = 65000, is_flash_sale = 1 WHERE id = 1;
UPDATE dbo.products SET discount_price = 299000, is_flash_sale = 1 WHERE id = 5;
UPDATE dbo.products SET discount_price = 35000, is_flash_sale = 1 WHERE id = 7;
GO

-- =========================================================
-- Du lieu mau: ma giam gia (voucher)
-- =========================================================
INSERT INTO dbo.vouchers (code, description, discount_percent, discount_amount, min_order_value, max_discount, quantity, used_count, start_date, end_date, active) VALUES
 ('WELCOME10', N'Giảm 10% cho đơn hàng đầu tiên', 10, NULL, 100000, 50000, 100, 0, NULL, NULL, 1),
 ('FREESHIP', N'Giảm thẳng 20.000đ cho mọi đơn hàng', NULL, 20000, 0, NULL, 200, 0, NULL, NULL, 1),
 ('SALE50K', N'Giảm 50.000đ cho đơn từ 500.000đ', NULL, 50000, 500000, NULL, 50, 0, NULL, NULL, 1);
GO

-- =========================================================
-- Du lieu mau: tai khoan
-- Mat khau demo (chua ma hoa) - can hash lai khi trien khai that
-- =========================================================
SET IDENTITY_INSERT dbo.users ON;
INSERT INTO dbo.users (id, email, password, full_name, phone, role, active) VALUES
 (1, N'admin@gmail.com', N'123456', N'Quản trị viên', N'0901231234', 1, 1),
 (2, N'khachhang@gmail.com', N'123456', N'Nguyễn Văn Tèo', N'0907828123', 0, 1),
 (3, N'nhanvien@gmail.com', N'123456', N'Trần Thị Nhân Viên', N'0909998888', 2, 1);
SET IDENTITY_INSERT dbo.users OFF;
GO

-- =========================================================
-- Thu tuc thong ke: Top 5 san pham ban chay (tuy chon khoang thoi gian)
-- =========================================================
CREATE PROCEDURE sp_top_5_best_selling_products
    @from_date DATE = NULL,
    @to_date   DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP 5
           p.id   AS product_id,
           p.name AS product_name,
           SUM(bd.quantity) AS total_quantity_sold,
           SUM(bd.quantity * bd.price) AS total_revenue
    FROM bill_details bd
    INNER JOIN products p ON bd.product_id = p.id
    INNER JOIN bills b ON bd.bill_id = b.id
    WHERE b.status = 'delivered'
      AND (@from_date IS NULL OR b.created_at >= @from_date)
      AND (@to_date   IS NULL OR b.created_at <= @to_date)
    GROUP BY p.id, p.name
    ORDER BY total_quantity_sold DESC;
END
GO

-- =========================================================
-- Thu tuc thong ke: Doanh thu theo ngay (tuy chon khoang thoi gian)
-- =========================================================
CREATE PROCEDURE sp_revenue_by_day
    @from_date DATE,
    @to_date   DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        CAST(created_at AS DATE) AS revenue_date,
        COUNT(id)                AS total_bills,
        SUM(total)                AS total_revenue
    FROM bills
    WHERE status = 'delivered'
      AND created_at BETWEEN @from_date AND @to_date
    GROUP BY CAST(created_at AS DATE)
    ORDER BY revenue_date;
END
GO
