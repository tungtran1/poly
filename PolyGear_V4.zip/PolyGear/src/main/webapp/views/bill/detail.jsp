<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Hóa đơn ${bill.code}" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<style>
@media print {
	header, nav, footer, .no-print { display: none !important; }
}
</style>

<div class="d-flex justify-content-between align-items-center mb-3 no-print">
	<a href="${pageContext.request.contextPath}/don-hang" class="btn btn-outline-secondary">&laquo; Danh sách đơn hàng</a>
	<div>
		<c:if test="${bill.status == 'waiting' || bill.status == 'preparing'}">
			<form action="${pageContext.request.contextPath}/hoa-don" method="post" class="d-inline">
				<input type="hidden" name="id" value="${bill.id}">
				<input type="hidden" name="action" value="cancel">
				<button type="submit" class="btn btn-outline-danger" onclick="return confirm('Bạn chắc chắn muốn hủy đơn hàng này?');">
					<i class="fa fa-times"></i> Hủy đơn hàng
				</button>
			</form>
		</c:if>
		<button class="btn btn-primary" onclick="window.print();"><i class="fa fa-print"></i> In hóa đơn</button>
	</div>
</div>

<c:if test="${param.cancelSuccess == 'true'}">
	<div class="alert alert-success no-print">Đơn hàng đã được hủy thành công.</div>
</c:if>
<c:if test="${param.cancelError == 'true'}">
	<div class="alert alert-danger no-print">Đơn hàng đang được giao hoặc đã hoàn tất nên không thể tự hủy. Vui lòng liên hệ cửa hàng để được hỗ trợ.</div>
</c:if>

<div class="card p-4">
	<div class="text-center mb-4">
		<h3 class="fw-bold">HÓA ĐƠN BÁN HÀNG</h3>
		<p class="text-muted mb-0">PolyGear - Cửa hàng phụ kiện điện thoại</p>
	</div>

	<div class="row mb-4">
		<div class="col-md-6">
			<p class="mb-1"><strong>Mã hóa đơn:</strong> ${bill.code}</p>
			<p class="mb-1"><strong>Ngày lập:</strong> <fmt:formatDate value="${bill.createdAt}" pattern="dd/MM/yyyy HH:mm"/></p>
			<p class="mb-1">
				<strong>Trạng thái:</strong>
				<jsp:include page="/views/common/status-badge.jsp"><jsp:param name="status" value="${bill.status}"/></jsp:include>
			</p>
			<c:if test="${not empty bill.voucherCode}">
				<p class="mb-1"><strong>Mã giảm giá:</strong> ${bill.voucherCode} (-<fmt:formatNumber value="${bill.discountAmount}" pattern="#,###"/> đ)</p>
			</c:if>
		</div>
		<div class="col-md-6">
			<p class="mb-1"><strong>Người nhận:</strong> ${bill.receiverName}</p>
			<p class="mb-1"><strong>Điện thoại:</strong> ${bill.receiverPhone}</p>
			<p class="mb-1"><strong>Địa chỉ:</strong> ${bill.receiverAddress}</p>
			<p class="mb-1"><strong>Vận chuyển:</strong> ${bill.shippingMethod}</p>
		</div>
	</div>

	<c:if test="${bill.status != 'cancel'}">
		<div class="mb-4 no-print">
			<ul class="list-group list-group-horizontal text-center small">
				<li class="list-group-item flex-fill ${bill.status == 'waiting' || bill.status == 'preparing' || bill.status == 'shipping' || bill.status == 'delivered' ? 'bg-primary text-white' : ''}">1. Chờ xác nhận</li>
				<li class="list-group-item flex-fill ${bill.status == 'preparing' || bill.status == 'shipping' || bill.status == 'delivered' ? 'bg-primary text-white' : ''}">2. Đang chuẩn bị</li>
				<li class="list-group-item flex-fill ${bill.status == 'shipping' || bill.status == 'delivered' ? 'bg-primary text-white' : ''}">3. Đang giao</li>
				<li class="list-group-item flex-fill ${bill.status == 'delivered' ? 'bg-primary text-white' : ''}">4. Đã giao</li>
			</ul>
		</div>
	</c:if>

	<table class="table table-bordered">
		<thead class="table-light">
			<tr>
				<th>#</th>
				<th>Phụ kiện</th>
				<th class="text-end">Đơn giá</th>
				<th class="text-center">Số lượng</th>
				<th class="text-end">Thành tiền</th>
			</tr>
		</thead>
		<tbody>
			<c:forEach items="${details}" var="d" varStatus="st">
				<tr>
					<td>${st.index + 1}</td>
					<td>${productMap[d.productId].name}</td>
					<td class="text-end"><fmt:formatNumber value="${d.price}" pattern="#,###"/> đ</td>
					<td class="text-center">${d.quantity}</td>
					<td class="text-end"><fmt:formatNumber value="${d.price * d.quantity}" pattern="#,###"/> đ</td>
				</tr>
			</c:forEach>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="4" class="text-end">Tạm tính</th>
				<th class="text-end"><fmt:formatNumber value="${bill.total - bill.shippingFee + bill.discountAmount}" pattern="#,###"/> đ</th>
			</tr>
			<c:if test="${not empty bill.voucherCode}">
				<tr>
					<th colspan="4" class="text-end">Giảm giá (${bill.voucherCode})</th>
					<th class="text-end text-success">-<fmt:formatNumber value="${bill.discountAmount}" pattern="#,###"/> đ</th>
				</tr>
			</c:if>
			<tr>
				<th colspan="4" class="text-end">Phí vận chuyển</th>
				<th class="text-end">
					<c:choose>
						<c:when test="${bill.shippingFee == 0}">Miễn phí</c:when>
						<c:otherwise><fmt:formatNumber value="${bill.shippingFee}" pattern="#,###"/> đ</c:otherwise>
					</c:choose>
				</th>
			</tr>
			<tr>
				<th colspan="4" class="text-end">Tổng cộng</th>
				<th class="text-end text-danger"><fmt:formatNumber value="${bill.total}" pattern="#,###"/> đ</th>
			</tr>
		</tfoot>
	</table>

	<p class="text-center text-muted mt-4 mb-0">Cảm ơn quý khách đã mua sắm tại PolyGear!</p>
</div>

<jsp:include page="/views/common/footer.jsp"/>
