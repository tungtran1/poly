<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Đơn hàng của tôi" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4"><i class="fa fa-list-alt"></i> Đơn hàng của tôi</h4>

<c:choose>
<c:when test="${empty bills}">
	<div class="alert alert-info">Bạn chưa có đơn hàng nào. <a href="${pageContext.request.contextPath}/san-pham">Mua sắm ngay &raquo;</a></div>
</c:when>
<c:otherwise>
	<div class="table-responsive">
		<table class="table align-middle">
			<thead>
				<tr>
					<th>Mã đơn</th>
					<th>Ngày đặt</th>
					<th class="text-end">Tổng tiền</th>
					<th class="text-center">Trạng thái</th>
					<th class="text-end">Hóa đơn</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${bills}" var="bill">
					<tr>
						<td>${bill.code}</td>
						<td><fmt:formatDate value="${bill.createdAt}" pattern="dd/MM/yyyy HH:mm"/></td>
						<td class="text-end fw-bold text-danger"><fmt:formatNumber value="${bill.total}" pattern="#,###"/> đ</td>
						<td class="text-center">
							<jsp:include page="/views/common/status-badge.jsp"><jsp:param name="status" value="${bill.status}"/></jsp:include>
						</td>
						<td class="text-end">
							<a href="${pageContext.request.contextPath}/hoa-don?id=${bill.id}" class="btn btn-sm btn-outline-primary"><i class="fa fa-file-text-o"></i> Xem hóa đơn</a>
							<c:if test="${bill.status == 'waiting' || bill.status == 'preparing'}">
								<form action="${pageContext.request.contextPath}/hoa-don" method="post" class="d-inline">
									<input type="hidden" name="id" value="${bill.id}">
									<input type="hidden" name="action" value="cancel">
									<button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn chắc chắn muốn hủy đơn hàng này?');"><i class="fa fa-times"></i> Hủy</button>
								</form>
							</c:if>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>
	</div>
</c:otherwise>
</c:choose>

<jsp:include page="/views/common/footer.jsp"/>
