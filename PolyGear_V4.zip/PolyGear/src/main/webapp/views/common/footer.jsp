		</main>
		<footer class="text-center text-muted py-4 mt-5 border-top">
			<p class="mb-0">&copy; 2026 PolyGear - Website bán phụ kiện điện thoại. Đồ án môn học FPT Polytechnic.</p>
		</footer>
	</div>
</body>
</html>
