<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%
	int cartCount = com.polygear.servlet.CartServlet.getCartCount(request);
	pageContext.setAttribute("cartCount", cartCount);
%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><c:if test="${not empty pageTitle}">${pageTitle} - </c:if>PolyGear</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
<link href="${pageContext.request.contextPath}/css/style.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container">
		<header class="pt-3">
			<a href="${pageContext.request.contextPath}/trang-chu">
				<img alt="PolyGear" src="${pageContext.request.contextPath}/images/logo.png" width="150" onerror="this.style.display='none'">
			</a>
			<hr>
		</header>

		<nav class="navbar navbar-expand-lg bg-body-tertiary rounded mb-4">
			<div class="container-fluid">
				<a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/trang-chu">PolyGear</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
					aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">
							<a class="nav-link" href="${pageContext.request.contextPath}/trang-chu">Trang chủ</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="${pageContext.request.contextPath}/san-pham">Phụ kiện</a>
						</li>
						<c:if test="${sessionScope.user != null}">
							<li class="nav-item">
								<a class="nav-link" href="${pageContext.request.contextPath}/don-hang">Đơn hàng của tôi</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="${pageContext.request.contextPath}/yeu-thich">Yêu thích</a>
							</li>
						</c:if>
						<c:if test="${sessionScope.user != null && sessionScope.user.manager}">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Quản trị</a>
								<ul class="dropdown-menu">
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/bills">Quản lý hóa đơn</a></li>
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/customers">Quản lý khách hàng</a></li>
									<c:if test="${sessionScope.user.admin}">
										<li><hr class="dropdown-divider"></li>
										<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/dashboard">Dashboard tổng quan</a></li>
										<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/products">Quản lý phụ kiện</a></li>
										<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/categories">Quản lý loại phụ kiện</a></li>
										<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/brands">Quản lý thương hiệu</a></li>
										<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/vouchers">Quản lý mã giảm giá</a></li>
										<li><a class="dropdown-item" href="${pageContext.request.contextPath}/manager/staff">Quản lý nhân viên</a></li>
									</c:if>
								</ul>
							</li>
						</c:if>
					</ul>
					<form class="d-flex me-3" action="${pageContext.request.contextPath}/san-pham" method="get" role="search">
						<input class="form-control me-2" type="search" name="keyword" placeholder="Tìm phụ kiện..." value="${keyword}">
						<button class="btn btn-outline-primary" type="submit"><i class="fa fa-search"></i></button>
					</form>
					<ul class="navbar-nav mb-2 mb-lg-0 align-items-lg-center">
						<li class="nav-item me-2">
							<a class="nav-link position-relative" href="${pageContext.request.contextPath}/gio-hang">
								<i class="fa fa-shopping-cart fa-lg"></i> Giỏ hàng
								<c:if test="${cartCount > 0}">
									<span class="badge rounded-pill bg-danger">${cartCount}</span>
								</c:if>
							</a>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
								<i class="fa fa-user-circle"></i> ${sessionScope.user != null ? sessionScope.user.fullName : "Tài khoản"}
							</a>
							<ul class="dropdown-menu dropdown-menu-end">
								<c:if test="${sessionScope.user == null}">
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/dang-nhap">Đăng nhập</a></li>
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/dang-ky">Đăng ký</a></li>
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/quen-mat-khau">Quên mật khẩu</a></li>
								</c:if>
								<c:if test="${sessionScope.user != null}">
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/edit-profile">Thông tin cá nhân</a></li>
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/change-pass">Đổi mật khẩu</a></li>
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/don-hang">Đơn hàng của tôi</a></li>
									<li><hr class="dropdown-divider"></li>
									<li><a class="dropdown-item" href="${pageContext.request.contextPath}/logout">Đăng xuất</a></li>
								</c:if>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<main>
