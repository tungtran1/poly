<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:choose>
	<c:when test="${param.status == 'waiting'}"><span class="badge bg-warning text-dark">Chờ xác nhận</span></c:when>
	<c:when test="${param.status == 'preparing'}"><span class="badge bg-info text-dark">Đang chuẩn bị</span></c:when>
	<c:when test="${param.status == 'shipping'}"><span class="badge bg-primary">Đang giao</span></c:when>
	<c:when test="${param.status == 'delivered'}"><span class="badge bg-success">Đã giao</span></c:when>
	<c:when test="${param.status == 'cancel'}"><span class="badge bg-danger">Đã hủy</span></c:when>
	<c:otherwise><span class="badge bg-secondary">${param.status}</span></c:otherwise>
</c:choose>
