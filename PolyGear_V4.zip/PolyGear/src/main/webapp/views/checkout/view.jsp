<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Thanh toán" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4"><i class="fa fa-credit-card"></i> Thanh toán đơn hàng</h4>

<c:if test="${not empty error}">
	<div class="alert alert-danger">${error}</div>
</c:if>

<div class="row g-4">
	<div class="col-md-7">
		<div class="card">
			<div class="card-header fw-bold">Thông tin nhận hàng</div>
			<div class="card-body">
				<form action="${pageContext.request.contextPath}/thanh-toan" method="post" id="checkoutForm">
					<div class="mb-3">
						<label class="form-label">Họ và tên người nhận <span class="text-danger">*</span></label>
						<input type="text" class="form-control" name="receiverName" value="${sessionScope.user.fullName}" required maxlength="60">
					</div>
					<div class="mb-3">
						<label class="form-label">Số điện thoại <span class="text-danger">*</span></label>
						<input type="text" class="form-control" name="receiverPhone" value="${sessionScope.user.phone}" required maxlength="10">
					</div>
					<div class="mb-3">
						<label class="form-label">Địa chỉ nhận hàng <span class="text-danger">*</span></label>
						<textarea class="form-control" name="receiverAddress" rows="3" required></textarea>
					</div>

					<div class="mb-3">
						<label class="form-label fw-bold">Phương thức giao hàng <span class="text-danger">*</span></label>
						<c:forEach items="${shippingMethods}" var="entry">
							<div class="form-check border rounded p-2 mb-2">
								<input class="form-check-input shipping-option" type="radio" name="shippingMethod" id="ship_${entry.key}"
									value="${entry.key}" data-fee="${entry.value[1]}"
									${entry.key == selectedShippingMethod ? 'checked' : ''} required>
								<label class="form-check-label w-100 d-flex justify-content-between" for="ship_${entry.key}">
									<span>${entry.value[0]}</span>
									<span class="fw-bold">
										<c:choose>
											<c:when test="${entry.value[1] == 0}">Miễn phí</c:when>
											<c:otherwise><fmt:formatNumber value="${entry.value[1]}" pattern="#,###"/> đ</c:otherwise>
										</c:choose>
									</span>
								</label>
							</div>
						</c:forEach>
					</div>

					<div class="mb-3">
						<label class="form-label">Phương thức thanh toán</label>
						<input type="text" class="form-control" value="Thanh toán khi nhận hàng (COD)" disabled>
					</div>
					<button type="submit" class="btn btn-primary btn-lg w-100">Đặt hàng</button>
				</form>
			</div>
		</div>
	</div>
	<div class="col-md-5">
		<div class="card">
			<div class="card-header fw-bold">Đơn hàng của bạn</div>
			<ul class="list-group list-group-flush">
				<c:forEach items="${cartItems}" var="item">
					<li class="list-group-item d-flex justify-content-between align-items-center">
						<span>${item.name} <span class="text-muted">x${item.quantity}</span></span>
						<span class="fw-bold"><fmt:formatNumber value="${item.subtotal}" pattern="#,###"/> đ</span>
					</li>
				</c:forEach>
				<li class="list-group-item d-flex justify-content-between align-items-center">
					<span>Tạm tính</span>
					<span id="subtotalDisplay"><fmt:formatNumber value="${cartTotal}" pattern="#,###"/> đ</span>
				</li>
				<c:if test="${not empty appliedVoucher}">
					<li class="list-group-item d-flex justify-content-between align-items-center text-success">
						<span>Mã <strong>${appliedVoucher.code}</strong></span>
						<span>-<fmt:formatNumber value="${discountAmount}" pattern="#,###"/> đ</span>
					</li>
				</c:if>
				<li class="list-group-item d-flex justify-content-between align-items-center">
					<span>Phí vận chuyển</span>
					<span id="shippingFeeDisplay"><fmt:formatNumber value="${shippingFee}" pattern="#,###"/> đ</span>
				</li>
				<li class="list-group-item d-flex justify-content-between align-items-center bg-light">
					<span class="fw-bold">Tổng cộng</span>
					<span class="fw-bold text-danger fs-5" id="finalTotalDisplay"><fmt:formatNumber value="${finalTotal}" pattern="#,###"/> đ</span>
				</li>
			</ul>
		</div>
	</div>
</div>

<script>
(function() {
	var subtotal = ${cartTotal};
	var discount = ${empty discountAmount ? 0 : discountAmount};
	var radios = document.querySelectorAll('.shipping-option');
	function formatVnd(n) {
		return n.toLocaleString('vi-VN') + ' đ';
	}
	function recalc() {
		var fee = 0;
		radios.forEach(function(r) { if (r.checked) fee = parseInt(r.getAttribute('data-fee'), 10); });
		document.getElementById('shippingFeeDisplay').textContent = formatVnd(fee);
		document.getElementById('finalTotalDisplay').textContent = formatVnd(subtotal - discount + fee);
	}
	radios.forEach(function(r) { r.addEventListener('change', recalc); });
})();
</script>

<jsp:include page="/views/common/footer.jsp"/>
