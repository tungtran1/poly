<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Quản lý thương hiệu" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4"><i class="fa fa-trademark"></i> Quản lý thương hiệu</h4>

<c:if test="${not empty message}"><div class="alert alert-success">${message}</div></c:if>
<c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>

<div class="row g-4">
	<div class="col-md-4">
		<div class="card p-3">
			<h6>${not empty brand ? 'Cập nhật thương hiệu' : 'Thêm thương hiệu mới'}</h6>
			<form action="${pageContext.request.contextPath}/manager/brands/${not empty brand ? 'edit' : 'add'}" method="post">
				<c:if test="${not empty brand}">
					<input type="hidden" name="id" value="${brand.id}">
				</c:if>
				<div class="mb-3">
					<label class="form-label">Tên thương hiệu</label>
					<input type="text" class="form-control" name="name" value="${brand.name}" placeholder="VD: Samsung, Apple, Baseus, Anker..." required>
				</div>
				<button type="submit" class="btn btn-primary w-100">${not empty brand ? 'Cập nhật' : 'Thêm mới'}</button>
				<c:if test="${not empty brand}">
					<a href="${pageContext.request.contextPath}/manager/brands" class="btn btn-outline-secondary w-100 mt-2">Hủy</a>
				</c:if>
			</form>
		</div>
	</div>
	<div class="col-md-8">
		<table class="table align-middle">
			<thead>
				<tr>
					<th>#</th>
					<th>Tên thương hiệu</th>
					<th class="text-center">Trạng thái</th>
					<th class="text-end">Thao tác</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${list}" var="b" varStatus="st">
					<tr>
						<td>${st.index + 1}</td>
						<td>${b.name}</td>
						<td class="text-center">
							<c:choose>
								<c:when test="${b.active}"><span class="badge bg-success">Đang hoạt động</span></c:when>
								<c:otherwise><span class="badge bg-secondary">Đã ẩn</span></c:otherwise>
							</c:choose>
						</td>
						<td class="text-end">
							<a href="${pageContext.request.contextPath}/manager/brands?id=${b.id}" class="btn btn-sm btn-outline-primary"><i class="fa fa-edit"></i></a>
							<form action="${pageContext.request.contextPath}/manager/brands/delete" method="post" class="d-inline">
								<input type="hidden" name="id" value="${b.id}">
								<button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa/ẩn thương hiệu này?');"><i class="fa fa-trash"></i></button>
							</form>
						</td>
					</tr>
				</c:forEach>
				<c:if test="${empty list}">
					<tr><td colspan="4" class="text-center text-muted">Chưa có thương hiệu nào.</td></tr>
				</c:if>
			</tbody>
		</table>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
