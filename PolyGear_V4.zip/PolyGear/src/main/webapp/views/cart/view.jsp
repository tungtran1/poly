<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Giỏ hàng" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4"><i class="fa fa-shopping-cart"></i> Giỏ hàng của bạn</h4>

<c:choose>
<c:when test="${empty cartItems}">
	<div class="alert alert-info">
		Giỏ hàng của bạn đang trống. <a href="${pageContext.request.contextPath}/san-pham">Tiếp tục mua sắm &raquo;</a>
	</div>
</c:when>
<c:otherwise>
	<div class="table-responsive">
		<table class="table align-middle">
			<thead>
				<tr>
					<th>Phụ kiện</th>
					<th class="text-end">Đơn giá</th>
					<th class="text-center" style="width:160px;">Số lượng</th>
					<th class="text-end">Thành tiền</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${cartItems}" var="item">
					<tr>
						<td>
							<div class="d-flex align-items-center gap-2">
								<img src="${pageContext.request.contextPath}/uploads/${item.image}" style="width:56px;height:56px;object-fit:cover;" class="rounded border" alt="${item.name}" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'">
								<span>${item.name}</span>
							</div>
						</td>
						<td class="text-end"><fmt:formatNumber value="${item.price}" pattern="#,###"/> đ</td>
						<td>
							<form action="${pageContext.request.contextPath}/gio-hang" method="post" class="d-flex justify-content-center gap-1">
								<input type="hidden" name="action" value="update">
								<input type="hidden" name="productId" value="${item.productId}">
								<input type="number" name="quantity" value="${item.quantity}" min="1" max="99" class="form-control form-control-sm" style="width:70px;">
								<button type="submit" class="btn btn-sm btn-outline-secondary"><i class="fa fa-refresh"></i></button>
							</form>
						</td>
						<td class="text-end fw-bold text-danger"><fmt:formatNumber value="${item.subtotal}" pattern="#,###"/> đ</td>
						<td class="text-end">
							<form action="${pageContext.request.contextPath}/gio-hang" method="post">
								<input type="hidden" name="action" value="remove">
								<input type="hidden" name="productId" value="${item.productId}">
								<button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Xóa sản phẩm này khỏi giỏ hàng?');"><i class="fa fa-trash"></i></button>
							</form>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>
	</div>

	<div class="row mt-4">
		<div class="col-md-6">
			<a href="${pageContext.request.contextPath}/san-pham" class="btn btn-outline-secondary">&laquo; Tiếp tục mua sắm</a>

			<div class="card mt-3" style="max-width:420px;">
				<div class="card-body">
					<h6 class="card-title">Mã giảm giá</h6>
					<c:if test="${not empty voucherError}">
						<div class="alert alert-warning py-2 small">${voucherError}</div>
					</c:if>
					<c:choose>
						<c:when test="${not empty appliedVoucher}">
							<div class="d-flex justify-content-between align-items-center">
								<span class="badge bg-success">${appliedVoucher.code}</span>
								<form action="${pageContext.request.contextPath}/gio-hang" method="post">
									<input type="hidden" name="action" value="remove-voucher">
									<button type="submit" class="btn btn-sm btn-link text-danger p-0">Hủy mã</button>
								</form>
							</div>
							<small class="text-muted">${appliedVoucher.description}</small>
						</c:when>
						<c:otherwise>
							<form action="${pageContext.request.contextPath}/gio-hang" method="post" class="d-flex gap-2">
								<input type="hidden" name="action" value="apply-voucher">
								<input type="text" name="voucherCode" class="form-control form-control-sm" placeholder="Nhập mã giảm giá">
								<button type="submit" class="btn btn-sm btn-outline-primary text-nowrap">Áp dụng</button>
							</form>
						</c:otherwise>
					</c:choose>
				</div>
			</div>
		</div>
		<div class="col-md-6 text-end">
			<p class="mb-1">Tạm tính: <fmt:formatNumber value="${cartTotal}" pattern="#,###"/> đ</p>
			<c:if test="${not empty appliedVoucher}">
				<p class="mb-1 text-success">Giảm giá: -<fmt:formatNumber value="${discountAmount}" pattern="#,###"/> đ</p>
			</c:if>
			<h5>Tổng cộng: <span class="text-danger fw-bold"><fmt:formatNumber value="${not empty appliedVoucher ? finalTotal : cartTotal}" pattern="#,###"/> đ</span></h5>
			<p class="small text-muted mb-2">(Chưa gồm phí vận chuyển - sẽ chọn ở bước thanh toán)</p>
			<a href="${pageContext.request.contextPath}/thanh-toan" class="btn btn-primary btn-lg">Tiến hành thanh toán <i class="fa fa-arrow-right"></i></a>
		</div>
	</div>
</c:otherwise>
</c:choose>

<jsp:include page="/views/common/footer.jsp"/>
