<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="${not empty voucher.id ? 'Sửa mã giảm giá' : 'Thêm mã giảm giá'}" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4">${not empty voucher.id ? 'Sửa mã giảm giá' : 'Thêm mã giảm giá mới'}</h4>

<div class="card" style="max-width:600px;">
	<div class="card-body">
		<form action="${pageContext.request.contextPath}/manager/vouchers/${not empty voucher.id ? 'edit' : 'add'}" method="post">
			<c:if test="${not empty voucher.id}">
				<input type="hidden" name="id" value="${voucher.id}">
			</c:if>
			<div class="mb-3">
				<label class="form-label">Mã giảm giá <span class="text-danger">*</span></label>
				<input type="text" class="form-control ${not empty errCode ? 'is-invalid' : ''}" name="code" value="${voucher.code}" maxlength="30" style="text-transform:uppercase;">
				<c:if test="${not empty errCode}"><div class="invalid-feedback">${errCode}</div></c:if>
			</div>
			<div class="mb-3">
				<label class="form-label">Mô tả</label>
				<input type="text" class="form-control" name="description" value="${voucher.description}" maxlength="250">
			</div>
			<div class="row mb-3">
				<div class="col-6">
					<label class="form-label">Loại giảm giá</label>
					<select class="form-select" name="discountType">
						<option value="percent" ${empty voucher.discountAmount ? 'selected' : ''}>Theo phần trăm (%)</option>
						<option value="amount" ${not empty voucher.discountAmount ? 'selected' : ''}>Số tiền cố định (đ)</option>
					</select>
				</div>
				<div class="col-6">
					<label class="form-label">Giá trị giảm <span class="text-danger">*</span></label>
					<input type="number" min="1" class="form-control ${not empty errValue ? 'is-invalid' : ''}" name="discountValue"
						value="${not empty voucher.discountPercent ? voucher.discountPercent : voucher.discountAmount}">
					<c:if test="${not empty errValue}"><div class="invalid-feedback">${errValue}</div></c:if>
				</div>
			</div>
			<div class="row mb-3">
				<div class="col-6">
					<label class="form-label">Đơn hàng tối thiểu (đ)</label>
					<input type="number" min="0" class="form-control" name="minOrderValue" value="${voucher.minOrderValue}">
				</div>
				<div class="col-6">
					<label class="form-label">Giảm tối đa (đ, nếu theo %)</label>
					<input type="number" min="0" class="form-control" name="maxDiscount" value="${voucher.maxDiscount}">
				</div>
			</div>
			<div class="mb-3">
				<label class="form-label">Số lượng mã phát hành</label>
				<input type="number" min="0" class="form-control" name="quantity" value="${voucher.quantity}">
			</div>
			<div class="mb-3">
				<label class="form-label">Trạng thái</label>
				<select class="form-select" name="active">
					<option value="1" ${voucher.active || empty voucher.id ? 'selected' : ''}>Đang hoạt động</option>
					<option value="0" ${not empty voucher.id && !voucher.active ? 'selected' : ''}>Ngừng hoạt động</option>
				</select>
			</div>
			<div class="d-flex gap-2">
				<button type="submit" class="btn btn-primary">Lưu</button>
				<a href="${pageContext.request.contextPath}/manager/vouchers" class="btn btn-outline-secondary">Hủy</a>
			</div>
		</form>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
