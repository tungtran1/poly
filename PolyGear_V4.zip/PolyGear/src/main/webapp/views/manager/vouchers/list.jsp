<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Quản lý mã giảm giá" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="d-flex justify-content-between align-items-center mb-4">
	<h4 class="mb-0"><i class="fa fa-ticket"></i> Quản lý mã giảm giá</h4>
	<a href="${pageContext.request.contextPath}/manager/vouchers/add" class="btn btn-primary"><i class="fa fa-plus"></i> Thêm mã mới</a>
</div>

<c:if test="${param.success == 'true'}"><div class="alert alert-success">Thao tác thành công!</div></c:if>
<c:if test="${param.error == 'true'}"><div class="alert alert-danger">Có lỗi xảy ra, vui lòng thử lại.</div></c:if>

<c:choose>
<c:when test="${empty vouchers}">
	<div class="alert alert-info">Chưa có mã giảm giá nào.</div>
</c:when>
<c:otherwise>
	<div class="table-responsive">
		<table class="table align-middle">
			<thead>
				<tr>
					<th>Mã</th>
					<th>Mô tả</th>
					<th>Giảm giá</th>
					<th class="text-end">Đơn tối thiểu</th>
					<th class="text-center">Đã dùng / Số lượng</th>
					<th class="text-center">Trạng thái</th>
					<th class="text-end">Thao tác</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${vouchers}" var="v">
					<tr>
						<td><strong>${v.code}</strong></td>
						<td>${v.description}</td>
						<td>
							<c:choose>
								<c:when test="${not empty v.discountPercent}">${v.discountPercent}%<c:if test="${not empty v.maxDiscount}"> (tối đa <fmt:formatNumber value="${v.maxDiscount}" pattern="#,###"/>đ)</c:if></c:when>
								<c:otherwise><fmt:formatNumber value="${v.discountAmount}" pattern="#,###"/> đ</c:otherwise>
							</c:choose>
						</td>
						<td class="text-end"><fmt:formatNumber value="${v.minOrderValue}" pattern="#,###"/> đ</td>
						<td class="text-center">${v.usedCount} / ${v.quantity}</td>
						<td class="text-center">
							<c:choose>
								<c:when test="${v.active}"><span class="badge bg-success">Hoạt động</span></c:when>
								<c:otherwise><span class="badge bg-secondary">Ngừng</span></c:otherwise>
							</c:choose>
						</td>
						<td class="text-end">
							<a href="${pageContext.request.contextPath}/manager/vouchers/edit?id=${v.id}" class="btn btn-sm btn-outline-primary"><i class="fa fa-pencil"></i></a>
							<form action="${pageContext.request.contextPath}/manager/vouchers/delete" method="post" class="d-inline">
								<input type="hidden" name="id" value="${v.id}">
								<button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa mã giảm giá này?');"><i class="fa fa-trash"></i></button>
							</form>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>
	</div>
</c:otherwise>
</c:choose>

<jsp:include page="/views/common/footer.jsp"/>
