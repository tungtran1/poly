<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<c:set var="pageTitle" value="Dashboard quản trị" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js" crossorigin="anonymous"></script>

<h4 class="mb-4"><i class="fa fa-dashboard"></i> Dashboard tổng quan</h4>

<div class="row g-3 mb-4">
	<div class="col-6 col-md-3">
		<div class="card text-white bg-success h-100">
			<div class="card-body">
				<div class="small">Tổng doanh thu (đơn đã giao)</div>
				<div class="fs-4 fw-bold"><fmt:formatNumber value="${totalRevenue}" pattern="#,###"/> đ</div>
			</div>
		</div>
	</div>
	<div class="col-6 col-md-3">
		<div class="card text-white bg-primary h-100">
			<div class="card-body">
				<div class="small">Tổng đơn hàng</div>
				<div class="fs-4 fw-bold">${totalOrders}</div>
				<div class="small">${pendingOrders} đơn đang xử lý</div>
			</div>
		</div>
	</div>
	<div class="col-6 col-md-3">
		<div class="card text-white bg-info h-100">
			<div class="card-body">
				<div class="small">Tổng khách hàng</div>
				<div class="fs-4 fw-bold">${totalCustomers}</div>
			</div>
		</div>
	</div>
	<div class="col-6 col-md-3">
		<div class="card text-white bg-warning h-100">
			<div class="card-body">
				<div class="small">Tổng sản phẩm</div>
				<div class="fs-4 fw-bold">${totalProducts}</div>
				<c:if test="${lowStockCount > 0}">
					<div class="small"><i class="fa fa-exclamation-triangle"></i> ${lowStockCount} sản phẩm sắp hết hàng</div>
				</c:if>
			</div>
		</div>
	</div>
</div>

<div class="row g-3 mb-3">
	<div class="col-md-7">
		<div class="card h-100">
			<div class="card-header fw-bold">Biểu đồ doanh thu 7 ngày gần nhất</div>
			<div class="card-body">
				<canvas id="revenueChart" height="220"></canvas>
				<c:if test="${empty revenueByDay}">
					<p class="text-muted text-center mb-0 mt-2">Chưa có dữ liệu doanh thu.</p>
				</c:if>
			</div>
		</div>
	</div>
	<div class="col-md-5">
		<div class="card h-100">
			<div class="card-header fw-bold">Tỷ trọng bán chạy (Top 5 sản phẩm)</div>
			<div class="card-body">
				<canvas id="topProductsChart" height="220"></canvas>
				<c:if test="${empty topProducts}">
					<p class="text-muted text-center mb-0 mt-2">Chưa có dữ liệu bán hàng.</p>
				</c:if>
			</div>
		</div>
	</div>
</div>

<div class="row g-3">
	<div class="col-md-6">
		<div class="card h-100">
			<div class="card-header fw-bold">Top 5 sản phẩm bán chạy</div>
			<ul class="list-group list-group-flush">
				<c:forEach items="${topProducts}" var="p" varStatus="st">
					<li class="list-group-item d-flex justify-content-between align-items-center">
						<span>${st.index + 1}. ${p.productName}</span>
						<span class="badge bg-primary rounded-pill">${p.totalQuantitySold} đã bán</span>
					</li>
				</c:forEach>
				<c:if test="${empty topProducts}">
					<li class="list-group-item text-muted">Chưa có dữ liệu bán hàng.</li>
				</c:if>
			</ul>
		</div>
	</div>
	<div class="col-md-6">
		<div class="card h-100">
			<div class="card-header fw-bold">Doanh thu 7 ngày gần nhất (chi tiết)</div>
			<ul class="list-group list-group-flush">
				<c:forEach items="${revenueByDay}" var="r">
					<li class="list-group-item d-flex justify-content-between align-items-center">
						<span><fmt:formatDate value="${r.revenueDate}" pattern="dd/MM/yyyy"/> (${r.totalBills} đơn)</span>
						<span class="fw-bold text-danger"><fmt:formatNumber value="${r.totalRevenue}" pattern="#,###"/> đ</span>
					</li>
				</c:forEach>
				<c:if test="${empty revenueByDay}">
					<li class="list-group-item text-muted">Chưa có dữ liệu doanh thu.</li>
				</c:if>
			</ul>
		</div>
	</div>
</div>

<script>
(function() {
	var revenueLabelsRaw = [<c:forEach items="${revenueByDay}" var="r" varStatus="st">'<fmt:formatDate value="${r.revenueDate}" pattern="dd/MM"/>'${!st.last ? ',' : ''}</c:forEach>];
	var revenueData = [<c:forEach items="${revenueByDay}" var="r" varStatus="st">${r.totalRevenue}${!st.last ? ',' : ''}</c:forEach>];

	var topLabels = [<c:forEach items="${topProducts}" var="p" varStatus="st">'${fn:escapeXml(p.productName)}'${!st.last ? ',' : ''}</c:forEach>];
	var topData = [<c:forEach items="${topProducts}" var="p" varStatus="st">${p.totalQuantitySold}${!st.last ? ',' : ''}</c:forEach>];

	if (revenueLabelsRaw.length > 0) {
		new Chart(document.getElementById('revenueChart'), {
			type: 'bar',
			data: {
				labels: revenueLabelsRaw,
				datasets: [{
					label: 'Doanh thu (đ)',
					data: revenueData,
					backgroundColor: 'rgba(220, 53, 69, 0.6)',
					borderColor: 'rgba(220, 53, 69, 1)',
					borderWidth: 1
				}]
			},
			options: {
				responsive: true,
				plugins: { legend: { display: false } },
				scales: {
					y: {
						beginAtZero: true,
						ticks: { callback: function(v) { return v.toLocaleString('vi-VN'); } }
					}
				}
			}
		});
	}

	if (topLabels.length > 0) {
		new Chart(document.getElementById('topProductsChart'), {
			type: 'doughnut',
			data: {
				labels: topLabels,
				datasets: [{
					data: topData,
					backgroundColor: ['#0d6efd', '#dc3545', '#198754', '#ffc107', '#6f42c1']
				}]
			},
			options: {
				responsive: true,
				plugins: { legend: { position: 'bottom' } }
			}
		});
	}
})();
</script>

<jsp:include page="/views/common/footer.jsp"/>
