<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Quản lý hóa đơn" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4"><i class="fa fa-file-text-o"></i> Quản lý hóa đơn / đơn hàng</h4>

<c:if test="${not empty filterUser}">
	<div class="alert alert-info d-flex justify-content-between align-items-center">
		<span>Đang xem lịch sử mua hàng của: <strong>${filterUser.fullName}</strong> (${filterUser.email})</span>
		<a href="${pageContext.request.contextPath}/manager/bills" class="btn btn-sm btn-outline-secondary">Xem tất cả đơn hàng</a>
	</div>
</c:if>

<form action="${pageContext.request.contextPath}/manager/bills" method="get" class="row g-2 mb-3">
	<div class="col-md-4">
		<input type="text" class="form-control" name="code" placeholder="Tìm theo mã đơn hàng..." value="${param.code}">
	</div>
	<div class="col-md-2">
		<button type="submit" class="btn btn-outline-primary w-100"><i class="fa fa-search"></i> Tìm</button>
	</div>
</form>

<c:choose>
<c:when test="${empty bills}">
	<div class="alert alert-info">Chưa có đơn hàng nào.</div>
</c:when>
<c:otherwise>
	<div class="table-responsive">
		<table class="table align-middle">
			<thead>
				<tr>
					<th>Mã đơn</th>
					<th>Ngày đặt</th>
					<th>Người nhận</th>
					<th class="text-end">Tổng tiền</th>
					<th class="text-center">Trạng thái</th>
					<th class="text-end">Thao tác</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${bills}" var="bill">
					<tr>
						<td>${bill.code}</td>
						<td><fmt:formatDate value="${bill.createdAt}" pattern="dd/MM/yyyy HH:mm"/></td>
						<td>${bill.receiverName}</td>
						<td class="text-end fw-bold text-danger"><fmt:formatNumber value="${bill.total}" pattern="#,###"/> đ</td>
						<td class="text-center">
							<jsp:include page="/views/common/status-badge.jsp"><jsp:param name="status" value="${bill.status}"/></jsp:include>
						</td>
						<td class="text-end">
							<a href="${pageContext.request.contextPath}/manager/bills/detail?id=${bill.id}" class="btn btn-sm btn-outline-primary"><i class="fa fa-eye"></i> Xem</a>
							<c:if test="${bill.status != 'cancel'}">
								<form action="${pageContext.request.contextPath}/manager/bills/update-status" method="post" class="d-inline">
									<input type="hidden" name="id" value="${bill.id}">
									<input type="hidden" name="status" value="cancel">
									<button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hủy đơn hàng này? Số lượng tồn kho sẽ được hoàn lại nếu đơn đã hoàn thành.');"><i class="fa fa-times"></i> Hủy</button>
								</form>
							</c:if>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>
	</div>
</c:otherwise>
</c:choose>

<jsp:include page="/views/common/footer.jsp"/>
