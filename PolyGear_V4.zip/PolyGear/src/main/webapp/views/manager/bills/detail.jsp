<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Chi tiết hóa đơn ${bill.code}" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="d-flex justify-content-between align-items-center mb-3">
	<a href="${pageContext.request.contextPath}/manager/bills" class="btn btn-outline-secondary">&laquo; Danh sách hóa đơn</a>
	<button class="btn btn-primary" onclick="window.print();"><i class="fa fa-print"></i> In hóa đơn</button>
</div>

<div class="card p-4 mb-4">
	<div class="text-center mb-4">
		<h3 class="fw-bold">HÓA ĐƠN BÁN HÀNG</h3>
		<p class="text-muted mb-0">PolyGear - Cửa hàng phụ kiện điện thoại</p>
	</div>

	<div class="row mb-4">
		<div class="col-md-6">
			<p class="mb-1"><strong>Mã hóa đơn:</strong> ${bill.code}</p>
			<p class="mb-1"><strong>Ngày lập:</strong> <fmt:formatDate value="${bill.createdAt}" pattern="dd/MM/yyyy HH:mm"/></p>
			<p class="mb-1">
				<strong>Trạng thái:</strong>
				<jsp:include page="/views/common/status-badge.jsp"><jsp:param name="status" value="${bill.status}"/></jsp:include>
			</p>
			<c:if test="${not empty bill.voucherCode}">
				<p class="mb-1"><strong>Mã giảm giá:</strong> ${bill.voucherCode} (-<fmt:formatNumber value="${bill.discountAmount}" pattern="#,###"/> đ)</p>
			</c:if>
		</div>
		<div class="col-md-6">
			<p class="mb-1"><strong>Người nhận:</strong> ${bill.receiverName}</p>
			<p class="mb-1"><strong>Điện thoại:</strong> ${bill.receiverPhone}</p>
			<p class="mb-1"><strong>Địa chỉ:</strong> ${bill.receiverAddress}</p>
			<p class="mb-1"><strong>Vận chuyển:</strong> ${bill.shippingMethod}</p>
		</div>
	</div>

	<table class="table table-bordered">
		<thead class="table-light">
			<tr>
				<th>#</th>
				<th>Phụ kiện</th>
				<th class="text-end">Đơn giá</th>
				<th class="text-center">Số lượng</th>
				<th class="text-end">Thành tiền</th>
			</tr>
		</thead>
		<tbody>
			<c:forEach items="${details}" var="d" varStatus="st">
				<tr>
					<td>${st.index + 1}</td>
					<td>${productMap[d.productId].name}</td>
					<td class="text-end"><fmt:formatNumber value="${d.price}" pattern="#,###"/> đ</td>
					<td class="text-center">${d.quantity}</td>
					<td class="text-end"><fmt:formatNumber value="${d.price * d.quantity}" pattern="#,###"/> đ</td>
				</tr>
			</c:forEach>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="4" class="text-end">Tạm tính</th>
				<th class="text-end"><fmt:formatNumber value="${bill.total - bill.shippingFee + bill.discountAmount}" pattern="#,###"/> đ</th>
			</tr>
			<c:if test="${not empty bill.voucherCode}">
				<tr>
					<th colspan="4" class="text-end">Giảm giá (${bill.voucherCode})</th>
					<th class="text-end text-success">-<fmt:formatNumber value="${bill.discountAmount}" pattern="#,###"/> đ</th>
				</tr>
			</c:if>
			<tr>
				<th colspan="4" class="text-end">Phí vận chuyển</th>
				<th class="text-end">
					<c:choose>
						<c:when test="${bill.shippingFee == 0}">Miễn phí</c:when>
						<c:otherwise><fmt:formatNumber value="${bill.shippingFee}" pattern="#,###"/> đ</c:otherwise>
					</c:choose>
				</th>
			</tr>
			<tr>
				<th colspan="4" class="text-end">Tổng cộng</th>
				<th class="text-end text-danger"><fmt:formatNumber value="${bill.total}" pattern="#,###"/> đ</th>
			</tr>
		</tfoot>
	</table>
</div>

<c:if test="${bill.status != 'cancel' && bill.status != 'delivered'}">
<div class="card p-3 no-print">
	<h6 class="mb-3">Cập nhật trạng thái đơn hàng</h6>
	<form action="${pageContext.request.contextPath}/manager/bills/update-status" method="post" class="d-flex gap-2 flex-wrap">
		<input type="hidden" name="id" value="${bill.id}">
		<c:if test="${bill.status == 'waiting'}">
			<button type="submit" name="status" value="preparing" class="btn btn-info text-white">Chuyển: Đang chuẩn bị</button>
		</c:if>
		<c:if test="${bill.status == 'preparing'}">
			<button type="submit" name="status" value="shipping" class="btn btn-primary">Chuyển: Đang giao</button>
		</c:if>
		<c:if test="${bill.status == 'shipping'}">
			<button type="submit" name="status" value="delivered" class="btn btn-success">Xác nhận: Đã giao</button>
		</c:if>
		<button type="submit" name="status" value="cancel" class="btn btn-outline-danger" onclick="return confirm('Hủy đơn hàng này? Số lượng tồn kho sẽ được hoàn lại.');">Hủy đơn</button>
	</form>
</div>
</c:if>

<jsp:include page="/views/common/footer.jsp"/>
