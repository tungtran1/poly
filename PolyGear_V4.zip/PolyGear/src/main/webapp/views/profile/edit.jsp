<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Thông tin cá nhân" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="row justify-content-center">
	<div class="col-md-6">
		<div class="card p-4">
			<h4 class="text-center mb-4">Thông tin cá nhân</h4>

			<c:if test="${not empty message}"><div class="alert alert-success">${message}</div></c:if>
			<c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>

			<form action="${pageContext.request.contextPath}/edit-profile" method="post">
				<div class="mb-3">
					<label class="form-label">Email</label>
					<input type="email" class="form-control" value="${profile.email}" disabled>
				</div>
				<div class="mb-3">
					<label class="form-label">Họ và tên</label>
					<input type="text" class="form-control ${not empty fullNameError ? 'is-invalid' : ''}" name="fullName" value="${profile.fullName}">
					<c:if test="${not empty fullNameError}"><div class="invalid-feedback">${fullNameError}</div></c:if>
				</div>
				<div class="mb-3">
					<label class="form-label">Số điện thoại</label>
					<input type="text" class="form-control ${not empty phoneError ? 'is-invalid' : ''}" name="phone" value="${profile.phone}">
					<c:if test="${not empty phoneError}"><div class="invalid-feedback">${phoneError}</div></c:if>
				</div>
				<button type="submit" class="btn btn-primary w-100">Lưu thay đổi</button>
				<p class="text-center mt-3 mb-0 small"><a href="${pageContext.request.contextPath}/change-pass">Đổi mật khẩu &raquo;</a></p>
			</form>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
