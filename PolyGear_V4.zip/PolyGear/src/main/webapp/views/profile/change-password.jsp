<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Đổi mật khẩu" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="row justify-content-center">
	<div class="col-md-6">
		<div class="card p-4">
			<h4 class="text-center mb-4">Đổi mật khẩu</h4>

			<c:if test="${not empty message}"><div class="alert alert-success">${message}</div></c:if>
			<c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>

			<form action="${pageContext.request.contextPath}/change-pass" method="post">
				<div class="mb-3">
					<label class="form-label">Mật khẩu hiện tại</label>
					<input type="password" class="form-control" name="oldPassword" required>
				</div>
				<div class="mb-3">
					<label class="form-label">Mật khẩu mới</label>
					<input type="password" class="form-control" name="newPassword" required minlength="6">
				</div>
				<div class="mb-3">
					<label class="form-label">Nhập lại mật khẩu mới</label>
					<input type="password" class="form-control" name="confirmPassword" required minlength="6">
				</div>
				<button type="submit" class="btn btn-primary w-100">Xác nhận đổi mật khẩu</button>
				<p class="text-center mt-3 mb-0 small"><a href="${pageContext.request.contextPath}/edit-profile">&laquo; Quay lại thông tin cá nhân</a></p>
			</form>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
