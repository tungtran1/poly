<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="${not empty product && not empty product.id ? 'Cập nhật phụ kiện' : 'Thêm phụ kiện'}" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<c:set var="isEdit" value="${not empty param.id || (not empty product && not empty product.id)}"/>

<h4 class="mb-4">${isEdit ? 'Cập nhật phụ kiện' : 'Thêm phụ kiện mới'}</h4>

<div class="row justify-content-center">
	<div class="col-md-7">
		<div class="card p-4">
			<form action="${pageContext.request.contextPath}/manager/products/${isEdit ? 'edit' : 'add'}" method="post" enctype="multipart/form-data">
				<c:if test="${isEdit}">
					<input type="hidden" name="id" value="${product.id}">
					<input type="hidden" name="oldImage" value="${product.image}">
				</c:if>

				<div class="mb-3">
					<label class="form-label">Loại phụ kiện</label>
					<select class="form-select ${not empty errCat ? 'is-invalid' : ''}" name="categoryId">
						<option value="">-- Chọn loại phụ kiện --</option>
						<c:forEach items="${categories}" var="cat">
							<option value="${cat.id}" ${product.categoryId == cat.id ? 'selected' : ''}>${cat.name}</option>
						</c:forEach>
					</select>
					<c:if test="${not empty errCat}"><div class="invalid-feedback">${errCat}</div></c:if>
				</div>

				<div class="mb-3">
					<label class="form-label">Thương hiệu</label>
					<select class="form-select" name="brandId">
						<option value="">-- Không rõ / khác --</option>
						<c:forEach items="${brands}" var="br">
							<option value="${br.id}" ${product.brandId == br.id ? 'selected' : ''}>${br.name}</option>
						</c:forEach>
					</select>
				</div>

				<div class="mb-3">
					<label class="form-label">Tên phụ kiện</label>
					<input type="text" class="form-control ${not empty errName ? 'is-invalid' : ''}" name="name" value="${product.name}">
					<c:if test="${not empty errName}"><div class="invalid-feedback">${errName}</div></c:if>
				</div>

				<div class="mb-3">
					<label class="form-label">Mô tả</label>
					<textarea class="form-control ${not empty errDesc ? 'is-invalid' : ''}" name="description" rows="3">${product.description}</textarea>
					<c:if test="${not empty errDesc}"><div class="invalid-feedback">${errDesc}</div></c:if>
				</div>

				<div class="row">
					<div class="col-6 mb-3">
						<label class="form-label">Giá bán (đ)</label>
						<input type="number" class="form-control ${not empty errPrice ? 'is-invalid' : ''}" name="price" value="${product.price}" min="0">
						<c:if test="${not empty errPrice}"><div class="invalid-feedback">${errPrice}</div></c:if>
					</div>
					<div class="col-6 mb-3">
						<label class="form-label">Số lượng tồn kho</label>
						<input type="number" class="form-control ${not empty errQuantity ? 'is-invalid' : ''}" name="quantity" value="${empty product.id && empty product.quantity ? 0 : product.quantity}" min="0">
						<c:if test="${not empty errQuantity}"><div class="invalid-feedback">${errQuantity}</div></c:if>
					</div>
				</div>

				<div class="mb-3">
					<label class="form-label">Hình ảnh ${isEdit ? '(bỏ trống nếu không đổi)' : ''}</label>
					<input type="file" class="form-control ${not empty errImage ? 'is-invalid' : ''}" name="image" accept="image/*">
					<c:if test="${not empty errImage}"><div class="invalid-feedback">${errImage}</div></c:if>
					<c:if test="${isEdit && not empty product.image}">
						<img src="${pageContext.request.contextPath}/uploads/${product.image}" class="mt-2 rounded border" style="width:80px;height:80px;object-fit:cover;">
					</c:if>
				</div>

				<div class="mb-3 form-check">
					<input type="checkbox" class="form-check-input" name="active" value="1" id="activeCheck" ${product.active || empty product ? 'checked' : ''}>
					<label class="form-check-label" for="activeCheck">Đang bán</label>
				</div>

				<hr>
				<div class="mb-3 form-check">
					<input type="checkbox" class="form-check-input" name="isFlashSale" value="1" id="flashSaleCheck" ${product.flashSale ? 'checked' : ''}>
					<label class="form-check-label" for="flashSaleCheck"><i class="fa fa-bolt text-danger"></i> Hiển thị trong Flash Sale trang chủ</label>
				</div>
				<div class="mb-3">
					<label class="form-label">Giá Flash Sale (đ)</label>
					<input type="number" class="form-control ${not empty errDiscountPrice ? 'is-invalid' : ''}" name="discountPrice" value="${product.discountPrice}" min="0">
					<c:if test="${not empty errDiscountPrice}"><div class="invalid-feedback">${errDiscountPrice}</div></c:if>
					<div class="form-text">Chỉ áp dụng khi bật Flash Sale, và phải nhỏ hơn giá bán gốc.</div>
				</div>

				<button type="submit" class="btn btn-primary w-100">${isEdit ? 'Cập nhật' : 'Thêm mới'}</button>
				<a href="${pageContext.request.contextPath}/manager/products" class="btn btn-outline-secondary w-100 mt-2">Hủy</a>
			</form>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
