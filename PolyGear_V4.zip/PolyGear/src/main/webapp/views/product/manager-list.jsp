<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Quản lý phụ kiện" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="d-flex justify-content-between align-items-center mb-4">
	<h4 class="mb-0"><i class="fa fa-mobile"></i> Quản lý phụ kiện</h4>
	<a href="${pageContext.request.contextPath}/manager/products/add" class="btn btn-primary"><i class="fa fa-plus"></i> Thêm phụ kiện</a>
</div>

<c:if test="${param.success == 'true'}"><div class="alert alert-success">Thao tác thành công!</div></c:if>
<c:if test="${param.error == 'false'}"><div class="alert alert-danger">Thao tác thất bại, vui lòng thử lại!</div></c:if>

<form action="${pageContext.request.contextPath}/manager/products" method="get" class="row g-2 mb-3">
	<div class="col-md-5">
		<input type="text" class="form-control" name="keyword" placeholder="Tìm theo tên phụ kiện..." value="${keyword}">
	</div>
	<div class="col-md-3">
		<select class="form-select" name="categoryId">
			<option value="0">-- Tất cả danh mục --</option>
			<c:forEach items="${categories}" var="cat">
				<option value="${cat.id}" ${categoryId == cat.id ? 'selected' : ''}>${cat.name}</option>
			</c:forEach>
		</select>
	</div>
	<div class="col-md-3">
		<select class="form-select" name="brandId">
			<option value="0">-- Tất cả thương hiệu --</option>
			<c:forEach items="${brands}" var="br">
				<option value="${br.id}" ${brandId == br.id ? 'selected' : ''}>${br.name}</option>
			</c:forEach>
		</select>
	</div>
	<div class="col-md-1">
		<button type="submit" class="btn btn-outline-primary w-100"><i class="fa fa-search"></i></button>
	</div>
</form>

<div class="table-responsive">
	<table class="table align-middle">
		<thead>
			<tr>
				<th>Ảnh</th>
				<th>Tên phụ kiện</th>
				<th class="text-end">Giá</th>
				<th class="text-end">Tồn kho</th>
				<th class="text-center">Trạng thái</th>
				<th class="text-end">Thao tác</th>
			</tr>
		</thead>
		<tbody>
			<c:forEach items="${products}" var="p">
				<tr>
					<td><img src="${pageContext.request.contextPath}/uploads/${p.image}" style="width:50px;height:50px;object-fit:cover;" class="rounded border" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'"></td>
					<td>${p.name} <c:if test="${p.flashSale}"><span class="badge bg-danger">Flash Sale</span></c:if></td>
					<td class="text-end"><fmt:formatNumber value="${p.price}" pattern="#,###"/> đ</td>
					<td class="text-end">
						<c:choose>
							<c:when test="${p.quantity <= 0}"><span class="badge bg-danger">Hết hàng</span></c:when>
							<c:when test="${p.quantity <= 5}"><span class="badge bg-warning text-dark">${p.quantity} (sắp hết)</span></c:when>
							<c:otherwise>${p.quantity}</c:otherwise>
						</c:choose>
					</td>
					<td class="text-center">
						<c:choose>
							<c:when test="${p.active}"><span class="badge bg-success">Đang bán</span></c:when>
							<c:otherwise><span class="badge bg-secondary">Ngừng bán</span></c:otherwise>
						</c:choose>
					</td>
					<td class="text-end">
						<a href="${pageContext.request.contextPath}/manager/products/edit?id=${p.id}" class="btn btn-sm btn-outline-primary"><i class="fa fa-edit"></i></a>
						<form action="${pageContext.request.contextPath}/manager/products/delete" method="post" class="d-inline">
							<input type="hidden" name="id" value="${p.id}">
							<button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa phụ kiện này?');"><i class="fa fa-trash"></i></button>
						</form>
					</td>
				</tr>
			</c:forEach>
			<c:if test="${empty products}">
				<tr><td colspan="6" class="text-center text-muted">Không tìm thấy phụ kiện nào phù hợp.</td></tr>
			</c:if>
		</tbody>
	</table>
</div>

<jsp:include page="/views/common/footer.jsp"/>
