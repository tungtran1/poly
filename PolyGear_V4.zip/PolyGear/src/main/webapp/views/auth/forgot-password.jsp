<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Quên mật khẩu" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="row justify-content-center">
	<div class="col-md-5">
		<div class="card p-4">
			<h4 class="text-center mb-3">Quên mật khẩu</h4>
			<p class="text-muted small text-center">Nhập email đã đăng ký, hệ thống sẽ gửi cho bạn liên kết để đặt lại mật khẩu.</p>

			<c:if test="${not empty message}">
				<div class="alert alert-info">${message}</div>
			</c:if>

			<c:if test="${not empty devResetLink}">
				<div class="alert alert-warning">
					<strong>Chế độ demo (chưa cấu hình email thật):</strong><br>
					Nhấn vào liên kết bên dưới để đặt lại mật khẩu:<br>
					<a href="${devResetLink}">${devResetLink}</a>
				</div>
			</c:if>

			<form action="${pageContext.request.contextPath}/quen-mat-khau" method="post">
				<div class="mb-3">
					<label class="form-label">Email</label>
					<input type="email" class="form-control" name="email" required autofocus>
				</div>
				<button type="submit" class="btn btn-primary w-100">Gửi yêu cầu</button>
				<p class="text-center mt-3 mb-0 small"><a href="${pageContext.request.contextPath}/dang-nhap">&laquo; Quay lại đăng nhập</a></p>
			</form>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
