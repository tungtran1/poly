<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Đăng ký" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="row justify-content-center">
	<div class="col-md-6">
		<div class="card p-4">
			<h4 class="text-center mb-4">Đăng ký tài khoản</h4>

			<c:if test="${not empty error}">
				<div class="alert alert-danger">${error}</div>
			</c:if>

			<form action="${pageContext.request.contextPath}/dang-ky" method="post">
				<div class="mb-3">
					<label class="form-label">Họ và tên</label>
					<input type="text" class="form-control ${not empty fullNameError ? 'is-invalid' : ''}" name="fullName" value="${fullName}">
					<c:if test="${not empty fullNameError}"><div class="invalid-feedback">${fullNameError}</div></c:if>
				</div>
				<div class="mb-3">
					<label class="form-label">Email</label>
					<input type="email" class="form-control ${not empty emailError ? 'is-invalid' : ''}" name="email" value="${email}">
					<c:if test="${not empty emailError}"><div class="invalid-feedback">${emailError}</div></c:if>
				</div>
				<div class="mb-3">
					<label class="form-label">Số điện thoại</label>
					<input type="text" class="form-control ${not empty phoneError ? 'is-invalid' : ''}" name="phone" value="${phone}">
					<c:if test="${not empty phoneError}"><div class="invalid-feedback">${phoneError}</div></c:if>
				</div>
				<div class="mb-3">
					<label class="form-label">Mật khẩu</label>
					<input type="password" class="form-control ${not empty passwordError ? 'is-invalid' : ''}" name="password">
					<c:if test="${not empty passwordError}"><div class="invalid-feedback">${passwordError}</div></c:if>
				</div>
				<div class="mb-3">
					<label class="form-label">Nhập lại mật khẩu</label>
					<input type="password" class="form-control ${not empty confirmPasswordError ? 'is-invalid' : ''}" name="confirmPassword">
					<c:if test="${not empty confirmPasswordError}"><div class="invalid-feedback">${confirmPasswordError}</div></c:if>
				</div>
				<button type="submit" class="btn btn-primary w-100">Đăng ký</button>
				<p class="text-center mt-3 mb-0 small">Đã có tài khoản? <a href="${pageContext.request.contextPath}/dang-nhap">Đăng nhập</a></p>
			</form>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
