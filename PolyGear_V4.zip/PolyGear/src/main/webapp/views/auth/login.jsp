<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Đăng nhập" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="row justify-content-center">
	<div class="col-md-5">
		<div class="card p-4">
			<h4 class="text-center mb-4">Đăng nhập</h4>

			<c:if test="${not empty message}">
				<div class="alert alert-danger">${message}</div>
			</c:if>
			<c:if test="${not empty success}">
				<div class="alert alert-success">${success}</div>
			</c:if>

			<form action="${pageContext.request.contextPath}/dang-nhap" method="post">
				<div class="mb-3">
					<label class="form-label">Email</label>
					<input type="email" class="form-control" name="email" required autofocus>
				</div>
				<div class="mb-3">
					<label class="form-label">Mật khẩu</label>
					<input type="password" class="form-control" name="password" required>
				</div>
				<div class="d-flex justify-content-between mb-3">
					<a href="${pageContext.request.contextPath}/quen-mat-khau" class="small">Quên mật khẩu?</a>
					<a href="${pageContext.request.contextPath}/dang-ky" class="small">Chưa có tài khoản? Đăng ký</a>
				</div>
				<button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
			</form>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
