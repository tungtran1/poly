<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Đặt lại mật khẩu" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="row justify-content-center">
	<div class="col-md-5">
		<div class="card p-4">
			<h4 class="text-center mb-4">Đặt lại mật khẩu</h4>

			<c:if test="${not empty error}">
				<div class="alert alert-danger">${error}</div>
			</c:if>

			<c:if test="${not empty token}">
				<form action="${pageContext.request.contextPath}/dat-lai-mat-khau" method="post">
					<input type="hidden" name="token" value="${token}">
					<div class="mb-3">
						<label class="form-label">Mật khẩu mới</label>
						<input type="password" class="form-control" name="password" required minlength="6">
					</div>
					<div class="mb-3">
						<label class="form-label">Nhập lại mật khẩu mới</label>
						<input type="password" class="form-control" name="confirmPassword" required minlength="6">
					</div>
					<button type="submit" class="btn btn-primary w-100">Xác nhận</button>
				</form>
			</c:if>

			<c:if test="${empty token}">
				<p class="text-center mb-0"><a href="${pageContext.request.contextPath}/quen-mat-khau">Yêu cầu liên kết đặt lại mật khẩu mới &raquo;</a></p>
			</c:if>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
