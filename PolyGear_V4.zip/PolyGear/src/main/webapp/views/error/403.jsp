<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true"%>
<jsp:include page="/views/common/header.jsp"/>
<div class="text-center py-5">
	<h1 class="display-3 fw-bold text-danger">403</h1>
	<p class="lead">Bạn không có quyền truy cập trang này.</p>
	<a href="${pageContext.request.contextPath}/trang-chu" class="btn btn-primary">Về trang chủ</a>
</div>
<jsp:include page="/views/common/footer.jsp"/>
