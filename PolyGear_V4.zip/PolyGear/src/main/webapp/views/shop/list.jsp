<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<c:set var="pageTitle" value="Phụ kiện điện thoại" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="row">
	<div class="col-md-3 mb-4">
		<div class="card mb-3">
			<div class="card-header fw-bold">Loại phụ kiện</div>
			<div class="list-group list-group-flush">
				<a href="${pageContext.request.contextPath}/san-pham${not empty brandId && brandId > 0 ? '?brandId='.concat(brandId) : ''}"
					class="list-group-item list-group-item-action ${empty currentCategory ? 'active' : ''}">Tất cả phụ kiện</a>
				<c:forEach items="${categories}" var="cat">
					<a href="${pageContext.request.contextPath}/san-pham?categoryId=${cat.id}${not empty brandId && brandId > 0 ? '&brandId='.concat(brandId) : ''}"
						class="list-group-item list-group-item-action ${currentCategory.id == cat.id ? 'active' : ''}">${cat.name}</a>
				</c:forEach>
			</div>
		</div>
		<div class="card mb-3">
			<div class="card-header fw-bold">Thương hiệu</div>
			<div class="list-group list-group-flush">
				<a href="${pageContext.request.contextPath}/san-pham${not empty categoryId && categoryId > 0 ? '?categoryId='.concat(categoryId) : ''}"
					class="list-group-item list-group-item-action ${empty currentBrand ? 'active' : ''}">Tất cả thương hiệu</a>
				<c:forEach items="${brands}" var="br">
					<a href="${pageContext.request.contextPath}/san-pham?brandId=${br.id}${not empty categoryId && categoryId > 0 ? '&categoryId='.concat(categoryId) : ''}"
						class="list-group-item list-group-item-action ${currentBrand.id == br.id ? 'active' : ''}">${br.name}</a>
				</c:forEach>
			</div>
		</div>
		<div class="card">
			<div class="card-header fw-bold">Tìm kiếm &amp; lọc giá</div>
			<div class="card-body">
				<form action="${pageContext.request.contextPath}/san-pham" method="get">
					<input type="hidden" name="categoryId" value="${categoryId}">
					<input type="hidden" name="brandId" value="${brandId}">
					<div class="mb-2">
						<label class="form-label small mb-1">Tên hoặc hãng sản xuất</label>
						<input type="text" class="form-control form-control-sm" name="keyword" placeholder="Nhập từ khóa..." value="${keyword}">
					</div>
					<div class="row g-1 mb-2">
						<div class="col-6">
							<label class="form-label small mb-1">Giá từ</label>
							<input type="number" min="0" class="form-control form-control-sm" name="minPrice" value="${minPrice}">
						</div>
						<div class="col-6">
							<label class="form-label small mb-1">Đến</label>
							<input type="number" min="0" class="form-control form-control-sm" name="maxPrice" value="${maxPrice}">
						</div>
					</div>
					<button class="btn btn-sm btn-primary w-100" type="submit"><i class="fa fa-filter"></i> Áp dụng</button>
				</form>
			</div>
		</div>
	</div>
	<div class="col-md-9">
		<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
			<h4 class="mb-0">
				<c:choose>
					<c:when test="${not empty currentCategory}">${currentCategory.name}</c:when>
					<c:otherwise>Tất cả phụ kiện</c:otherwise>
				</c:choose>
				<c:if test="${not empty currentBrand}"> - <small class="text-muted">${currentBrand.name}</small></c:if>
			</h4>
			<form action="${pageContext.request.contextPath}/san-pham" method="get" class="d-flex align-items-center gap-2">
				<input type="hidden" name="categoryId" value="${categoryId}">
				<input type="hidden" name="brandId" value="${brandId}">
				<input type="hidden" name="keyword" value="${keyword}">
				<input type="hidden" name="minPrice" value="${minPrice}">
				<input type="hidden" name="maxPrice" value="${maxPrice}">
				<label class="small text-muted mb-0">Sắp xếp:</label>
				<select class="form-select form-select-sm" name="sort" onchange="this.form.submit()" style="width:auto;">
					<option value="newest" ${empty sort || sort == 'newest' ? 'selected' : ''}>Mới nhất</option>
					<option value="price_asc" ${sort == 'price_asc' ? 'selected' : ''}>Giá tăng dần</option>
					<option value="price_desc" ${sort == 'price_desc' ? 'selected' : ''}>Giá giảm dần</option>
					<option value="best_selling" ${sort == 'best_selling' ? 'selected' : ''}>Bán chạy nhất</option>
				</select>
			</form>
		</div>
		<c:if test="${not empty keyword}">
			<p class="text-muted">Kết quả tìm kiếm cho: "<strong>${keyword}</strong>" (${fn:length(products)} sản phẩm)</p>
		</c:if>

		<div class="row g-3">
			<c:forEach items="${products}" var="p">
				<div class="col-6 col-md-4">
					<div class="card h-100 position-relative">
						<c:if test="${sessionScope.user != null}">
							<form action="${pageContext.request.contextPath}/yeu-thich/toggle" method="post" class="position-absolute top-0 end-0 m-1" style="z-index:2;">
								<input type="hidden" name="productId" value="${p.id}">
								<input type="hidden" name="redirect" value="/san-pham">
								<button class="btn btn-sm btn-light rounded-circle shadow-sm" type="submit" title="Yêu thích">
									<i class="fa ${wishlistIds.contains(p.id) ? 'fa-heart text-danger' : 'fa-heart-o'}"></i>
								</button>
							</form>
						</c:if>
						<c:if test="${p.onSale}"><span class="badge bg-danger position-absolute top-0 start-0 m-1">Flash Sale</span></c:if>
						<a href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">
							<img src="${pageContext.request.contextPath}/uploads/${p.image}" class="card-img-top" style="height:160px;object-fit:cover;" alt="${p.name}" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'">
						</a>
						<div class="card-body d-flex flex-column">
							<h6 class="card-title">
								<a class="text-decoration-none text-dark" href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">${p.name}</a>
							</h6>
							<c:choose>
								<c:when test="${p.onSale}">
									<p class="card-text mb-1">
										<span class="text-danger fw-bold"><fmt:formatNumber value="${p.discountPrice}" pattern="#,###"/> đ</span>
										<del class="text-muted small ms-1"><fmt:formatNumber value="${p.price}" pattern="#,###"/> đ</del>
									</p>
								</c:when>
								<c:otherwise>
									<p class="card-text text-danger fw-bold mb-1"><fmt:formatNumber value="${p.price}" pattern="#,###"/> đ</p>
								</c:otherwise>
							</c:choose>
							<p class="card-text mt-auto mb-2">
								<c:choose>
									<c:when test="${p.quantity <= 0}"><small class="text-danger">Hết hàng</small></c:when>
									<c:when test="${p.quantity <= 5}"><small class="text-warning">Sắp hết hàng (còn ${p.quantity})</small></c:when>
									<c:otherwise><small class="text-muted">Còn ${p.quantity} sản phẩm</small></c:otherwise>
								</c:choose>
							</p>
							<form action="${pageContext.request.contextPath}/gio-hang" method="post">
								<input type="hidden" name="action" value="add">
								<input type="hidden" name="productId" value="${p.id}">
								<input type="hidden" name="quantity" value="1">
								<button class="btn btn-sm btn-outline-primary w-100" type="submit" ${p.quantity <= 0 ? 'disabled' : ''}><i class="fa fa-cart-plus"></i> Thêm vào giỏ</button>
							</form>
						</div>
					</div>
				</div>
			</c:forEach>
			<c:if test="${empty products}">
				<div class="col-12">
					<div class="alert alert-info">Không tìm thấy phụ kiện nào phù hợp.</div>
				</div>
			</c:if>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
