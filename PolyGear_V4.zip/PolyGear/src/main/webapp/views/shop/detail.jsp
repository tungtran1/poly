<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<c:set var="pageTitle" value="${product.name}" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/trang-chu">Trang chủ</a></li>
		<li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/san-pham">Phụ kiện</a></li>
		<c:if test="${not empty category}">
			<li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/san-pham?categoryId=${category.id}">${category.name}</a></li>
		</c:if>
		<li class="breadcrumb-item active">${product.name}</li>
	</ol>
</nav>

<div class="row g-4 mb-5">
	<div class="col-md-5">
		<img src="${pageContext.request.contextPath}/uploads/${product.image}" class="img-fluid rounded border" style="width:100%;height:340px;object-fit:cover;" alt="${product.name}" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'">
	</div>
	<div class="col-md-7">
		<div class="d-flex justify-content-between align-items-start">
			<h3>${product.name}</h3>
			<c:if test="${sessionScope.user != null}">
				<form action="${pageContext.request.contextPath}/yeu-thich/toggle" method="post">
					<input type="hidden" name="productId" value="${product.id}">
					<input type="hidden" name="redirect" value="/san-pham/chi-tiet?id=${product.id}">
					<button class="btn btn-outline-danger" type="submit">
						<i class="fa ${isWishlisted ? 'fa-heart' : 'fa-heart-o'}"></i> ${isWishlisted ? 'Đã yêu thích' : 'Yêu thích'}
					</button>
				</form>
			</c:if>
		</div>
		<c:if test="${not empty category}">
			<span class="badge bg-secondary mb-2">${category.name}</span>
		</c:if>

		<div class="mb-1">
			<c:choose>
				<c:when test="${averageRating > 0}">
					<c:forEach begin="1" end="5" var="i">
						<i class="fa ${i <= averageRating + 0.5 ? 'fa-star text-warning' : 'fa-star-o text-warning'}"></i>
					</c:forEach>
					<span class="text-muted ms-1"><fmt:formatNumber value="${averageRating}" pattern="#.#"/>/5 (${reviewCount} đánh giá)</span>
				</c:when>
				<c:otherwise><span class="text-muted">Chưa có đánh giá nào</span></c:otherwise>
			</c:choose>
		</div>

		<c:choose>
			<c:when test="${product.onSale}">
				<h4 class="mb-0">
					<span class="text-danger fw-bold"><fmt:formatNumber value="${product.discountPrice}" pattern="#,###"/> đ</span>
					<del class="text-muted fs-6 ms-2"><fmt:formatNumber value="${product.price}" pattern="#,###"/> đ</del>
					<span class="badge bg-danger ms-2">Flash Sale</span>
				</h4>
			</c:when>
			<c:otherwise>
				<h4 class="text-danger fw-bold"><fmt:formatNumber value="${product.price}" pattern="#,###"/> đ</h4>
			</c:otherwise>
		</c:choose>
		<p class="text-muted">${product.description}</p>

		<c:choose>
			<c:when test="${product.quantity <= 0}">
				<div class="alert alert-danger py-2">Sản phẩm hiện đã hết hàng.</div>
			</c:when>
			<c:when test="${product.quantity <= 5}">
				<div class="alert alert-warning py-2">Sắp hết hàng, chỉ còn ${product.quantity} sản phẩm!</div>
			</c:when>
		</c:choose>

		<form action="${pageContext.request.contextPath}/gio-hang" method="post" class="row g-2 align-items-center mt-3">
			<input type="hidden" name="action" value="add">
			<input type="hidden" name="productId" value="${product.id}">
			<div class="col-auto">
				<label class="col-form-label">Số lượng:</label>
			</div>
			<div class="col-auto">
				<input type="number" name="quantity" value="1" min="1" max="${product.quantity}" class="form-control" style="width:90px;" ${product.quantity <= 0 ? 'disabled' : ''}>
			</div>
			<div class="col-auto">
				<button type="submit" class="btn btn-primary" ${product.quantity <= 0 ? 'disabled' : ''}><i class="fa fa-cart-plus"></i> Thêm vào giỏ hàng</button>
			</div>
		</form>
	</div>
</div>

<div class="row mb-5">
	<div class="col-md-8">
		<h5 class="mb-3">Đánh giá &amp; bình luận (${reviewCount})</h5>

		<c:if test="${param.reviewSuccess == 'true'}">
			<div class="alert alert-success py-2">Cảm ơn bạn đã đánh giá sản phẩm!</div>
		</c:if>
		<c:if test="${param.reviewError == 'notpurchased'}">
			<div class="alert alert-warning py-2">Bạn cần mua và nhận hàng thành công trước khi đánh giá sản phẩm này.</div>
		</c:if>
		<c:if test="${param.reviewError == 'alreadyreviewed'}">
			<div class="alert alert-warning py-2">Bạn đã đánh giá sản phẩm này rồi.</div>
		</c:if>

		<c:if test="${canReview}">
			<form action="${pageContext.request.contextPath}/san-pham/danh-gia" method="post" class="border rounded p-3 mb-4">
				<input type="hidden" name="productId" value="${product.id}">
				<div class="mb-2">
					<label class="form-label">Số sao</label>
					<select class="form-select" name="rating" style="width:120px;">
						<option value="5">5 sao</option>
						<option value="4">4 sao</option>
						<option value="3">3 sao</option>
						<option value="2">2 sao</option>
						<option value="1">1 sao</option>
					</select>
				</div>
				<div class="mb-2">
					<label class="form-label">Bình luận</label>
					<textarea class="form-control" name="comment" rows="3" placeholder="Chia sẻ cảm nhận của bạn về sản phẩm..."></textarea>
				</div>
				<button type="submit" class="btn btn-primary btn-sm">Gửi đánh giá</button>
			</form>
		</c:if>

		<c:if test="${empty reviews}">
			<p class="text-muted">Chưa có đánh giá nào cho sản phẩm này.</p>
		</c:if>
		<c:forEach items="${reviews}" var="r">
			<div class="border-bottom pb-2 mb-2">
				<div class="d-flex justify-content-between">
					<strong>${r.userFullName}</strong>
					<small class="text-muted"><fmt:formatDate value="${r.createdAt}" pattern="dd/MM/yyyy"/></small>
				</div>
				<div class="mb-1">
					<c:forEach begin="1" end="5" var="i">
						<i class="fa ${i <= r.rating ? 'fa-star text-warning' : 'fa-star-o text-warning'}"></i>
					</c:forEach>
				</div>
				<p class="mb-0">${r.comment}</p>
			</div>
		</c:forEach>
	</div>
</div>

<c:if test="${not empty related}">
	<h5 class="mb-3">Phụ kiện cùng loại</h5>
	<div class="row g-3">
		<c:forEach items="${related}" var="p">
			<c:if test="${p.id != product.id}">
				<div class="col-6 col-md-3">
					<div class="card h-100">
						<a href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">
							<img src="${pageContext.request.contextPath}/uploads/${p.image}" class="card-img-top" style="height:140px;object-fit:cover;" alt="${p.name}" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'">
						</a>
						<div class="card-body">
							<h6 class="card-title"><a class="text-decoration-none text-dark" href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">${p.name}</a></h6>
							<p class="card-text text-danger fw-bold"><fmt:formatNumber value="${p.displayPrice}" pattern="#,###"/> đ</p>
						</div>
					</div>
				</div>
			</c:if>
		</c:forEach>
	</div>
</c:if>

<jsp:include page="/views/common/footer.jsp"/>
