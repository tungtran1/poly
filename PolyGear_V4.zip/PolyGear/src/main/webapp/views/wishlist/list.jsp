<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Sản phẩm yêu thích" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4"><i class="fa fa-heart text-danger"></i> Sản phẩm yêu thích</h4>

<c:choose>
<c:when test="${empty products}">
	<div class="alert alert-info">Bạn chưa có sản phẩm yêu thích nào. <a href="${pageContext.request.contextPath}/san-pham">Khám phá ngay &raquo;</a></div>
</c:when>
<c:otherwise>
	<div class="row g-3">
		<c:forEach items="${products}" var="p">
			<div class="col-6 col-md-3">
				<div class="card h-100 position-relative">
					<form action="${pageContext.request.contextPath}/yeu-thich/toggle" method="post" class="position-absolute top-0 end-0 m-1" style="z-index:2;">
						<input type="hidden" name="productId" value="${p.id}">
						<input type="hidden" name="redirect" value="/yeu-thich">
						<button class="btn btn-sm btn-light rounded-circle shadow-sm" type="submit" title="Bỏ yêu thích">
							<i class="fa fa-heart text-danger"></i>
						</button>
					</form>
					<a href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">
						<img src="${pageContext.request.contextPath}/uploads/${p.image}" class="card-img-top" style="height:160px;object-fit:cover;" alt="${p.name}" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'">
					</a>
					<div class="card-body d-flex flex-column">
						<h6 class="card-title">
							<a class="text-decoration-none text-dark" href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">${p.name}</a>
						</h6>
						<p class="card-text text-danger fw-bold mt-auto"><fmt:formatNumber value="${p.displayPrice}" pattern="#,###"/> đ</p>
						<form action="${pageContext.request.contextPath}/gio-hang" method="post">
							<input type="hidden" name="action" value="add">
							<input type="hidden" name="productId" value="${p.id}">
							<input type="hidden" name="quantity" value="1">
							<button class="btn btn-sm btn-outline-primary w-100" type="submit" ${p.quantity <= 0 ? 'disabled' : ''}><i class="fa fa-cart-plus"></i> Thêm vào giỏ</button>
						</form>
					</div>
				</div>
			</div>
		</c:forEach>
	</div>
</c:otherwise>
</c:choose>

<jsp:include page="/views/common/footer.jsp"/>
