<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Quản lý nhân viên" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="d-flex justify-content-between align-items-center mb-4">
	<h4 class="mb-0"><i class="fa fa-users"></i> Quản lý nhân viên</h4>
	<a href="${pageContext.request.contextPath}/manager/staff/add" class="btn btn-primary"><i class="fa fa-plus"></i> Thêm nhân viên</a>
</div>

<c:if test="${param.success == 'true'}"><div class="alert alert-success">Thao tác thành công!</div></c:if>
<c:if test="${param.error == 'false'}"><div class="alert alert-danger">Thao tác thất bại, vui lòng thử lại!</div></c:if>

<form action="${pageContext.request.contextPath}/manager/staff" method="get" class="row g-2 mb-3">
	<div class="col-md-5">
		<input type="text" class="form-control" name="keyword" placeholder="Tìm theo tên, email hoặc số điện thoại..." value="${keyword}">
	</div>
	<div class="col-md-2">
		<button type="submit" class="btn btn-outline-primary w-100"><i class="fa fa-search"></i> Tìm</button>
	</div>
</form>

<div class="table-responsive">
	<table class="table align-middle">
		<thead>
			<tr>
				<th>Họ và tên</th>
				<th>Email</th>
				<th>Điện thoại</th>
				<th class="text-center">Trạng thái</th>
				<th class="text-end">Thao tác</th>
			</tr>
		</thead>
		<tbody>
			<c:forEach items="${staffList}" var="s">
				<tr>
					<td>${s.fullName}</td>
					<td>${s.email}</td>
					<td>${s.phone}</td>
					<td class="text-center">
						<c:choose>
							<c:when test="${s.active}"><span class="badge bg-success">Hoạt động</span></c:when>
							<c:otherwise><span class="badge bg-secondary">Đã khóa</span></c:otherwise>
						</c:choose>
					</td>
					<td class="text-end">
						<a href="${pageContext.request.contextPath}/manager/bills?userId=${s.id}" class="btn btn-sm btn-outline-secondary" title="Lịch sử mua hàng"><i class="fa fa-history"></i></a>
						<a href="${pageContext.request.contextPath}/manager/staff/edit?userId=${s.id}" class="btn btn-sm btn-outline-primary"><i class="fa fa-edit"></i></a>
						<form action="${pageContext.request.contextPath}/manager/staff/update-status" method="post" class="d-inline">
							<input type="hidden" name="userId" value="${s.id}">
							<input type="hidden" name="status" value="${s.active ? 0 : 1}">
							<button type="submit" class="btn btn-sm ${s.active ? 'btn-outline-danger' : 'btn-outline-success'}" onclick="return confirm('${s.active ? 'Khóa' : 'Mở khóa'} tài khoản này?');">
								<i class="fa ${s.active ? 'fa-lock' : 'fa-unlock'}"></i>
							</button>
						</form>
						<form action="${pageContext.request.contextPath}/manager/staff/delete" method="post" class="d-inline">
							<input type="hidden" name="userId" value="${s.id}">
							<button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa tài khoản này? Nếu đã có đơn hàng, tài khoản sẽ chỉ bị khóa để giữ lịch sử mua hàng.');">
								<i class="fa fa-trash"></i>
							</button>
						</form>
					</td>
				</tr>
			</c:forEach>
			<c:if test="${empty staffList}">
				<tr><td colspan="5" class="text-center text-muted">Chưa có tài khoản nào.</td></tr>
			</c:if>
		</tbody>
	</table>
</div>

<jsp:include page="/views/common/footer.jsp"/>
