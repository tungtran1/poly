<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="${not empty staff && not empty staff.id ? 'Cập nhật nhân viên' : 'Thêm nhân viên'}" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<c:set var="isEdit" value="${not empty param.userId || (not empty staff && not empty staff.id)}"/>

<h4 class="mb-4">${isEdit ? 'Cập nhật nhân viên' : 'Thêm nhân viên mới'}</h4>

<div class="row justify-content-center">
	<div class="col-md-6">
		<div class="card p-4">
			<form action="${pageContext.request.contextPath}/manager/staff/${isEdit ? 'edit' : 'add'}" method="post">
				<c:if test="${isEdit}">
					<input type="hidden" name="userId" value="${staff.id}">
				</c:if>

				<div class="mb-3">
					<label class="form-label">Họ và tên</label>
					<input type="text" class="form-control ${not empty fullNameError ? 'is-invalid' : ''}" name="fullName" value="${staff.fullName}">
					<c:if test="${not empty fullNameError}"><div class="invalid-feedback">${fullNameError}</div></c:if>
				</div>

				<div class="mb-3">
					<label class="form-label">Email</label>
					<input type="email" class="form-control ${not empty emailError ? 'is-invalid' : ''}" name="email" value="${staff.email}">
					<c:if test="${not empty emailError}"><div class="invalid-feedback">${emailError}</div></c:if>
				</div>

				<div class="mb-3">
					<label class="form-label">Số điện thoại</label>
					<input type="text" class="form-control ${not empty phoneError ? 'is-invalid' : ''}" name="phone" value="${staff.phone}">
					<c:if test="${not empty phoneError}"><div class="invalid-feedback">${phoneError}</div></c:if>
				</div>

				<div class="mb-3">
					<label class="form-label">Mật khẩu ${isEdit ? '(bỏ trống nếu không đổi)' : ''}</label>
					<input type="password" class="form-control ${not empty passwordError ? 'is-invalid' : ''}" name="password">
					<c:if test="${not empty passwordError}"><div class="invalid-feedback">${passwordError}</div></c:if>
				</div>

				<div class="mb-3 form-check">
					<input type="checkbox" class="form-check-input" name="active" value="1" id="activeCheck" ${staff.active || empty staff ? 'checked' : ''}>
					<label class="form-check-label" for="activeCheck">Hoạt động</label>
				</div>

				<button type="submit" class="btn btn-primary w-100">${isEdit ? 'Cập nhật' : 'Thêm mới'}</button>
				<a href="${pageContext.request.contextPath}/manager/staff" class="btn btn-outline-secondary w-100 mt-2">Hủy</a>
			</form>
		</div>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
