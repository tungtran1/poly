<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<c:set var="pageTitle" value="Quản lý loại phụ kiện" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<h4 class="mb-4"><i class="fa fa-tags"></i> Quản lý loại phụ kiện</h4>

<c:if test="${not empty message}"><div class="alert alert-success">${message}</div></c:if>
<c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>

<div class="row g-4">
	<div class="col-md-4">
		<div class="card p-3">
			<h6>${not empty category ? 'Cập nhật loại phụ kiện' : 'Thêm loại phụ kiện mới'}</h6>
			<form action="${pageContext.request.contextPath}/manager/categories/${not empty category ? 'edit' : 'add'}" method="post">
				<c:if test="${not empty category}">
					<input type="hidden" name="id" value="${category.id}">
				</c:if>
				<div class="mb-3">
					<label class="form-label">Tên loại phụ kiện</label>
					<input type="text" class="form-control" name="name" value="${category.name}" required>
				</div>
				<button type="submit" class="btn btn-primary w-100">${not empty category ? 'Cập nhật' : 'Thêm mới'}</button>
				<c:if test="${not empty category}">
					<a href="${pageContext.request.contextPath}/manager/categories" class="btn btn-outline-secondary w-100 mt-2">Hủy</a>
				</c:if>
			</form>
		</div>
	</div>
	<div class="col-md-8">
		<table class="table align-middle">
			<thead>
				<tr>
					<th>#</th>
					<th>Tên loại phụ kiện</th>
					<th class="text-center">Trạng thái</th>
					<th class="text-end">Thao tác</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${list}" var="c" varStatus="st">
					<tr>
						<td>${st.index + 1}</td>
						<td>${c.name}</td>
						<td class="text-center">
							<c:choose>
								<c:when test="${c.active}"><span class="badge bg-success">Đang hoạt động</span></c:when>
								<c:otherwise><span class="badge bg-secondary">Đã ẩn</span></c:otherwise>
							</c:choose>
						</td>
						<td class="text-end">
							<a href="${pageContext.request.contextPath}/manager/categories?id=${c.id}" class="btn btn-sm btn-outline-primary"><i class="fa fa-edit"></i></a>
							<form action="${pageContext.request.contextPath}/manager/categories/delete" method="post" class="d-inline">
								<input type="hidden" name="id" value="${c.id}">
								<button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa/ẩn loại phụ kiện này?');"><i class="fa fa-trash"></i></button>
							</form>
						</td>
					</tr>
				</c:forEach>
				<c:if test="${empty list}">
					<tr><td colspan="4" class="text-center text-muted">Chưa có loại phụ kiện nào.</td></tr>
				</c:if>
			</tbody>
		</table>
	</div>
</div>

<jsp:include page="/views/common/footer.jsp"/>
