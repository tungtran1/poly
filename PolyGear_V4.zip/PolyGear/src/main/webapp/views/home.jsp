<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<c:set var="pageTitle" value="Trang chủ" scope="request"/>
<jsp:include page="/views/common/header.jsp"/>

<div class="p-5 mb-4 rounded-3 text-center text-white" style="background:linear-gradient(135deg,#0d6efd,#6610f2);">
	<h1 class="display-6 fw-bold">PolyGear</h1>
	<p class="col-md-8 mx-auto">Cửa hàng phụ kiện điện thoại: ốp lưng, cáp sạc, sạc dự phòng, tai nghe, kính cường lực, giá đỡ...</p>
	<a href="${pageContext.request.contextPath}/san-pham" class="btn btn-light fw-bold">Xem tất cả phụ kiện</a>
</div>

<c:if test="${not empty flashSaleProducts}">
	<div class="d-flex justify-content-between align-items-center mb-3">
		<h4 class="mb-0"><i class="fa fa-bolt text-danger"></i> Flash Sale hôm nay</h4>
		<span class="badge bg-danger">Giá sốc - số lượng có hạn</span>
	</div>
	<div class="row g-3 mb-5">
		<c:forEach items="${flashSaleProducts}" var="p">
			<div class="col-6 col-md-3">
				<div class="card h-100 border-danger position-relative">
					<span class="badge bg-danger position-absolute top-0 start-0 m-1">Flash Sale</span>
					<a href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">
						<img src="${pageContext.request.contextPath}/uploads/${p.image}" class="card-img-top" style="height:160px;object-fit:cover;" alt="${p.name}" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'">
					</a>
					<div class="card-body d-flex flex-column">
						<h6 class="card-title">
							<a class="text-decoration-none text-dark" href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">${p.name}</a>
						</h6>
						<p class="card-text mb-1">
							<span class="text-danger fw-bold"><fmt:formatNumber value="${p.discountPrice}" pattern="#,###"/> đ</span>
							<del class="text-muted small ms-1"><fmt:formatNumber value="${p.price}" pattern="#,###"/> đ</del>
						</p>
						<form action="${pageContext.request.contextPath}/gio-hang" method="post" class="mt-auto">
							<input type="hidden" name="action" value="add">
							<input type="hidden" name="productId" value="${p.id}">
							<input type="hidden" name="quantity" value="1">
							<button class="btn btn-sm btn-danger w-100" type="submit"><i class="fa fa-bolt"></i> Mua ngay</button>
						</form>
					</div>
				</div>
			</div>
		</c:forEach>
	</div>
</c:if>

<h4 class="mb-3">Chọn theo loại phụ kiện</h4>
<div class="row g-2 mb-5">
	<c:forEach items="${categories}" var="cat">
		<div class="col-6 col-md-2">
			<a href="${pageContext.request.contextPath}/san-pham?categoryId=${cat.id}" class="btn btn-outline-secondary w-100 h-100">${cat.name}</a>
		</div>
	</c:forEach>
	<c:if test="${empty categories}">
		<div class="col-12 text-muted">Chưa có loại phụ kiện nào.</div>
	</c:if>
</div>

<div class="d-flex justify-content-between align-items-center mb-3">
	<h4 class="mb-0">Sản phẩm nổi bật</h4>
	<a href="${pageContext.request.contextPath}/san-pham" class="small">Xem tất cả &raquo;</a>
</div>
<div class="row g-3">
	<c:forEach items="${featuredProducts}" var="p" begin="0" end="7">
		<div class="col-6 col-md-3">
			<div class="card h-100">
				<a href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">
					<img src="${pageContext.request.contextPath}/uploads/${p.image}" class="card-img-top" style="height:160px;object-fit:cover;" alt="${p.name}" onerror="this.src='${pageContext.request.contextPath}/images/logo.png'">
				</a>
				<div class="card-body d-flex flex-column">
					<h6 class="card-title">
						<a class="text-decoration-none text-dark" href="${pageContext.request.contextPath}/san-pham/chi-tiet?id=${p.id}">${p.name}</a>
					</h6>
					<p class="card-text text-danger fw-bold mt-auto"><fmt:formatNumber value="${p.displayPrice}" pattern="#,###"/> đ</p>
					<form action="${pageContext.request.contextPath}/gio-hang" method="post">
						<input type="hidden" name="action" value="add">
						<input type="hidden" name="productId" value="${p.id}">
						<input type="hidden" name="quantity" value="1">
						<button class="btn btn-sm btn-outline-primary w-100" type="submit"><i class="fa fa-cart-plus"></i> Thêm vào giỏ</button>
					</form>
				</div>
			</div>
		</div>
	</c:forEach>
	<c:if test="${empty featuredProducts}">
		<div class="col-12 text-muted">Chưa có sản phẩm nào.</div>
	</c:if>
</div>

<jsp:include page="/views/common/footer.jsp"/>
