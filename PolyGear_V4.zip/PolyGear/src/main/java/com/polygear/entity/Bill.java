package com.polygear.entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Bill {
	Integer id;
	Integer userId;
	String code;
	Date createdAt;
	int total;
	String status;
	// waiting, preparing, shipping, delivered, cancel
	String receiverName;
	String receiverPhone;
	String receiverAddress;
	String voucherCode;
	int discountAmount;
	String shippingMethod;
	int shippingFee;

	public Bill(Integer id, Integer userId, String code, Date createdAt, int total, String status) {
		this.id = id;
		this.userId = userId;
		this.code = code;
		this.createdAt = createdAt;
		this.total = total;
		this.status = status;
	}
}
