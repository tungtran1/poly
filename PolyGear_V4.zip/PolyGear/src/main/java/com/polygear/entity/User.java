package com.polygear.entity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	public static final int ROLE_CUSTOMER = 0; // Khach hang
	public static final int ROLE_ADMIN = 1; // Quan tri vien - toan quyen
	public static final int ROLE_STAFF = 2; // Nhan vien - quyen han che (xu ly don hang, san pham)

	private Integer id;
	private String email;
	private String password;
	private String fullName;
	private String phone;
	private int role; // 0 = khach hang, 1 = quan tri vien, 2 = nhan vien
	private boolean active;
	private String resetToken;
	private Long resetTokenExpiry; // epoch millis

	public User(Integer id, String email, String password, String fullName, String phone, int role,
			boolean active) {
		this.id = id;
		this.email = email;
		this.password = password;
		this.fullName = fullName;
		this.phone = phone;
		this.role = role;
		this.active = active;
	}

	public boolean isAdmin() {
		return role == ROLE_ADMIN;
	}

	public boolean isStaff() {
		return role == ROLE_STAFF;
	}

	public boolean isCustomer() {
		return role == ROLE_CUSTOMER;
	}

	// Co the vao khu vuc quan tri (Admin hoac Nhan vien)
	public boolean isManager() {
		return role == ROLE_ADMIN || role == ROLE_STAFF;
	}
}
