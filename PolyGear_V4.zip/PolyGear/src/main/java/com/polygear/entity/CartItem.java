package com.polygear.entity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Một dòng trong giỏ hàng (luu trong session, khong luu DB).
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CartItem implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer productId;
	private String name;
	private String image;
	private int price;
	private int quantity;

	public long getSubtotal() {
		return (long) price * quantity;
	}
}
