package com.polygear.entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Review {
	Integer id;
	Integer productId;
	Integer userId;
	int rating; // 1-5 sao
	String comment;
	Date createdAt;

	// Bo sung khi join voi bang users de hien thi ten nguoi danh gia
	String userFullName;
}
