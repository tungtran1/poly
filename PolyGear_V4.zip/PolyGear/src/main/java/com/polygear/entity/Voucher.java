package com.polygear.entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Voucher {
	Integer id;
	String code;
	String description;
	Integer discountPercent; // giam theo %, null neu dung discountAmount
	Integer discountAmount; // giam so tien co dinh, null neu dung discountPercent
	int minOrderValue;
	Integer maxDiscount; // gioi han so tien giam toi da khi dung %
	int quantity; // so luong con lai
	int usedCount;
	Date startDate;
	Date endDate;
	boolean active;

	// Tinh so tien duoc giam cho 1 don hang co tong tien la orderTotal
	public int calculateDiscount(long orderTotal) {
		if (orderTotal < minOrderValue) {
			return 0;
		}
		int discount = 0;
		if (discountPercent != null && discountPercent > 0) {
			discount = (int) (orderTotal * discountPercent / 100);
			if (maxDiscount != null && discount > maxDiscount) {
				discount = maxDiscount;
			}
		} else if (discountAmount != null && discountAmount > 0) {
			discount = discountAmount;
		}
		return (int) Math.min(discount, orderTotal);
	}

	public boolean isUsable() {
		if (!active || quantity - usedCount <= 0) {
			return false;
		}
		Date now = new Date();
		if (startDate != null && now.before(startDate)) {
			return false;
		}
		if (endDate != null && now.after(endDate)) {
			return false;
		}
		return true;
	}
}
