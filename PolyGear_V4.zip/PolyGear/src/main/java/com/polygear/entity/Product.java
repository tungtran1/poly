package com.polygear.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Product {
	Integer id;
	Integer categoryId;
	Integer brandId;
	String name;
	String description;
	String image;
	int price;
	int quantity;
	boolean active;
	Integer discountPrice; // gia flash sale, null neu khong giam gia
	boolean flashSale; // co dang hien thi o khu Flash Sale trang chu khong

	// Gia hien thi thuc te cho khach hang (uu tien gia flash sale neu dang bat)
	public int getDisplayPrice() {
		if (flashSale && discountPrice != null && discountPrice > 0 && discountPrice < price) {
			return discountPrice;
		}
		return price;
	}

	public boolean isOnSale() {
		return flashSale && discountPrice != null && discountPrice > 0 && discountPrice < price;
	}

	public Product(Integer id, Integer categoryId, String name, String description, String image, int price,
			boolean active) {
		this.id = id;
		this.categoryId = categoryId;
		this.name = name;
		this.description = description;
		this.image = image;
		this.price = price;
		this.active = active;
	}
}

