package com.polygear.entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Wishlist {
	Integer id;
	Integer userId;
	Integer productId;
	Date createdAt;
}
