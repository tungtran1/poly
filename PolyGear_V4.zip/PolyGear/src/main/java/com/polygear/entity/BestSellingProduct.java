package com.polygear.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class BestSellingProduct {
	private int productId;
	private String productName;
	private int totalQuantitySold;
	private long totalRevenue;

}
