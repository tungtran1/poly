package com.polygear.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.http.HttpServletRequest;

public class ParamUtil {
	// Tra ve gia tri kieu String (da trim, null neu khong co)
	public static String getString(HttpServletRequest request, String name) {
		try {
			String value = request.getParameter(name);
			return value == null ? null : value.trim();
		} catch (Exception e) {
			return null;
		}
	}

	// Tra ve gia tri kieu int (0 neu khong hop le)
	public static int getInt(HttpServletRequest request, String name) {
		try {
			return Integer.parseInt(request.getParameter(name).trim());
		} catch (Exception e) {
			return 0;
		}
	}

	// Tra ve gia tri kieu long (0 neu khong hop le)
	public static long getLong(HttpServletRequest request, String name) {
		try {
			return Long.parseLong(request.getParameter(name).trim());
		} catch (Exception e) {
			return 0L;
		}
	}

	// Tra ve gia tri kieu Date
	public static Date getDate(HttpServletRequest request, String name, String pattern) {
		try {
			String value = request.getParameter(name);
			SimpleDateFormat sdf = new SimpleDateFormat(pattern);
			return sdf.parse(value);
		} catch (Exception e) {
			return null;
		}
	}
}
