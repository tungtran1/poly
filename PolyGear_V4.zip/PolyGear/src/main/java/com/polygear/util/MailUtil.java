package com.polygear.util;

import java.io.InputStream;
import java.util.Properties;

import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

/**
 * Gui email qua SMTP (dung cho chuc nang "Quen mat khau").
 *
 * Cau hinh trong file: src/main/resources/mail.properties
 *   mail.smtp.host=smtp.gmail.com
 *   mail.smtp.port=587
 *   mail.username=your-email@gmail.com
 *   mail.password=your-app-password
 *
 * Neu chua cau hinh (hoac gui that bai vi thieu SMTP that), ham send() se
 * tra ve false thay vi nem loi 500 -> ForgotPasswordServlet se hien thi
 * link dat lai mat khau truc tiep tren man hinh de vẫn dùng được (demo/offline).
 */
public class MailUtil {

	private static Properties config;

	private static synchronized Properties loadConfig() {
		if (config != null) {
			return config;
		}
		Properties props = new Properties();
		try (InputStream in = MailUtil.class.getClassLoader().getResourceAsStream("mail.properties")) {
			if (in != null) {
				props.load(in);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		config = props;
		return config;
	}

	public static boolean send(String toEmail, String subject, String htmlContent) {
		Properties cfg = loadConfig();
		String host = cfg.getProperty("mail.smtp.host", "").trim();
		String username = cfg.getProperty("mail.username", "").trim();
		String password = cfg.getProperty("mail.password", "").trim();
		String port = cfg.getProperty("mail.smtp.port", "587").trim();

		if (host.isEmpty() || username.isEmpty() || password.isEmpty()) {
			// Chua cau hinh SMTP that -> khong gui duoc, de servlet tu xu ly phuong an du phong
			return false;
		}

		try {
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.port", port);

			Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});

			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username, "PolyGear"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
			message.setSubject(subject, "UTF-8");
			message.setContent(htmlContent, "text/html; charset=UTF-8");

			Transport.send(message);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
