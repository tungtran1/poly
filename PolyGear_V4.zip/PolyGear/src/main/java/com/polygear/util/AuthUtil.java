package com.polygear.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.polygear.entity.User;

public class AuthUtil {
	public static final String SESSION_USER = "user";

	// Luu thong tin user dang nhap
	public static void setUser(HttpServletRequest request, User user) {
		HttpSession session = request.getSession();
		session.setAttribute(SESSION_USER, user);
	}

	// Lay thong tin user dang nhap
	public static User getUser(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session == null)
			return null;
		return (User) session.getAttribute(SESSION_USER);
	}

	// Da dang nhap chua?
	public static boolean isAuthenticated(HttpServletRequest request) {
		return getUser(request) != null;
	}

	// Kiem tra co the vao khu vuc quan tri hay khong (Admin hoac Nhan vien)
	public static boolean isManager(HttpServletRequest request) {
		User u = getUser(request);
		return u != null && u.isManager();
	}

	// Kiem tra quyen quan tri vien toan quyen (khong bao gom nhan vien)
	public static boolean isAdmin(HttpServletRequest request) {
		User u = getUser(request);
		return u != null && u.isAdmin();
	}

	// Kiem tra la nhan vien (quyen han che)
	public static boolean isStaff(HttpServletRequest request) {
		User u = getUser(request);
		return u != null && u.isStaff();
	}

	// Xoa thong tin dang nhap
	public static void clear(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.removeAttribute(SESSION_USER);
		}
	}
}
