package com.polygear.util;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Danh sach cac phuong thuc / don vi giao hang va phi van chuyen tuong ung.
 * Phi luon duoc tra ve tu server (khong tin gia tri client gui len) de tranh
 * khach hang sua phi van chuyen tren trinh duyet.
 */
public class ShippingUtil {

	// key = ma phuong thuc luu trong DB, value = { nhan hien thi, phi (VND) }
	private static final Map<String, Object[]> METHODS = new LinkedHashMap<>();
	static {
		METHODS.put("store_pickup", new Object[] { "Nhận tại cửa hàng (miễn phí)", 0 });
		METHODS.put("standard", new Object[] { "Giao hàng tiêu chuẩn - Giao Hàng Tiết Kiệm (3-5 ngày)", 20000 });
		METHODS.put("express", new Object[] { "Giao hàng nhanh - Giao Hàng Nhanh (1-2 ngày)", 35000 });
	}

	public static Map<String, Object[]> getAllMethods() {
		return METHODS;
	}

	public static boolean isValid(String code) {
		return code != null && METHODS.containsKey(code);
	}

	public static String getLabel(String code) {
		Object[] info = METHODS.get(code);
		return info == null ? code : (String) info[0];
	}

	public static int getFee(String code) {
		Object[] info = METHODS.get(code);
		return info == null ? 0 : (int) info[1];
	}
}
