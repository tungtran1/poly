package com.polygear.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.Part;

public class FileUtil {
	private static final String FOLDER = "/uploads/";

	// Upload file vao thu muc /uploads, tra ve ten file duy nhat da luu
	public static String upload(HttpServletRequest request, String name) throws IOException {
		try {
			Part part = request.getPart(name);
			if (part == null || part.getSize() == 0) {
				return null;
			}
			String fileName = part.getSubmittedFileName();
			if (fileName == null || fileName.isEmpty()) {
				return null;
			}
			String ext = fileName.contains(".") ? fileName.substring(fileName.lastIndexOf(".")) : "";
			String uniqueName = System.currentTimeMillis() + ext;

			String realPath = request.getServletContext().getRealPath(FOLDER);
			Path folderPath = Path.of(realPath);
			// SUA LOI: truoc day code tao thu muc trung voi duong dan file (realPath + uniqueName)
			// khien viec upload luon that bai. Bay gio tao dung THU MUC CHA truoc khi ghi file.
			if (!Files.exists(folderPath)) {
				Files.createDirectories(folderPath);
			}

			File dest = new File(folderPath.toFile(), uniqueName);
			part.write(dest.getAbsolutePath());
			return uniqueName;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// Xoa file trong /uploads
	public static boolean delete(HttpServletRequest request, String fileName) {
		try {
			if (fileName == null || fileName.isEmpty())
				return false;
			String realPath = request.getServletContext().getRealPath(FOLDER);
			File file = new File(realPath, fileName);
			return file.exists() && file.isFile() && file.delete();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
