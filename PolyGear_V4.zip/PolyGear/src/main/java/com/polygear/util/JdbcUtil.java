package com.polygear.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class JdbcUtil {
	// Cau hinh ket noi SQL Server - chinh lai cho dung moi truong cua ban
	static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	static String dburl = "jdbc:sqlserver://localhost:1433;databaseName=polygear;encrypt=false";
	static String username = "sa";
	static String password = "123456";

	// Nap driver
	static {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	/** Mo ket noi */
	private static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(dburl, username, password);
	}

	/**
	 * Tao PreparedStatement de lam viec voi SQL hoac PROC
	 */
	public static PreparedStatement createPreStmt(String sql, Object... values) throws SQLException {
		Connection connection = getConnection();
		PreparedStatement stmt;

		if (sql.trim().startsWith("{")) {
			stmt = connection.prepareCall(sql);
		} else {
			stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		}

		for (int i = 0; i < values.length; i++) {
			if (values[i] == null) {
				stmt.setNull(i + 1, Types.NULL);
			} else {
				stmt.setObject(i + 1, values[i]);
			}
		}
		return stmt;
	}

	/** Thao tac du lieu (insert/update/delete) - tra ve so dong bi anh huong */
	public static int executeUpdate(String sql, Object... values) throws SQLException {
		try (PreparedStatement stmt = JdbcUtil.createPreStmt(sql, values)) {
			return stmt.executeUpdate();
		}
	}

	/**
	 * Thao tac insert va tra ve ID vua duoc sinh (identity) thay vi so dong bi
	 * anh huong. Dung cho cac bang can lay lai id sau khi them moi.
	 */
	public static int executeInsertAndGetId(String sql, Object... values) throws SQLException {
		try (PreparedStatement stmt = JdbcUtil.createPreStmt(sql, values)) {
			int affected = stmt.executeUpdate();
			if (affected > 0) {
				try (ResultSet keys = stmt.getGeneratedKeys()) {
					if (keys.next()) {
						return keys.getInt(1);
					}
				}
			}
			return 0;
		}
	}

	/** Truy van du lieu (select) */
	public static ResultSet executeQuery(String sql, Object... values) throws SQLException {
		PreparedStatement stmt = JdbcUtil.createPreStmt(sql, values);
		return stmt.executeQuery();
	}
}
