package com.polygear.util;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebFilter({ "/manager/*", "/thanh-toan", "/don-hang", "/hoa-don", "/edit-profile", "/change-pass", "/yeu-thich",
		"/yeu-thich/toggle", "/san-pham/danh-gia" })
public class AuthFilter implements Filter {
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		String uriString = req.getRequestURI();
		String error = "";

		// Cac khu vuc chi Quan tri vien (Admin) duoc vao, Nhan vien KHONG duoc vao.
		// Nhan vien chi con duoc vao "/manager/bills" (xu ly don hang) va
		// "/manager/customers" (xem thong tin khach hang de ho tro don hang).
		String[] adminOnlyPaths = { "/manager/vouchers", "/manager/staff", "/manager/categories", "/manager/brands",
				"/manager/products", "/manager/dashboard" };

		if (!AuthUtil.isAuthenticated(req)) {
			error = "401";
		} else if (!AuthUtil.isManager(req) && uriString.contains("/manager")) {
			error = "403";
		} else if (uriString.contains("/manager") && !AuthUtil.isAdmin(req)) {
			for (String adminOnlyPath : adminOnlyPaths) {
				if (uriString.contains(adminOnlyPath)) {
					error = "403";
					break;
				}
			}
		}

		if ("401".equals(error)) {
			req.getSession().setAttribute("REDIRECT_URL", uriString);
			res.sendRedirect(req.getContextPath() + "/dang-nhap");
			return;
		}
		if ("403".equals(error)) {
			req.getRequestDispatcher("/views/error/403.jsp").forward(req, res);
			return;
		}

		chain.doFilter(req, res);
	}
}
