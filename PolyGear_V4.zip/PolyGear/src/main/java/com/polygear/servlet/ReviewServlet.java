package com.polygear.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.ReviewDAO;
import com.polygear.entity.Review;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

/**
 * Nhan danh gia / binh luan san pham tu khach hang. Chi cho phep khach hang
 * da mua va nhan hang (bill status = delivered) danh gia, va moi khach hang
 * chi danh gia 1 lan cho 1 san pham.
 */
@WebServlet("/san-pham/danh-gia")
public class ReviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ReviewDAO reviewDAO = new ReviewDAO();

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = AuthUtil.getUser(request);
		int productId = ParamUtil.getInt(request, "productId");
		int rating = ParamUtil.getInt(request, "rating");
		String comment = ParamUtil.getString(request, "comment");

		String redirectUrl = request.getContextPath() + "/san-pham/chi-tiet?id=" + productId;

		if (productId <= 0 || rating < 1 || rating > 5) {
			response.sendRedirect(redirectUrl + "&reviewError=invalid");
			return;
		}
		if (!reviewDAO.hasPurchased(user.getId(), productId)) {
			response.sendRedirect(redirectUrl + "&reviewError=notpurchased");
			return;
		}
		if (reviewDAO.hasReviewed(user.getId(), productId)) {
			response.sendRedirect(redirectUrl + "&reviewError=alreadyreviewed");
			return;
		}

		Review review = new Review();
		review.setProductId(productId);
		review.setUserId(user.getId());
		review.setRating(rating);
		review.setComment(comment);
		reviewDAO.create(review);

		response.sendRedirect(redirectUrl + "&reviewSuccess=true");
	}
}
