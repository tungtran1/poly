package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.VoucherDAO;
import com.polygear.entity.Voucher;
import com.polygear.util.ParamUtil;

/**
 * Quan ly ma giam gia (voucher/coupon) danh cho quan tri vien.
 */
@WebServlet({ "/manager/vouchers", "/manager/vouchers/add", "/manager/vouchers/edit",
		"/manager/vouchers/delete" })
public class VoucherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VoucherDAO voucherDAO = new VoucherDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();

		if (path.equals("/manager/vouchers/add")) {
			request.getRequestDispatcher("/views/manager/vouchers/form.jsp").forward(request, response);
			return;
		}
		if (path.equals("/manager/vouchers/edit")) {
			int id = ParamUtil.getInt(request, "id");
			Voucher voucher = voucherDAO.findById(id);
			if (voucher == null) {
				response.sendRedirect(request.getContextPath() + "/manager/vouchers?error=notfound");
				return;
			}
			request.setAttribute("voucher", voucher);
			request.getRequestDispatcher("/views/manager/vouchers/form.jsp").forward(request, response);
			return;
		}

		List<Voucher> list = voucherDAO.findAll();
		request.setAttribute("vouchers", list);
		request.getRequestDispatcher("/views/manager/vouchers/list.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		if (path.equals("/manager/vouchers/add")) {
			create(request, response);
		} else if (path.equals("/manager/vouchers/edit")) {
			edit(request, response);
		} else if (path.equals("/manager/vouchers/delete")) {
			delete(request, response);
		}
	}

	private Voucher buildFromRequest(HttpServletRequest request) {
		String code = ParamUtil.getString(request, "code");
		String description = ParamUtil.getString(request, "description");
		String discountType = ParamUtil.getString(request, "discountType"); // "percent" hoac "amount"
		int discountValue = ParamUtil.getInt(request, "discountValue");
		int minOrderValue = ParamUtil.getInt(request, "minOrderValue");
		int maxDiscount = ParamUtil.getInt(request, "maxDiscount");
		int quantity = ParamUtil.getInt(request, "quantity");
		int active = ParamUtil.getInt(request, "active");

		Voucher voucher = new Voucher();
		voucher.setCode(code);
		voucher.setDescription(description);
		if ("percent".equals(discountType)) {
			voucher.setDiscountPercent(discountValue);
			voucher.setDiscountAmount(null);
			voucher.setMaxDiscount(maxDiscount > 0 ? maxDiscount : null);
		} else {
			voucher.setDiscountAmount(discountValue);
			voucher.setDiscountPercent(null);
			voucher.setMaxDiscount(null);
		}
		voucher.setMinOrderValue(Math.max(minOrderValue, 0));
		voucher.setQuantity(Math.max(quantity, 0));
		voucher.setActive(active == 1);
		return voucher;
	}

	private void create(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String code = ParamUtil.getString(request, "code");
		int discountValue = ParamUtil.getInt(request, "discountValue");

		boolean hasError = false;
		if (code == null || code.isBlank()) {
			request.setAttribute("errCode", "Vui lòng nhập mã giảm giá");
			hasError = true;
		} else if (voucherDAO.codeExists(code)) {
			request.setAttribute("errCode", "Mã giảm giá này đã tồn tại");
			hasError = true;
		}
		if (discountValue <= 0) {
			request.setAttribute("errValue", "Giá trị giảm giá phải lớn hơn 0");
			hasError = true;
		}

		if (hasError) {
			request.setAttribute("voucher", buildFromRequest(request));
			request.getRequestDispatcher("/views/manager/vouchers/form.jsp").forward(request, response);
			return;
		}

		Voucher voucher = buildFromRequest(request);
		int rs = voucherDAO.create(voucher);
		if (rs > 0) {
			response.sendRedirect(request.getContextPath() + "/manager/vouchers?success=true");
		} else {
			response.sendRedirect(request.getContextPath() + "/manager/vouchers?error=true");
		}
	}

	private void edit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = ParamUtil.getInt(request, "id");
		String code = ParamUtil.getString(request, "code");
		int discountValue = ParamUtil.getInt(request, "discountValue");

		boolean hasError = false;
		if (code == null || code.isBlank()) {
			request.setAttribute("errCode", "Vui lòng nhập mã giảm giá");
			hasError = true;
		} else {
			Voucher existing = voucherDAO.findByCode(code);
			if (existing != null && !existing.getId().equals(id)) {
				request.setAttribute("errCode", "Mã giảm giá này đã tồn tại");
				hasError = true;
			}
		}
		if (discountValue <= 0) {
			request.setAttribute("errValue", "Giá trị giảm giá phải lớn hơn 0");
			hasError = true;
		}

		if (hasError) {
			Voucher voucher = buildFromRequest(request);
			voucher.setId(id);
			request.setAttribute("voucher", voucher);
			request.getRequestDispatcher("/views/manager/vouchers/form.jsp").forward(request, response);
			return;
		}

		Voucher voucher = buildFromRequest(request);
		voucher.setId(id);
		int rs = voucherDAO.update(voucher);
		if (rs > 0) {
			response.sendRedirect(request.getContextPath() + "/manager/vouchers?success=true");
		} else {
			response.sendRedirect(request.getContextPath() + "/manager/vouchers?error=true");
		}
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = ParamUtil.getInt(request, "id");
		voucherDAO.delete(id);
		response.sendRedirect(request.getContextPath() + "/manager/vouchers?success=true");
	}
}
