package com.polygear.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.UserDAO;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

@WebServlet("/dang-nhap")
public class AuthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/views/auth/login.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String email = ParamUtil.getString(request, "email");
		String password = ParamUtil.getString(request, "password");

		User user = (email == null || email.isBlank()) ? null : userDAO.findByEmail(email);

		if (user == null) {
			request.setAttribute("message", "Tài khoản không tồn tại!");
			request.getRequestDispatcher("/views/auth/login.jsp").forward(request, response);
			return;
		}

		if (user.getPassword() == null || !user.getPassword().equals(password)) {
			request.setAttribute("message", "Mật khẩu không chính xác!");
			request.getRequestDispatcher("/views/auth/login.jsp").forward(request, response);
			return;
		}

		if (!user.isActive()) {
			request.setAttribute("message", "Tài khoản đã bị khóa!");
			request.getRequestDispatcher("/views/auth/login.jsp").forward(request, response);
			return;
		}

		AuthUtil.setUser(request, user);
		String redirectUrl = request.getContextPath() + "/trang-chu";
		Object savedRedirect = request.getSession().getAttribute("REDIRECT_URL");
		if (savedRedirect != null) {
			redirectUrl = (String) savedRedirect;
			request.getSession().removeAttribute("REDIRECT_URL");
		}

		response.sendRedirect(redirectUrl);
	}
}
