package com.polygear.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.UserDAO;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

@WebServlet({ "/edit-profile", "/change-pass" })
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		User user = AuthUtil.getUser(request);
		// Lay ban ghi moi nhat tu DB de hien thi chinh xac
		User fresh = userDAO.findById(user.getId());
		request.setAttribute("profile", fresh);

		if ("/change-pass".equals(path)) {
			request.getRequestDispatcher("/views/profile/change-password.jsp").forward(request, response);
		} else {
			request.getRequestDispatcher("/views/profile/edit.jsp").forward(request, response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		User sessionUser = AuthUtil.getUser(request);
		User current = userDAO.findById(sessionUser.getId());

		if ("/change-pass".equals(path)) {
			changePassword(request, response, current);
		} else {
			editProfile(request, response, current);
		}
	}

	private void editProfile(HttpServletRequest request, HttpServletResponse response, User current)
			throws ServletException, IOException {
		String fullName = ParamUtil.getString(request, "fullName");
		String phone = ParamUtil.getString(request, "phone");

		boolean hasError = false;
		if (fullName == null || fullName.isBlank()) {
			request.setAttribute("fullNameError", "Họ và tên không được để trống.");
			hasError = true;
		}
		if (phone == null || !phone.matches("^0\\d{9}$")) {
			request.setAttribute("phoneError", "Số điện thoại không hợp lệ.");
			hasError = true;
		}

		if (hasError) {
			current.setFullName(fullName);
			current.setPhone(phone);
			request.setAttribute("profile", current);
			request.getRequestDispatcher("/views/profile/edit.jsp").forward(request, response);
			return;
		}

		current.setFullName(fullName);
		current.setPhone(phone);
		int rs = userDAO.updateUserInfo(current);
		if (rs > 0) {
			AuthUtil.setUser(request, userDAO.findById(current.getId()));
			request.setAttribute("message", "Cập nhật thông tin thành công.");
		} else {
			request.setAttribute("error", "Cập nhật thất bại, vui lòng thử lại.");
		}
		request.setAttribute("profile", userDAO.findById(current.getId()));
		request.getRequestDispatcher("/views/profile/edit.jsp").forward(request, response);
	}

	private void changePassword(HttpServletRequest request, HttpServletResponse response, User current)
			throws ServletException, IOException {
		String oldPassword = ParamUtil.getString(request, "oldPassword");
		String newPassword = ParamUtil.getString(request, "newPassword");
		String confirmPassword = ParamUtil.getString(request, "confirmPassword");

		if (oldPassword == null || !oldPassword.equals(current.getPassword())) {
			request.setAttribute("error", "Mật khẩu hiện tại không đúng.");
		} else if (newPassword == null || newPassword.length() < 6) {
			request.setAttribute("error", "Mật khẩu mới phải có ít nhất 6 ký tự.");
		} else if (!newPassword.equals(confirmPassword)) {
			request.setAttribute("error", "Mật khẩu nhập lại không khớp.");
		} else {
			int rs = userDAO.updatePassword(current.getId(), newPassword);
			if (rs > 0) {
				AuthUtil.setUser(request, userDAO.findById(current.getId()));
				request.setAttribute("message", "Đổi mật khẩu thành công.");
			} else {
				request.setAttribute("error", "Đổi mật khẩu thất bại, vui lòng thử lại.");
			}
		}
		request.getRequestDispatcher("/views/profile/change-password.jsp").forward(request, response);
	}
}
