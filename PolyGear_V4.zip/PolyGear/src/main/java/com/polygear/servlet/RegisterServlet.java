package com.polygear.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.UserDAO;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

/**
 * Dang ky tai khoan khach hang moi.
 */
@WebServlet("/dang-ky")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/views/auth/register.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = ParamUtil.getString(request, "email");
		String password = ParamUtil.getString(request, "password");
		String confirmPassword = ParamUtil.getString(request, "confirmPassword");
		String fullName = ParamUtil.getString(request, "fullName");
		String phone = ParamUtil.getString(request, "phone");

		boolean hasError = false;

		if (email == null || !email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
			request.setAttribute("emailError", "Email không hợp lệ.");
			hasError = true;
		} else if (userDAO.findByEmail(email) != null) {
			request.setAttribute("emailError", "Email này đã được sử dụng.");
			hasError = true;
		}

		if (password == null || password.length() < 6) {
			request.setAttribute("passwordError", "Mật khẩu phải có ít nhất 6 ký tự.");
			hasError = true;
		} else if (!password.equals(confirmPassword)) {
			request.setAttribute("confirmPasswordError", "Mật khẩu nhập lại không khớp.");
			hasError = true;
		}

		if (fullName == null || fullName.isBlank()) {
			request.setAttribute("fullNameError", "Họ và tên không được để trống.");
			hasError = true;
		}

		if (phone == null || !phone.matches("^0\\d{9}$")) {
			request.setAttribute("phoneError", "Số điện thoại không hợp lệ (10 số, bắt đầu bằng 0).");
			hasError = true;
		}

		if (hasError) {
			request.setAttribute("email", email);
			request.setAttribute("fullName", fullName);
			request.setAttribute("phone", phone);
			request.getRequestDispatcher("/views/auth/register.jsp").forward(request, response);
			return;
		}

		User user = new User();
		user.setEmail(email);
		user.setPassword(password);
		user.setFullName(fullName);
		user.setPhone(phone);
		user.setRole(User.ROLE_CUSTOMER); // khach hang
		user.setActive(true);

		int rs = userDAO.create(user);
		if (rs > 0) {
			User created = userDAO.findByEmail(email);
			AuthUtil.setUser(request, created);
			response.sendRedirect(request.getContextPath() + "/trang-chu");
		} else {
			request.setAttribute("emailError", "Đăng ký thất bại, vui lòng thử lại.");
			request.getRequestDispatcher("/views/auth/register.jsp").forward(request, response);
		}
	}
}
