package com.polygear.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.UserDAO;
import com.polygear.entity.User;
import com.polygear.util.ParamUtil;

@WebServlet("/dat-lai-mat-khau")
public class ResetPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();

	private User validateToken(String token) {
		if (token == null || token.isBlank()) {
			return null;
		}
		User user = userDAO.findByResetToken(token);
		if (user == null || user.getResetTokenExpiry() == null) {
			return null;
		}
		if (System.currentTimeMillis() > user.getResetTokenExpiry()) {
			return null; // het han
		}
		return user;
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String token = ParamUtil.getString(request, "token");
		User user = validateToken(token);

		if (user == null) {
			request.setAttribute("error", "Liên kết đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.");
			request.getRequestDispatcher("/views/auth/reset-password.jsp").forward(request, response);
			return;
		}

		request.setAttribute("token", token);
		request.getRequestDispatcher("/views/auth/reset-password.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String token = ParamUtil.getString(request, "token");
		String password = ParamUtil.getString(request, "password");
		String confirmPassword = ParamUtil.getString(request, "confirmPassword");

		User user = validateToken(token);
		if (user == null) {
			request.setAttribute("error", "Liên kết đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.");
			request.getRequestDispatcher("/views/auth/reset-password.jsp").forward(request, response);
			return;
		}

		if (password == null || password.length() < 6) {
			request.setAttribute("error", "Mật khẩu phải có ít nhất 6 ký tự.");
			request.setAttribute("token", token);
			request.getRequestDispatcher("/views/auth/reset-password.jsp").forward(request, response);
			return;
		}
		if (!password.equals(confirmPassword)) {
			request.setAttribute("error", "Mật khẩu nhập lại không khớp.");
			request.setAttribute("token", token);
			request.getRequestDispatcher("/views/auth/reset-password.jsp").forward(request, response);
			return;
		}

		userDAO.resetPasswordWithToken(user.getId(), password);
		request.setAttribute("success", "Đặt lại mật khẩu thành công! Bạn có thể đăng nhập bằng mật khẩu mới.");
		request.getRequestDispatcher("/views/auth/login.jsp").forward(request, response);
	}
}
