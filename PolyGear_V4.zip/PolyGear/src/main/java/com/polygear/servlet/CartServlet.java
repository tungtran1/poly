package com.polygear.servlet;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.polygear.dao.ProductDAO;
import com.polygear.dao.VoucherDAO;
import com.polygear.entity.CartItem;
import com.polygear.entity.Product;
import com.polygear.entity.Voucher;
import com.polygear.util.ParamUtil;

/**
 * Gio hang duoc luu trong session duoi dang Map&lt;productId, CartItem&gt;.
 * Khong can dang nhap van co the them vao gio; chi can dang nhap khi thanh toan.
 */
@WebServlet("/gio-hang")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String SESSION_CART = "cart";
	public static final String SESSION_VOUCHER = "appliedVoucherCode";

	private ProductDAO productDAO = new ProductDAO();
	private VoucherDAO voucherDAO = new VoucherDAO();

	@SuppressWarnings("unchecked")
	public static Map<Integer, CartItem> getCart(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute(SESSION_CART);
		if (cart == null) {
			cart = new LinkedHashMap<>();
			session.setAttribute(SESSION_CART, cart);
		}
		return cart;
	}

	public static int getCartCount(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session == null) {
			return 0;
		}
		@SuppressWarnings("unchecked")
		Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute(SESSION_CART);
		if (cart == null) {
			return 0;
		}
		int count = 0;
		for (CartItem item : cart.values()) {
			count += item.getQuantity();
		}
		return count;
	}

	// Ma voucher dang duoc ap dung cho gio hang trong session (null neu chua ap dung)
	public static String getAppliedVoucherCode(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		return session == null ? null : (String) session.getAttribute(SESSION_VOUCHER);
	}

	public static void clearVoucher(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.removeAttribute(SESSION_VOUCHER);
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Map<Integer, CartItem> cart = getCart(request);

		long total = 0;
		for (CartItem item : cart.values()) {
			total += item.getSubtotal();
		}

		request.setAttribute("cartItems", cart.values());
		request.setAttribute("cartTotal", total);
		applyVoucherToRequest(request, total);

		Object voucherError = request.getSession().getAttribute("voucherError");
		if (voucherError != null) {
			request.setAttribute("voucherError", voucherError);
			request.getSession().removeAttribute("voucherError");
		}

		request.getRequestDispatcher("/views/cart/view.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = ParamUtil.getString(request, "action");
		Map<Integer, CartItem> cart = getCart(request);

		if ("add".equals(action)) {
			int productId = ParamUtil.getInt(request, "productId");
			int quantity = Math.max(1, ParamUtil.getInt(request, "quantity"));
			Product product = productDAO.findById(productId);
			if (product != null && product.isActive() && product.getQuantity() > 0) {
				CartItem existing = cart.get(productId);
				int wantedQuantity = (existing != null ? existing.getQuantity() : 0) + quantity;
				// Khong cho gio hang vuot qua so luong con trong kho
				wantedQuantity = Math.min(wantedQuantity, product.getQuantity());
				if (existing != null) {
					existing.setQuantity(wantedQuantity);
				} else {
					cart.put(productId,
							new CartItem(productId, product.getName(), product.getImage(), product.getDisplayPrice(),
									wantedQuantity));
				}
			}
		} else if ("update".equals(action)) {
			int productId = ParamUtil.getInt(request, "productId");
			int quantity = ParamUtil.getInt(request, "quantity");
			CartItem item = cart.get(productId);
			if (item != null) {
				if (quantity <= 0) {
					cart.remove(productId);
				} else {
					Product product = productDAO.findById(productId);
					if (product != null) {
						quantity = Math.min(quantity, product.getQuantity());
					}
					item.setQuantity(quantity);
				}
			}
		} else if ("remove".equals(action)) {
			int productId = ParamUtil.getInt(request, "productId");
			cart.remove(productId);
		} else if ("clear".equals(action)) {
			cart.clear();
			clearVoucher(request);
		} else if ("apply-voucher".equals(action)) {
			String code = ParamUtil.getString(request, "voucherCode");
			long total = 0;
			for (CartItem item : cart.values()) {
				total += item.getSubtotal();
			}
			Voucher voucher = code == null ? null : voucherDAO.findByCode(code);
			if (voucher == null) {
				request.getSession().setAttribute("voucherError", "Mã giảm giá không tồn tại.");
			} else if (!voucher.isUsable()) {
				request.getSession().setAttribute("voucherError", "Mã giảm giá đã hết hạn hoặc đã hết lượt sử dụng.");
			} else if (total < voucher.getMinOrderValue()) {
				request.getSession().setAttribute("voucherError",
						"Đơn hàng cần tối thiểu " + voucher.getMinOrderValue() + "đ để áp dụng mã này.");
			} else {
				request.getSession().setAttribute(SESSION_VOUCHER, voucher.getCode());
				request.getSession().removeAttribute("voucherError");
			}
		} else if ("remove-voucher".equals(action)) {
			clearVoucher(request);
		}

		String redirect = ParamUtil.getString(request, "redirect");
		if (redirect != null && redirect.equals("shop")) {
			response.sendRedirect(request.getContextPath() + "/san-pham");
		} else {
			response.sendRedirect(request.getContextPath() + "/gio-hang");
		}
	}

	// Tinh so tien duoc giam tu voucher dang ap dung (neu co) va dua vao request de hien thi
	private void applyVoucherToRequest(HttpServletRequest request, long cartTotal) {
		String code = getAppliedVoucherCode(request);
		if (code == null) {
			return;
		}
		Voucher voucher = voucherDAO.findByCode(code);
		if (voucher == null || !voucher.isUsable() || cartTotal < voucher.getMinOrderValue()) {
			clearVoucher(request);
			return;
		}
		int discount = voucher.calculateDiscount(cartTotal);
		request.setAttribute("appliedVoucher", voucher);
		request.setAttribute("discountAmount", discount);
		request.setAttribute("finalTotal", cartTotal - discount);
	}
}
