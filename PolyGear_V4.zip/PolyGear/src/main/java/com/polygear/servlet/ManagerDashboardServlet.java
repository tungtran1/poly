package com.polygear.servlet;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.StatisticDAO;

/**
 * Dashboard quan tri: tong doanh thu, tong don hang, tong khach hang, tong
 * san pham, top 5 san pham ban chay va doanh thu 7 ngay gan nhat.
 */
@WebServlet("/manager/dashboard")
public class ManagerDashboardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StatisticDAO statisticDAO = new StatisticDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("totalRevenue", statisticDAO.getTotalRevenue());
		request.setAttribute("totalOrders", statisticDAO.getTotalOrders());
		request.setAttribute("totalCustomers", statisticDAO.getTotalCustomers());
		request.setAttribute("totalProducts", statisticDAO.getTotalProducts());
		request.setAttribute("pendingOrders", statisticDAO.getPendingOrders());
		request.setAttribute("lowStockCount", statisticDAO.getLowStockCount(5));

		try {
			Calendar cal = Calendar.getInstance();
			Date toDate = cal.getTime();
			cal.add(Calendar.DAY_OF_MONTH, -6);
			Date fromDate = cal.getTime();

			request.setAttribute("topProducts", statisticDAO.getTop5BestSellingProducts(null, null));
			request.setAttribute("revenueByDay", statisticDAO.getRevenueByDay(fromDate, toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}

		request.getRequestDispatcher("/views/manager/dashboard.jsp").forward(request, response);
	}
}
