package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.BrandDAO;
import com.polygear.entity.Brand;
import com.polygear.util.ParamUtil;

@WebServlet({ "/manager/brands", "/manager/brands/add", "/manager/brands/edit", "/manager/brands/delete" })
public class BrandServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BrandDAO brandDAO = new BrandDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = ParamUtil.getInt(request, "id");
		if (id > 0) {
			Brand brand = brandDAO.findById(id);
			request.setAttribute("brand", brand);
		}
		List<Brand> list = brandDAO.findAll();
		request.setAttribute("list", list);
		request.getRequestDispatcher("/views/brands/list.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uriString = request.getRequestURI();
		if (uriString.contains("add")) {
			create(request);
		} else if (uriString.contains("edit")) {
			update(request);
		} else if (uriString.contains("delete")) {
			delete(request);
		}
		List<Brand> list = brandDAO.findAll();
		request.setAttribute("list", list);
		request.getRequestDispatcher("/views/brands/list.jsp").forward(request, response);
	}

	// xu ly them moi
	public void create(HttpServletRequest request) {
		String name = ParamUtil.getString(request, "name");
		if (name == null || name.isBlank()) {
			request.setAttribute("error", "Tên không được để trống");
		} else {
			Brand brand = new Brand(null, name, true);
			int rs = brandDAO.create(brand);
			if (rs > 0) {
				request.setAttribute("message", "Thêm mới thành công");
			} else {
				request.setAttribute("error", "Thêm mới thất bại");
			}
		}
	}

	// xu ly cap nhat
	public void update(HttpServletRequest request) {
		int id = ParamUtil.getInt(request, "id");
		String name = ParamUtil.getString(request, "name");
		Brand brand = brandDAO.findById(id);
		if (brand != null) {
			if (name == null || name.isBlank()) {
				request.setAttribute("error", "Tên không được để trống");
			} else {
				brand.setName(name);
				int rs = brandDAO.update(brand);
				if (rs > 0) {
					request.setAttribute("message", "Cập nhật thành công");
				} else {
					request.setAttribute("error", "Cập nhật thất bại");
				}
			}
			request.setAttribute("brand", brand);
		} else {
			request.setAttribute("error", "Thương hiệu không tồn tại");
		}
	}

	// xu ly xoa
	public void delete(HttpServletRequest request) {
		int id = ParamUtil.getInt(request, "id");
		if (id > 0) {
			Brand brand = brandDAO.findById(id);
			if (brand == null) {
				request.setAttribute("error", "Không tìm thấy thương hiệu");
				return;
			}
			int countProduct = brandDAO.countProductInBrand(id);
			if (countProduct > 0) {
				// Con san pham dang gan thuong hieu nay -> chi an di, khong xoa cung
				brand.setActive(false);
				brandDAO.update(brand);
			} else {
				brandDAO.delete(id);
			}
			request.setAttribute("message", "Xóa thành công");
		} else {
			request.setAttribute("error", "Không tìm thấy thương hiệu");
		}
	}
}
