package com.polygear.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.BillDAO;
import com.polygear.dao.BillDetailDAO;
import com.polygear.dao.ProductDAO;
import com.polygear.dao.UserDAO;
import com.polygear.entity.Bill;
import com.polygear.entity.BillDetail;
import com.polygear.entity.Product;
import com.polygear.entity.User;
import com.polygear.util.ParamUtil;

/**
 * Quan ly hoa don / don hang cho quan tri vien (danh sach toan bo don, xem
 * chi tiet, cap nhat trang thai).
 */
@WebServlet({ "/manager/bills", "/manager/bills/detail", "/manager/bills/update-status" })
public class ManagerBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BillDAO billDAO = new BillDAO();
	private BillDetailDAO billDetailDAO = new BillDetailDAO();
	private ProductDAO productDAO = new ProductDAO();
	private UserDAO userDAO = new UserDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();

		if ("/manager/bills/detail".equals(path)) {
			int billId = ParamUtil.getInt(request, "id");
			Bill bill = billDAO.findById(billId);
			if (bill == null) {
				response.sendRedirect(request.getContextPath() + "/manager/bills");
				return;
			}
			List<BillDetail> details = billDetailDAO.findByBillId(billId);
			Map<Integer, Product> productMap = new HashMap<>();
			for (BillDetail d : details) {
				if (!productMap.containsKey(d.getProductId())) {
					productMap.put(d.getProductId(), productDAO.findById(d.getProductId()));
				}
			}
			request.setAttribute("bill", bill);
			request.setAttribute("details", details);
			request.setAttribute("productMap", productMap);
			request.getRequestDispatcher("/views/manager/bills/detail.jsp").forward(request, response);
			return;
		}

		int userId = ParamUtil.getInt(request, "userId");
		String code = ParamUtil.getString(request, "code");
		List<Bill> bills;
		if (userId > 0) {
			bills = billDAO.findByUserId(userId);
			request.setAttribute("filterUser", userDAO.findById(userId));
		} else if (code != null && !code.isBlank()) {
			bills = billDAO.searchByCode(code);
		} else {
			bills = billDAO.findAll();
		}
		request.setAttribute("bills", bills);
		request.getRequestDispatcher("/views/manager/bills/list.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int billId = ParamUtil.getInt(request, "id");
		String status = ParamUtil.getString(request, "status");
		billDAO.updateStatus(billId, status);
		response.sendRedirect(request.getContextPath() + "/manager/bills/detail?id=" + billId);
	}
}
