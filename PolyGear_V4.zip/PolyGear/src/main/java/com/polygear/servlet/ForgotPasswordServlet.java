package com.polygear.servlet;

import java.io.IOException;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.UserDAO;
import com.polygear.entity.User;
import com.polygear.util.MailUtil;
import com.polygear.util.ParamUtil;

/**
 * Quen mat khau: nguoi dung nhap email -> he thong tao token dung 1 lan
 * (het han sau 30 phut), gui email chua link dat lai mat khau.
 *
 * Neu chua cau hinh SMTP that (xem MailUtil / mail.properties), he thong se
 * hien thi thang link dat lai mat khau ngay tren man hinh de van dung duoc
 * chuc nang khi demo / cham bai.
 */
@WebServlet("/quen-mat-khau")
public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final long TOKEN_TTL_MS = 30 * 60 * 1000L; // 30 phut

	private UserDAO userDAO = new UserDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/views/auth/forgot-password.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = ParamUtil.getString(request, "email");
		User user = (email == null || email.isBlank()) ? null : userDAO.findByEmail(email);

		// Luon hien thi cung 1 thong bao du email co ton tai hay khong,
		// tranh de lo thong tin email nao da dang ky trong he thong.
		String genericMessage = "Nếu email tồn tại trong hệ thống, một liên kết đặt lại mật khẩu đã được gửi tới email đó.";
		request.setAttribute("message", genericMessage);

		if (user != null) {
			String token = UUID.randomUUID().toString().replace("-", "");
			long expiry = System.currentTimeMillis() + TOKEN_TTL_MS;
			userDAO.saveResetToken(user.getId(), token, expiry);

			String baseUrl = request.getScheme() + "://" + request.getServerName()
					+ (request.getServerPort() == 80 || request.getServerPort() == 443 ? ""
							: ":" + request.getServerPort())
					+ request.getContextPath();
			String link = baseUrl + "/dat-lai-mat-khau?token=" + token;

			String html = "<p>Xin chào " + user.getFullName() + ",</p>"
					+ "<p>Bạn vừa yêu cầu đặt lại mật khẩu cho tài khoản PolyGear. Nhấn vào liên kết bên dưới để đặt mật khẩu mới (liên kết có hiệu lực trong 30 phút):</p>"
					+ "<p><a href=\"" + link + "\">" + link + "</a></p>"
					+ "<p>Nếu bạn không yêu cầu điều này, hãy bỏ qua email này.</p>";

			boolean sent = MailUtil.send(user.getEmail(), "PolyGear - Đặt lại mật khẩu", html);
			if (!sent) {
				// Che do du phong: chua cau hinh SMTP that -> hien thi link truc tiep
				request.setAttribute("devResetLink", link);
			}
		}

		request.getRequestDispatcher("/views/auth/forgot-password.jsp").forward(request, response);
	}
}
