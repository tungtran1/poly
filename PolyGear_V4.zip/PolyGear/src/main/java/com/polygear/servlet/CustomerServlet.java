package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.UserDAO;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

/**
 * Quan ly tai khoan Khach hang (role = CUSTOMER). Admin va Nhan vien deu
 * duoc XEM danh sach (huu ich khi xu ly don hang), nhung chi Admin moi duoc
 * khoa/mo khoa tai khoan. Khong ai duoc tao/xoa tai khoan khach hang - khach
 * hang tu dang ky qua trang /dang-ky.
 */
@WebServlet({ "/manager/customers", "/manager/customers/update-status" })
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String keyword = ParamUtil.getString(req, "keyword");
		List<User> customers = userDAO.searchByRole(User.ROLE_CUSTOMER, keyword);
		req.setAttribute("customers", customers);
		req.setAttribute("keyword", keyword);
		req.getRequestDispatcher("/views/staff/customer-list.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		// Chi Admin duoc khoa/mo khoa tai khoan khach hang, Nhan vien chi duoc xem
		if (!AuthUtil.isAdmin(req)) {
			resp.sendRedirect(req.getContextPath() + "/manager/customers?error=false");
			return;
		}
		int userId = ParamUtil.getInt(req, "userId");
		int status = ParamUtil.getInt(req, "status");
		int rs = userDAO.updateStatus(userId, status == 1);
		if (rs > 0) {
			resp.sendRedirect(req.getContextPath() + "/manager/customers?success=true");
		} else {
			resp.sendRedirect(req.getContextPath() + "/manager/customers?error=false");
		}
	}
}
