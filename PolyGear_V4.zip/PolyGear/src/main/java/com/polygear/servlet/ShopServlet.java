package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.BrandDAO;
import com.polygear.dao.CategoryDAO;
import com.polygear.dao.ProductDAO;
import com.polygear.entity.Brand;
import com.polygear.entity.Category;
import com.polygear.entity.Product;
import com.polygear.util.ParamUtil;

/**
 * Trang danh sach phu kien cho khach hang, cho phep loc theo loai phu kien
 * (category), thuong hieu (brand) va tim kiem theo ten.
 */
@WebServlet("/san-pham")
public class ShopServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductDAO productDAO = new ProductDAO();
	private CategoryDAO categoryDAO = new CategoryDAO();
	private BrandDAO brandDAO = new BrandDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int categoryId = ParamUtil.getInt(request, "categoryId");
		int brandId = ParamUtil.getInt(request, "brandId");
		String keyword = ParamUtil.getString(request, "keyword");
		int minPrice = ParamUtil.getInt(request, "minPrice");
		int maxPrice = ParamUtil.getInt(request, "maxPrice");
		String sort = ParamUtil.getString(request, "sort");

		List<Product> products = productDAO.findForShop(categoryId > 0 ? categoryId : null,
				brandId > 0 ? brandId : null, keyword, minPrice > 0 ? minPrice : null, maxPrice > 0 ? maxPrice : null,
				sort);
		List<Category> categories = categoryDAO.findAllActive();
		List<Brand> brands = brandDAO.findAllActive();

		Category currentCategory = categoryId > 0 ? categoryDAO.findById(categoryId) : null;
		Brand currentBrand = brandId > 0 ? brandDAO.findById(brandId) : null;

		request.setAttribute("products", products);
		request.setAttribute("categories", categories);
		request.setAttribute("brands", brands);
		request.setAttribute("currentCategory", currentCategory);
		request.setAttribute("currentBrand", currentBrand);
		request.setAttribute("categoryId", categoryId);
		request.setAttribute("brandId", brandId);
		request.setAttribute("keyword", keyword);
		request.setAttribute("minPrice", minPrice > 0 ? minPrice : null);
		request.setAttribute("maxPrice", maxPrice > 0 ? maxPrice : null);
		request.setAttribute("sort", sort);

		com.polygear.entity.User user = com.polygear.util.AuthUtil.getUser(request);
		if (user != null) {
			request.setAttribute("wishlistIds", new com.polygear.dao.WishlistDAO().findProductIdsByUserId(user.getId()));
		}

		request.getRequestDispatcher("/views/shop/list.jsp").forward(request, response);
	}
}
