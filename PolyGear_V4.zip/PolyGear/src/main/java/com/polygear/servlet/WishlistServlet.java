package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.WishlistDAO;
import com.polygear.entity.Product;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

/**
 * Danh sach san pham yeu thich cua khach hang. Yeu cau dang nhap (duoc bao
 * ve boi AuthFilter).
 */
@WebServlet({ "/yeu-thich", "/yeu-thich/toggle" })
public class WishlistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private WishlistDAO wishlistDAO = new WishlistDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = AuthUtil.getUser(request);
		List<Product> products = wishlistDAO.findProductsByUserId(user.getId());
		request.setAttribute("products", products);
		request.getRequestDispatcher("/views/wishlist/list.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = AuthUtil.getUser(request);
		int productId = ParamUtil.getInt(request, "productId");

		if (wishlistDAO.exists(user.getId(), productId)) {
			wishlistDAO.remove(user.getId(), productId);
		} else {
			wishlistDAO.add(user.getId(), productId);
		}

		String redirect = ParamUtil.getString(request, "redirect");
		if (redirect != null && !redirect.isBlank()) {
			response.sendRedirect(request.getContextPath() + redirect);
		} else {
			response.sendRedirect(request.getContextPath() + "/yeu-thich");
		}
	}
}
