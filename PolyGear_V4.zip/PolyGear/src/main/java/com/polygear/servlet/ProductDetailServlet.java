package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.CategoryDAO;
import com.polygear.dao.ProductDAO;
import com.polygear.dao.ReviewDAO;
import com.polygear.dao.WishlistDAO;
import com.polygear.entity.Category;
import com.polygear.entity.Product;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

@WebServlet("/san-pham/chi-tiet")
public class ProductDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductDAO productDAO = new ProductDAO();
	private CategoryDAO categoryDAO = new CategoryDAO();
	private ReviewDAO reviewDAO = new ReviewDAO();
	private WishlistDAO wishlistDAO = new WishlistDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = ParamUtil.getInt(request, "id");
		Product product = id > 0 ? productDAO.findById(id) : null;

		if (product == null || !product.isActive()) {
			response.sendRedirect(request.getContextPath() + "/san-pham");
			return;
		}

		Category category = product.getCategoryId() != null ? categoryDAO.findById(product.getCategoryId()) : null;
		List<Product> related = productDAO.findForShop(product.getCategoryId(), null);

		request.setAttribute("product", product);
		request.setAttribute("category", category);
		request.setAttribute("related", related);

		// Danh gia / binh luan cua san pham
		request.setAttribute("reviews", reviewDAO.findByProductId(id));
		double avgRating = reviewDAO.getAverageRating(id);
		request.setAttribute("averageRating", avgRating);
		request.setAttribute("averageRatingRounded", Math.round(avgRating));
		request.setAttribute("reviewCount", reviewDAO.countByProductId(id));

		User user = AuthUtil.getUser(request);
		if (user != null) {
			request.setAttribute("isWishlisted", wishlistDAO.exists(user.getId(), id));
			request.setAttribute("canReview",
					reviewDAO.hasPurchased(user.getId(), id) && !reviewDAO.hasReviewed(user.getId(), id));
		}

		request.getRequestDispatcher("/views/shop/detail.jsp").forward(request, response);
	}
}
