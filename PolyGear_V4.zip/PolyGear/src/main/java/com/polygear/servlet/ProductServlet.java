package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import com.polygear.dao.BrandDAO;
import com.polygear.dao.CategoryDAO;
import com.polygear.dao.ProductDAO;
import com.polygear.entity.Product;
import com.polygear.util.FileUtil;
import com.polygear.util.ParamUtil;

@MultipartConfig
@WebServlet({ "/manager/products", "/manager/products/add", "/manager/products/edit", "/manager/products/delete" })
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductDAO productDAO = new ProductDAO();
	private CategoryDAO categoryDAO = new CategoryDAO();
	private BrandDAO brandDAO = new BrandDAO();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uriString = req.getRequestURI();
		if (uriString.contains("add") || uriString.contains("edit")) {
			req.setAttribute("categories", categoryDAO.findAll());
			req.setAttribute("brands", brandDAO.findAll());
			int id = ParamUtil.getInt(req, "id");
			if (uriString.contains("edit") && id > 0) {
				Product product = productDAO.findById(id);
				if (product == null) {
					resp.sendRedirect(req.getContextPath() + "/manager/products?error=false");
					return;
				}
				req.setAttribute("product", product);
			}
			req.getRequestDispatcher("/views/product/product-form.jsp").forward(req, resp);
			return;
		}
		if (uriString.contains("/manager/products")) {
			req.setAttribute("categories", categoryDAO.findAll());
			req.setAttribute("brands", brandDAO.findAll());
			getProductsManager(req);
			req.getRequestDispatcher("/views/product/manager-list.jsp").forward(req, resp);
			return;
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uriString = req.getRequestURI();
		if (uriString.contains("add")) {
			create(req, resp);
		} else if (uriString.contains("edit")) {
			edit(req, resp);
		} else if (uriString.contains("delete")) {
			delete(req, resp);
		}
	}

	private void getProductsManager(HttpServletRequest request) {
		String keyword = ParamUtil.getString(request, "keyword");
		int categoryId = ParamUtil.getInt(request, "categoryId");
		int brandId = ParamUtil.getInt(request, "brandId");

		StringBuilder sql = new StringBuilder("SELECT * FROM products WHERE 1=1");
		java.util.List<Object> params = new java.util.ArrayList<>();
		if (keyword != null && !keyword.isBlank()) {
			sql.append(" AND name LIKE ?");
			params.add("%" + keyword.trim() + "%");
		}
		if (categoryId > 0) {
			sql.append(" AND category_id = ?");
			params.add(categoryId);
		}
		if (brandId > 0) {
			sql.append(" AND brand_id = ?");
			params.add(brandId);
		}
		sql.append(" ORDER BY id DESC");

		List<Product> list = productDAO.findBySql(sql.toString(), params.toArray());
		request.setAttribute("products", list);
		request.setAttribute("keyword", keyword);
		request.setAttribute("categoryId", categoryId);
		request.setAttribute("brandId", brandId);
	}

	private void create(HttpServletRequest request, HttpServletResponse response) {
		try {
			Product product = getProductFromRequestAndValidate(request, response);
			if (product == null) {
				return; // da forward ve form khi validate loi
			}
			int rs = productDAO.create(product);
			if (rs > 0) {
				response.sendRedirect(request.getContextPath() + "/manager/products?success=true");
			} else {
				response.sendRedirect(request.getContextPath() + "/manager/products?error=false");
			}
		} catch (IOException | ServletException e) {
			e.printStackTrace();
		}
	}

	private void edit(HttpServletRequest request, HttpServletResponse response) {
		try {
			Product product = getProductFromRequestAndValidate(request, response);
			if (product == null) {
				return; // da forward ve form khi validate loi
			}
			// SUA LOI: form gui hidden input name="id" (truoc day la "productId" khong
			// khop voi servlet doc "id" -> luon cap nhat sai san pham co id = 0)
			int productId = ParamUtil.getInt(request, "id");
			product.setId(productId);

			int rs = productDAO.update(product);
			if (rs > 0) {
				response.sendRedirect(request.getContextPath() + "/manager/products?success=true");
			} else {
				response.sendRedirect(request.getContextPath() + "/manager/products?error=false");
			}
		} catch (IOException | ServletException e) {
			e.printStackTrace();
		}
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) {
		try {
			int productId = ParamUtil.getInt(request, "id");
			int rs = productDAO.delete(productId);
			if (rs > 0) {
				response.sendRedirect(request.getContextPath() + "/manager/products?success=true");
			} else {
				response.sendRedirect(request.getContextPath() + "/manager/products?error=false");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private Product getProductFromRequestAndValidate(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int categoryId = ParamUtil.getInt(request, "categoryId");
		int brandId = ParamUtil.getInt(request, "brandId");
		String name = ParamUtil.getString(request, "name");
		String description = ParamUtil.getString(request, "description");
		int price = ParamUtil.getInt(request, "price");
		int quantity = ParamUtil.getInt(request, "quantity");
		int active = ParamUtil.getInt(request, "active");
		Part imagePart = request.getPart("image");

		boolean hasError = false;
		if (categoryId == 0) {
			request.setAttribute("errCat", "Vui lòng chọn danh mục");
			hasError = true;
		}
		if (name == null || name.isBlank()) {
			request.setAttribute("errName", "Vui lòng nhập tên phụ kiện");
			hasError = true;
		}
		if (price <= 0) {
			request.setAttribute("errPrice", "Giá phải lớn hơn 0");
			hasError = true;
		}
		if (quantity < 0) {
			request.setAttribute("errQuantity", "Số lượng tồn kho không được âm");
			hasError = true;
		}
		if (description == null || description.isBlank()) {
			request.setAttribute("errDesc", "Vui lòng nhập mô tả");
			hasError = true;
		}

		String uriString = request.getRequestURI();
		boolean isAdd = uriString.contains("add");
		if (isAdd && (imagePart == null || imagePart.getSize() == 0)) {
			request.setAttribute("errImage", "Vui lòng chọn hình ảnh");
			hasError = true;
		}

		int isFlashSale = ParamUtil.getInt(request, "isFlashSale");
		int discountPrice = ParamUtil.getInt(request, "discountPrice");
		if (isFlashSale == 1 && discountPrice <= 0) {
			request.setAttribute("errDiscountPrice", "Vui lòng nhập giá Flash Sale hợp lệ");
			hasError = true;
		}
		if (isFlashSale == 1 && discountPrice >= price && price > 0) {
			request.setAttribute("errDiscountPrice", "Giá Flash Sale phải nhỏ hơn giá gốc");
			hasError = true;
		}

		if (hasError) {
			request.setAttribute("categories", categoryDAO.findAll());
			request.setAttribute("brands", brandDAO.findAll());
			Product product = new Product();
			product.setCategoryId(categoryId);
			product.setBrandId(brandId);
			product.setName(name);
			product.setDescription(description);
			product.setPrice(price);
			product.setQuantity(quantity);
			product.setActive(active == 1);
			product.setFlashSale(isFlashSale == 1);
			product.setDiscountPrice(discountPrice > 0 ? discountPrice : null);
			if (!isAdd) {
				product.setId(ParamUtil.getInt(request, "id"));
				product.setImage(ParamUtil.getString(request, "oldImage"));
			}
			request.setAttribute("product", product);
			request.getRequestDispatcher("/views/product/product-form.jsp").forward(request, response);
			return null;
		}

		String imageName;
		if (imagePart != null && imagePart.getSize() > 0) {
			imageName = FileUtil.upload(request, "image");
			if (imageName == null) {
				imageName = ParamUtil.getString(request, "oldImage");
			}
		} else {
			imageName = ParamUtil.getString(request, "oldImage");
		}

		Product product = new Product();
		product.setCategoryId(categoryId);
		product.setBrandId(brandId > 0 ? brandId : null);
		product.setName(name);
		product.setDescription(description);
		product.setPrice(price);
		product.setQuantity(quantity);
		product.setActive(active == 1);
		product.setImage(imageName);
		product.setFlashSale(isFlashSale == 1);
		product.setDiscountPrice(discountPrice > 0 ? discountPrice : null);

		return product;
	}
}
