package com.polygear.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.BillDAO;
import com.polygear.dao.BillDetailDAO;
import com.polygear.dao.ProductDAO;
import com.polygear.entity.Bill;
import com.polygear.entity.BillDetail;
import com.polygear.entity.Product;
import com.polygear.entity.User;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;

/**
 * Quan ly don hang / hoa don cua khach hang dang dang nhap.
 * /don-hang        : danh sach don hang cua toi
 * /hoa-don?id=..   : chi tiet hoa don (dang in duoc)
 */
@WebServlet({ "/don-hang", "/hoa-don" })
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BillDAO billDAO = new BillDAO();
	private BillDetailDAO billDetailDAO = new BillDetailDAO();
	private ProductDAO productDAO = new ProductDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		User user = AuthUtil.getUser(request);

		if ("/hoa-don".equals(path)) {
			int billId = ParamUtil.getInt(request, "id");
			Bill bill = billDAO.findByIdAndUserId(billId, user.getId());
			if (bill == null) {
				response.sendRedirect(request.getContextPath() + "/don-hang");
				return;
			}
			List<BillDetail> details = billDetailDAO.findByBillId(billId);
			Map<Integer, Product> productMap = new HashMap<>();
			for (BillDetail d : details) {
				if (!productMap.containsKey(d.getProductId())) {
					productMap.put(d.getProductId(), productDAO.findById(d.getProductId()));
				}
			}
			request.setAttribute("bill", bill);
			request.setAttribute("details", details);
			request.setAttribute("productMap", productMap);
			request.getRequestDispatcher("/views/bill/detail.jsp").forward(request, response);
			return;
		}

		// /don-hang : danh sach
		List<Bill> bills = billDAO.findByUserId(user.getId());
		request.setAttribute("bills", bills);
		request.getRequestDispatcher("/views/bill/list.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = AuthUtil.getUser(request);
		int billId = ParamUtil.getInt(request, "id");
		String action = ParamUtil.getString(request, "action");

		Bill bill = billDAO.findByIdAndUserId(billId, user.getId());
		if (bill == null) {
			response.sendRedirect(request.getContextPath() + "/don-hang");
			return;
		}

		if ("cancel".equals(action)) {
			// Khach hang chi duoc tu huy don khi don con dang "Cho xac nhan" hoac
			// "Dang chuan bi" - khi da chuyen sang "Dang giao" thi phai lien he
			// quan ly/nhan vien de duoc ho tro huy don
			if (BillDAO.STATUS_WAITING.equals(bill.getStatus()) || BillDAO.STATUS_PREPARING.equals(bill.getStatus())) {
				billDAO.updateStatus(billId, BillDAO.STATUS_CANCEL);
				response.sendRedirect(request.getContextPath() + "/hoa-don?id=" + billId + "&cancelSuccess=true");
			} else {
				response.sendRedirect(request.getContextPath() + "/hoa-don?id=" + billId + "&cancelError=true");
			}
			return;
		}

		response.sendRedirect(request.getContextPath() + "/hoa-don?id=" + billId);
	}
}
