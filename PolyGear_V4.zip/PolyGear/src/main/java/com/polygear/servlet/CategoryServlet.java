package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.CategoryDAO;
import com.polygear.entity.Category;
import com.polygear.util.ParamUtil;

@WebServlet({ "/manager/categories", "/manager/categories/add", "/manager/categories/edit",
		"/manager/categories/delete" })
public class CategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CategoryDAO categoryDAO = new CategoryDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = ParamUtil.getInt(request, "id");
		if (id > 0) {
			Category category = categoryDAO.findById(id);
			request.setAttribute("category", category);
		}
		List<Category> list = categoryDAO.findAll();
		request.setAttribute("list", list);
		request.getRequestDispatcher("/views/categories/list.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uriString = request.getRequestURI();
		if (uriString.contains("add")) {
			create(request);
		} else if (uriString.contains("edit")) {
			update(request);
		} else if (uriString.contains("delete")) {
			delete(request);
		}
		List<Category> list = categoryDAO.findAll();
		request.setAttribute("list", list);
		request.getRequestDispatcher("/views/categories/list.jsp").forward(request, response);
	}

	// xu ly them moi
	public void create(HttpServletRequest request) {
		String name = ParamUtil.getString(request, "name");
		if (name == null || name.isBlank()) {
			request.setAttribute("error", "Tên không được để trống");
		} else {
			Category category = new Category(null, name, true);
			int rs = categoryDAO.create(category);
			if (rs > 0) {
				request.setAttribute("message", "Thêm mới thành công");
			} else {
				request.setAttribute("error", "Thêm mới thất bại");
			}
		}
	}

	// xu ly cap nhat
	public void update(HttpServletRequest request) {
		int id = ParamUtil.getInt(request, "id");
		String name = ParamUtil.getString(request, "name");
		Category category = categoryDAO.findById(id);
		if (category != null) {
			if (name == null || name.isBlank()) {
				request.setAttribute("error", "Tên không được để trống");
			} else {
				category.setName(name);
				int rs = categoryDAO.update(category);
				if (rs > 0) {
					request.setAttribute("message", "Cập nhật thành công");
				} else {
					request.setAttribute("error", "Cập nhật thất bại");
				}
			}
			request.setAttribute("category", category);
		} else {
			request.setAttribute("error", "Loại không tồn tại");
		}
	}

	// xu ly xoa
	public void delete(HttpServletRequest request) {
		int id = ParamUtil.getInt(request, "id");
		if (id > 0) {
			Category category = categoryDAO.findById(id);
			if (category == null) {
				request.setAttribute("error", "Không tìm thấy loại phụ kiện");
				return;
			}
			int countProduct = categoryDAO.countProductInCategory(id);
			if (countProduct > 0) {
				category.setActive(false);
				categoryDAO.update(category);
			} else {
				categoryDAO.delete(id);
			}
			request.setAttribute("message", "Xóa thành công");
		} else {
			request.setAttribute("error", "Không tìm thấy loại phụ kiện");
		}
	}
}
