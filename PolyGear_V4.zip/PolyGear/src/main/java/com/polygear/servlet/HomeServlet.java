package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.CategoryDAO;
import com.polygear.dao.ProductDAO;
import com.polygear.entity.Category;
import com.polygear.entity.Product;

@WebServlet("/trang-chu")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductDAO productDAO = new ProductDAO();
	private CategoryDAO categoryDAO = new CategoryDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Product> featuredProducts = productDAO.findForShop(null, null);
		List<Category> categories = categoryDAO.findAllActive();
		List<Product> flashSaleProducts = productDAO.findFlashSale();

		request.setAttribute("featuredProducts", featuredProducts);
		request.setAttribute("categories", categories);
		request.setAttribute("flashSaleProducts", flashSaleProducts);
		request.getRequestDispatcher("/views/home.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
