package com.polygear.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.BillDAO;
import com.polygear.dao.UserDAO;
import com.polygear.entity.User;
import com.polygear.util.ParamUtil;

/**
 * Quan ly tai khoan Nhan vien (role = STAFF). Chi Admin duoc truy cap (xem
 * AuthFilter). Nhan vien duoc tao boi Admin, khong the tu dang ky.
 */
@WebServlet({ "/manager/staff", "/manager/staff/add", "/manager/staff/edit", "/manager/staff/update-status",
		"/manager/staff/delete" })
public class StaffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();
	private BillDAO billDAO = new BillDAO();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String path = req.getServletPath();

		if (path.equals("/manager/staff")) {
			listStaff(req, resp);
			req.getRequestDispatcher("/views/staff/staff-list.jsp").forward(req, resp);
		} else if (path.equals("/manager/staff/add")) {
			req.getRequestDispatcher("/views/staff/staff-form.jsp").forward(req, resp);
		} else if (path.equals("/manager/staff/edit")) {
			int userId = ParamUtil.getInt(req, "userId");
			User existingUser = userDAO.findById(userId);

			if (existingUser != null && existingUser.isStaff()) {
				req.setAttribute("staff", existingUser);
				req.getRequestDispatcher("/views/staff/staff-form.jsp").forward(req, resp);
			} else {
				resp.sendRedirect(req.getContextPath() + "/manager/staff?error=notfound");
			}
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String path = req.getServletPath();

		if (path.equals("/manager/staff/add")) {
			create(req, resp);
		} else if (path.equals("/manager/staff/edit")) {
			edit(req, resp);
		} else if (path.equals("/manager/staff/update-status")) {
			updateStatus(req, resp);
		} else if (path.equals("/manager/staff/delete")) {
			delete(req, resp);
		}
	}

	// Danh sach tai khoan Nhan vien, ho tro tim theo ten/email/sdt
	public void listStaff(HttpServletRequest req, HttpServletResponse resp) {
		String keyword = ParamUtil.getString(req, "keyword");
		List<User> staffList = userDAO.searchByRole(User.ROLE_STAFF, keyword);
		req.setAttribute("staffList", staffList);
		req.setAttribute("keyword", keyword);
	}

	// Xoa tai khoan: neu chua co hoa don nao thi xoa han, neu da co hoa don thi
	// chi khoa lai (giu du lieu lich su mua hang)
	public void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		int userId = ParamUtil.getInt(req, "userId");
		User user = userDAO.findById(userId);
		if (user == null) {
			resp.sendRedirect(req.getContextPath() + "/manager/staff?error=false");
			return;
		}
		if (billDAO.findByUserId(userId).isEmpty()) {
			userDAO.delete(userId);
		} else {
			userDAO.updateStatus(userId, false);
		}
		resp.sendRedirect(req.getContextPath() + "/manager/staff?success=true");
	}

	public void create(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User staff = getStaffFromRequestAndValidate(req, resp, true);
		if (staff != null) {
			User existingUser = userDAO.findByEmail(staff.getEmail());
			if (existingUser != null) {
				req.setAttribute("emailError", "Email đã được sử dụng.");
				req.setAttribute("staff", staff);
				req.getRequestDispatcher("/views/staff/staff-form.jsp").forward(req, resp);
				return;
			}
			int rs = userDAO.create(staff);
			if (rs > 0) {
				resp.sendRedirect(req.getContextPath() + "/manager/staff?success=true");
			} else {
				resp.sendRedirect(req.getContextPath() + "/manager/staff?error=false");
			}
		}
	}

	public void edit(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User staff = getStaffFromRequestAndValidate(req, resp, false);
		if (staff != null) {
			int userId = ParamUtil.getInt(req, "userId");
			staff.setId(userId);

			User existingUser = userDAO.findByEmail(staff.getEmail());
			if (existingUser != null && !existingUser.getId().equals(userId)) {
				req.setAttribute("emailError", "Email này đã thuộc về tài khoản khác.");
				req.setAttribute("staff", staff);
				req.getRequestDispatcher("/views/staff/staff-form.jsp").forward(req, resp);
				return;
			}

			int rs = userDAO.updateUserInfo(staff);
			if (rs > 0) {
				resp.sendRedirect(req.getContextPath() + "/manager/staff?success=true");
			} else {
				resp.sendRedirect(req.getContextPath() + "/manager/staff?error=false");
			}
		}
	}

	public void updateStatus(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		int userId = ParamUtil.getInt(req, "userId");
		int status = ParamUtil.getInt(req, "status");
		int rs = userDAO.updateStatus(userId, status == 1);
		if (rs > 0) {
			resp.sendRedirect(req.getContextPath() + "/manager/staff?success=true");
		} else {
			resp.sendRedirect(req.getContextPath() + "/manager/staff?error=false");
		}
	}

	public User getStaffFromRequestAndValidate(HttpServletRequest req, HttpServletResponse resp, boolean isCreate)
			throws ServletException, IOException {
		String email = ParamUtil.getString(req, "email");
		String password = ParamUtil.getString(req, "password");
		String fullName = ParamUtil.getString(req, "fullName");
		String phone = ParamUtil.getString(req, "phone");
		int active = ParamUtil.getInt(req, "active");

		boolean hasError = false;
		if (email == null || !email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
			req.setAttribute("emailError", "Email không hợp lệ.");
			hasError = true;
		}

		if (isCreate || (password != null && !password.isBlank())) {
			if (password == null || password.length() < 6) {
				req.setAttribute("passwordError", "Mật khẩu phải có ít nhất 6 ký tự.");
				hasError = true;
			}
		}

		if (fullName == null || fullName.isBlank()) {
			req.setAttribute("fullNameError", "Họ và tên không được để trống.");
			hasError = true;
		}
		if (phone == null || !phone.matches("^0\\d{9}$")) {
			req.setAttribute("phoneError", "Số điện thoại không hợp lệ.");
			hasError = true;
		}

		if (hasError) {
			User tempStaff = new User();
			tempStaff.setEmail(email);
			tempStaff.setFullName(fullName);
			tempStaff.setPhone(phone);
			tempStaff.setActive(active == 1);
			req.setAttribute("staff", tempStaff);

			req.getRequestDispatcher("/views/staff/staff-form.jsp").forward(req, resp);
			return null;
		}

		User staff = new User();
		staff.setEmail(email);
		staff.setPassword(password);
		staff.setFullName(fullName);
		staff.setPhone(phone);
		staff.setActive(active == 1);
		staff.setRole(User.ROLE_STAFF);
		return staff;
	}
}
