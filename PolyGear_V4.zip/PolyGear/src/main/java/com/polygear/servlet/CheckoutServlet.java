package com.polygear.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.polygear.dao.BillDAO;
import com.polygear.dao.ProductDAO;
import com.polygear.dao.VoucherDAO;
import com.polygear.entity.Bill;
import com.polygear.entity.BillDetail;
import com.polygear.entity.CartItem;
import com.polygear.entity.Product;
import com.polygear.entity.User;
import com.polygear.entity.Voucher;
import com.polygear.util.AuthUtil;
import com.polygear.util.ParamUtil;
import com.polygear.util.ShippingUtil;

/**
 * Thanh toan gio hang: tao Hoa don (Bill) + Chi tiet hoa don (BillDetail) tu
 * gio hang trong session, roi xoa gio hang. Yeu cau dang nhap (AuthFilter da
 * bao ve URL nay).
 */
@WebServlet("/thanh-toan")
public class CheckoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BillDAO billDAO = new BillDAO();
	private ProductDAO productDAO = new ProductDAO();
	private VoucherDAO voucherDAO = new VoucherDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Map<Integer, CartItem> cart = CartServlet.getCart(request);
		if (cart.isEmpty()) {
			response.sendRedirect(request.getContextPath() + "/gio-hang");
			return;
		}

		long total = 0;
		for (CartItem item : cart.values()) {
			total += item.getSubtotal();
		}

		int discount = 0;
		Voucher voucher = null;
		String voucherCode = CartServlet.getAppliedVoucherCode(request);
		if (voucherCode != null) {
			voucher = voucherDAO.findByCode(voucherCode);
			if (voucher != null && voucher.isUsable() && total >= voucher.getMinOrderValue()) {
				discount = voucher.calculateDiscount(total);
			} else {
				voucher = null;
				CartServlet.clearVoucher(request);
			}
		}

		// Phuong thuc giao hang khach dang chon (mac dinh "standard" neu chua chon)
		String shippingMethod = ParamUtil.getString(request, "shippingMethod");
		if (!ShippingUtil.isValid(shippingMethod)) {
			shippingMethod = "standard";
		}
		int shippingFee = ShippingUtil.getFee(shippingMethod);

		request.setAttribute("cartItems", cart.values());
		request.setAttribute("cartTotal", total);
		request.setAttribute("appliedVoucher", voucher);
		request.setAttribute("discountAmount", discount);
		request.setAttribute("shippingMethods", ShippingUtil.getAllMethods());
		request.setAttribute("selectedShippingMethod", shippingMethod);
		request.setAttribute("shippingFee", shippingFee);
		request.setAttribute("finalTotal", total - discount + shippingFee);
		request.getRequestDispatcher("/views/checkout/view.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Map<Integer, CartItem> cart = CartServlet.getCart(request);
		if (cart.isEmpty()) {
			response.sendRedirect(request.getContextPath() + "/gio-hang");
			return;
		}

		User user = AuthUtil.getUser(request);
		String receiverName = ParamUtil.getString(request, "receiverName");
		String receiverPhone = ParamUtil.getString(request, "receiverPhone");
		String receiverAddress = ParamUtil.getString(request, "receiverAddress");
		String shippingMethod = ParamUtil.getString(request, "shippingMethod");

		if (receiverName == null || receiverName.isBlank() || receiverPhone == null || receiverPhone.isBlank()
				|| receiverAddress == null || receiverAddress.isBlank()) {
			showCheckoutError(request, response, "Vui lòng nhập đầy đủ thông tin nhận hàng.", shippingMethod);
			return;
		}
		if (!ShippingUtil.isValid(shippingMethod)) {
			showCheckoutError(request, response, "Vui lòng chọn phương thức giao hàng hợp lệ.", shippingMethod);
			return;
		}

		// Kiem tra ton kho truoc khi tao hoa don, tranh ban vuot so luong con lai
		// va thong bao het hang ro rang cho khach
		for (CartItem item : cart.values()) {
			Product product = productDAO.findById(item.getProductId());
			if (product == null || !product.isActive() || product.getQuantity() <= 0) {
				showCheckoutError(request, response,
						"Sản phẩm \"" + item.getName() + "\" hiện đã hết hàng, vui lòng xóa khỏi giỏ hàng.",
						shippingMethod);
				return;
			}
			if (product.getQuantity() < item.getQuantity()) {
				showCheckoutError(request, response, "Sản phẩm \"" + item.getName() + "\" chỉ còn "
						+ product.getQuantity() + " sản phẩm trong kho, vui lòng cập nhật lại giỏ hàng.",
						shippingMethod);
				return;
			}
		}

		long total = 0;
		for (CartItem item : cart.values()) {
			total += item.getSubtotal();
		}

		// Xac dinh lai voucher va so tien giam gia ngay tren server (khong tin du lieu tu client)
		int discount = 0;
		Voucher voucher = null;
		String voucherCode = CartServlet.getAppliedVoucherCode(request);
		if (voucherCode != null) {
			voucher = voucherDAO.findByCode(voucherCode);
			if (voucher != null && voucher.isUsable() && total >= voucher.getMinOrderValue()) {
				discount = voucher.calculateDiscount(total);
			} else {
				voucher = null;
				CartServlet.clearVoucher(request);
			}
		}

		// Phi van chuyen luon duoc tinh lai tren server, khong tin gia tri tu client
		int shippingFee = ShippingUtil.getFee(shippingMethod);

		Date now = new Date();
		Bill bill = new Bill();
		bill.setUserId(user.getId());
		bill.setCode("HD" + now.getTime());
		bill.setCreatedAt(now);
		bill.setTotal(0);
		// Don hang moi dat luon o trang thai "Cho xac nhan", quan ly/nhan vien se cap
		// nhat dan theo luong: Cho xac nhan -> Dang chuan bi -> Dang giao -> Da giao
		bill.setStatus(BillDAO.STATUS_WAITING);
		bill.setReceiverName(receiverName);
		bill.setReceiverPhone(receiverPhone);
		bill.setReceiverAddress(receiverAddress);
		bill.setShippingMethod(ShippingUtil.getLabel(shippingMethod));
		bill.setShippingFee(shippingFee);
		if (voucher != null) {
			bill.setVoucherCode(voucher.getCode());
			bill.setDiscountAmount(discount);
		}

		List<BillDetail> billDetails = new ArrayList<>();
		for (CartItem item : cart.values()) {
			billDetails.add(new BillDetail(null, null, item.getProductId(), item.getQuantity(), item.getPrice()));
		}

		int billId = billDAO.createWithBillDetails(bill, billDetails);
		if (billId > 0) {
			// Don hang duoc ghi nhan ngay -> tru ton kho luon de tranh ban vuot so luong,
			// neu don sau nay bi huy thi so luong se duoc hoan lai (xem BillDAO.updateStatus)
			for (CartItem item : cart.values()) {
				productDAO.decreaseStock(item.getProductId(), item.getQuantity());
			}
			if (voucher != null) {
				voucherDAO.incrementUsedCount(voucher.getCode());
			}
			cart.clear();
			CartServlet.clearVoucher(request);
			response.sendRedirect(request.getContextPath() + "/hoa-don?id=" + billId);
		} else {
			showCheckoutError(request, response, "Đặt hàng thất bại, vui lòng thử lại.", shippingMethod);
		}
	}

	// Hien thi lai trang thanh toan kem thong bao loi, giu nguyen gio hang, voucher va phuong thuc giao hang dang chon
	private void showCheckoutError(HttpServletRequest request, HttpServletResponse response, String errorMessage,
			String shippingMethod) throws ServletException, IOException {
		Map<Integer, CartItem> cart = CartServlet.getCart(request);
		long total = 0;
		for (CartItem item : cart.values()) {
			total += item.getSubtotal();
		}
		int discount = 0;
		Voucher voucher = null;
		String voucherCode = CartServlet.getAppliedVoucherCode(request);
		if (voucherCode != null) {
			voucher = voucherDAO.findByCode(voucherCode);
			if (voucher != null && voucher.isUsable() && total >= voucher.getMinOrderValue()) {
				discount = voucher.calculateDiscount(total);
			}
		}
		if (!ShippingUtil.isValid(shippingMethod)) {
			shippingMethod = "standard";
		}
		int shippingFee = ShippingUtil.getFee(shippingMethod);

		request.setAttribute("error", errorMessage);
		request.setAttribute("cartItems", cart.values());
		request.setAttribute("cartTotal", total);
		request.setAttribute("appliedVoucher", voucher);
		request.setAttribute("discountAmount", discount);
		request.setAttribute("shippingMethods", ShippingUtil.getAllMethods());
		request.setAttribute("selectedShippingMethod", shippingMethod);
		request.setAttribute("shippingFee", shippingFee);
		request.setAttribute("finalTotal", total - discount + shippingFee);
		request.getRequestDispatcher("/views/checkout/view.jsp").forward(request, response);
	}
}
