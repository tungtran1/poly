package com.polygear.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Review;
import com.polygear.util.JdbcUtil;

/**
 * Quan ly danh gia / binh luan san pham.
 */
public class ReviewDAO {

	public int create(Review review) {
		String sql = "INSERT INTO reviews(product_id, user_id, rating, comment, created_at) VALUES (?, ?, ?, ?, GETDATE())";
		try {
			return JdbcUtil.executeUpdate(sql, review.getProductId(), review.getUserId(), review.getRating(),
					review.getComment());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Danh sach danh gia cua 1 san pham, kem ten nguoi danh gia, moi nhat truoc
	public List<Review> findByProductId(Integer productId) {
		String sql = "SELECT r.*, u.full_name AS user_full_name FROM reviews r "
				+ "INNER JOIN users u ON r.user_id = u.id WHERE r.product_id = ? ORDER BY r.created_at DESC";
		List<Review> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, productId);
			while (rs.next()) {
				Review r = new Review();
				r.setId(rs.getInt("id"));
				r.setProductId(rs.getInt("product_id"));
				r.setUserId(rs.getInt("user_id"));
				r.setRating(rs.getInt("rating"));
				r.setComment(rs.getString("comment"));
				r.setCreatedAt(rs.getTimestamp("created_at"));
				r.setUserFullName(rs.getString("user_full_name"));
				list.add(r);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// Diem trung binh danh gia cua 1 san pham (0 neu chua co danh gia nao)
	public double getAverageRating(Integer productId) {
		String sql = "SELECT AVG(CAST(rating AS FLOAT)) AS avg_rating FROM reviews WHERE product_id = ?";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, productId);
			if (rs.next()) {
				double avg = rs.getDouble("avg_rating");
				return rs.wasNull() ? 0 : avg;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int countByProductId(Integer productId) {
		String sql = "SELECT COUNT(*) AS total FROM reviews WHERE product_id = ?";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, productId);
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Kiem tra khach hang da mua san pham nay va don da giao chua (chi cho phep danh gia khi da nhan hang)
	public boolean hasPurchased(Integer userId, Integer productId) {
		String sql = "SELECT TOP 1 bd.id FROM bill_details bd INNER JOIN bills b ON bd.bill_id = b.id "
				+ "WHERE b.user_id = ? AND bd.product_id = ? AND b.status = 'delivered'";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, userId, productId);
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean hasReviewed(Integer userId, Integer productId) {
		String sql = "SELECT id FROM reviews WHERE user_id = ? AND product_id = ?";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, userId, productId);
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
