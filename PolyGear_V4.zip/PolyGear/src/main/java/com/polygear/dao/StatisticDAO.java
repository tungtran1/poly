package com.polygear.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.polygear.entity.BestSellingProduct;
import com.polygear.entity.RevenueByDay;
import com.polygear.util.DateUtil;
import com.polygear.util.JdbcUtil;

public class StatisticDAO {

	// Tong doanh thu tu cac don hang da giao thanh cong (delivered)
	public long getTotalRevenue() {
		String sql = "SELECT ISNULL(SUM(total), 0) AS total_revenue FROM bills WHERE status = 'delivered'";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql);
			if (rs.next()) {
				return rs.getLong("total_revenue");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Tong so don hang (tinh tat ca trang thai, tru don da huy)
	public int getTotalOrders() {
		String sql = "SELECT COUNT(*) AS total FROM bills WHERE status <> 'cancel'";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql);
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Tong so khach hang (khong tinh tai khoan quan tri)
	public int getTotalCustomers() {
		String sql = "SELECT COUNT(*) AS total FROM users WHERE role = 0";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql);
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Tong so san pham dang ban
	public int getTotalProducts() {
		String sql = "SELECT COUNT(*) AS total FROM products WHERE active = 1";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql);
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// So don hang dang cho xu ly (chua giao, chua huy) - de canh bao quan ly xu ly
	public int getPendingOrders() {
		String sql = "SELECT COUNT(*) AS total FROM bills WHERE status IN ('waiting', 'preparing', 'shipping')";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql);
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// So san pham sap het hang (ton kho <= nguong canh bao), phuc vu thong bao het hang
	public int getLowStockCount(int threshold) {
		String sql = "SELECT COUNT(*) AS total FROM products WHERE active = 1 AND quantity <= ?";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, threshold);
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public List<BestSellingProduct> getTop5BestSellingProducts(Date fromDate, Date toDate) throws SQLException {
		List<BestSellingProduct> result = new ArrayList<>();
		String sql = "{CALL sp_top_5_best_selling_products(?, ?)}";

		String fromDateStr = DateUtil.toString(fromDate, "yyyy-MM-dd");
		String toDateStr = DateUtil.toString(toDate, "yyyy-MM-dd");

		ResultSet rs = JdbcUtil.executeQuery(sql, fromDate == null ? null : fromDateStr,
				toDate == null ? null : toDateStr);

		while (rs.next()) {
			BestSellingProduct dto = new BestSellingProduct();
			dto.setProductId(rs.getInt("product_id"));
			dto.setProductName(rs.getString("product_name"));
			dto.setTotalQuantitySold(rs.getInt("total_quantity_sold"));
			dto.setTotalRevenue(rs.getLong("total_revenue"));
			result.add(dto);
		}
		return result;
	}

	public List<RevenueByDay> getRevenueByDay(Date fromDate, Date toDate) throws SQLException {
		List<RevenueByDay> result = new ArrayList<>();
		String sql = "{CALL sp_revenue_by_day(?, ?)}";

		String fromDateStr = DateUtil.toString(fromDate, "yyyy-MM-dd");
		String toDateStr = DateUtil.toString(toDate, "yyyy-MM-dd");

		ResultSet rs = JdbcUtil.executeQuery(sql, fromDate == null ? null : fromDateStr,
				toDate == null ? null : toDateStr);

		while (rs.next()) {
			RevenueByDay dto = new RevenueByDay();
			dto.setRevenueDate(rs.getDate("revenue_date"));
			dto.setTotalBills(rs.getInt("total_bills"));
			dto.setTotalRevenue(rs.getLong("total_revenue"));
			result.add(dto);
		}
		return result;
	}
}
