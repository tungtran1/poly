package com.polygear.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Bill;
import com.polygear.entity.BillDetail;
import com.polygear.util.JdbcUtil;

public class BillDAO implements CrudDAO<Bill, Integer> {

	// Luong trang thai don hang: waiting -> preparing -> shipping -> delivered
	// Co the huy (cancel) o bat ky buoc nao truoc khi "delivered"
	public static final String STATUS_WAITING = "waiting"; // Cho xac nhan
	public static final String STATUS_PREPARING = "preparing"; // Dang chuan bi
	public static final String STATUS_SHIPPING = "shipping"; // Dang giao
	public static final String STATUS_DELIVERED = "delivered"; // Da giao
	public static final String STATUS_CANCEL = "cancel"; // Da huy

	// Thu tu cac trang thai trong luong xu ly binh thuong (khong tinh cancel)
	private static final List<String> STATUS_FLOW = List.of(STATUS_WAITING, STATUS_PREPARING, STATUS_SHIPPING,
			STATUS_DELIVERED);

	// Khong new BillDetailDAO() nhu mot field de tranh vong lap khoi tao giua 2 DAO
	private BillDetailDAO billDetailDAO() {
		return new BillDetailDAO();
	}

	@Override
	public int create(Bill entity) {
		String sql = "INSERT INTO bills(user_id, code, created_at, total, status, receiver_name, receiver_phone, receiver_address, voucher_code, discount_amount, shipping_method, shipping_fee) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getUserId(), entity.getCode(), toTimestamp(entity.getCreatedAt()),
					entity.getTotal(), entity.getStatus(), entity.getReceiverName(), entity.getReceiverPhone(),
					entity.getReceiverAddress(), entity.getVoucherCode(), entity.getDiscountAmount(),
					entity.getShippingMethod(), entity.getShippingFee());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int update(Bill entity) {
		String sql = "UPDATE bills SET user_id = ?, code = ?, created_at = ?, total = ?, status = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getUserId(), entity.getCode(), toTimestamp(entity.getCreatedAt()),
					entity.getTotal(), entity.getStatus(), entity.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delete(Integer id) {
		String sql = "DELETE FROM bills WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// SUA LOI: ban goc tra ve null -> gay NullPointerException moi khi duoc goi
	@Override
	public List<Bill> findAll() {
		String sql = "SELECT * FROM bills ORDER BY id DESC";
		return findBySql(sql);
	}

	// SUA LOI: ban goc tra ve null
	@Override
	public Bill findById(Integer id) {
		String sql = "SELECT * FROM bills WHERE id = ?";
		List<Bill> list = findBySql(sql, id);
		return list.isEmpty() ? null : list.get(0);
	}

	// SUA LOI: ban goc tra ve null khien moi noi goi ham nay (findByIdAndUserId,
	// findByUserId...) deu bi NullPointerException
	@Override
	public List<Bill> findBySql(String sql, Object... value) {
		List<Bill> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, value);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public Bill findByIdAndUserId(Integer id, Integer userId) {
		String sql = "SELECT * FROM bills WHERE id = ? AND user_id = ?";
		List<Bill> bills = findBySql(sql, id, userId);
		return bills.isEmpty() ? null : bills.get(0);
	}

	public int createWithBillDetails(Bill bill, List<BillDetail> billDetails) {
		String sqlBill = "INSERT INTO bills(user_id, code, created_at, total, status, receiver_name, receiver_phone, receiver_address, voucher_code, discount_amount, shipping_method, shipping_fee) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement stmt = JdbcUtil.createPreStmt(sqlBill, bill.getUserId(), bill.getCode(),
					toTimestamp(bill.getCreatedAt()), bill.getTotal(), bill.getStatus(), bill.getReceiverName(),
					bill.getReceiverPhone(), bill.getReceiverAddress(), bill.getVoucherCode(),
					bill.getDiscountAmount(), bill.getShippingMethod(), bill.getShippingFee());
			int rs = stmt.executeUpdate();
			if (rs > 0) {
				ResultSet generatedKeys = stmt.getGeneratedKeys();
				if (generatedKeys.next()) {
					int billId = generatedKeys.getInt(1);
					BillDetailDAO billDetailDAO = billDetailDAO();
					for (BillDetail billDetail : billDetails) {
						billDetail.setBillId(billId);
						billDetailDAO.create(billDetail);
					}
					// updateTotal se tinh lai tong tien hang (subtotal), sau do tru giam gia
					// va cong phi van chuyen de ra tong tien cuoi cung phai thanh toan
					updateTotal(billId);
					String sqlAdjust = "UPDATE bills SET total = CASE WHEN total - ? + ? < 0 THEN 0 ELSE total - ? + ? END WHERE id = ?";
					JdbcUtil.executeUpdate(sqlAdjust, bill.getDiscountAmount(), bill.getShippingFee(),
							bill.getDiscountAmount(), bill.getShippingFee(), billId);
					return billId;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * Cap nhat trang thai don hang theo dung luong: waiting -> preparing -> shipping -> delivered.
	 * Cho phep huy (cancel) o bat ky buoc nao truoc "delivered". Khong the thay doi trang thai
	 * cua don da "delivered" hoac da "cancel".
	 */
	public int updateStatus(Integer billId, String newStatus) {
		Bill bill = this.findById(billId);
		if (bill == null) {
			return 0;
		}
		String currentStatus = bill.getStatus();

		// Da giao hoac da huy -> khong cho phep cap nhat them
		if (STATUS_DELIVERED.equals(currentStatus) || STATUS_CANCEL.equals(currentStatus)) {
			return 0;
		}

		if (STATUS_CANCEL.equals(newStatus)) {
			int rs = doUpdateStatus(billId, STATUS_CANCEL);
			if (rs > 0) {
				// Ton kho da bi tru ngay luc dat hang -> khi huy phai hoan lai
				restoreStock(billId);
				restoreVoucher(billId);
			}
			return rs;
		}

		int currentIndex = STATUS_FLOW.indexOf(currentStatus);
		int newIndex = STATUS_FLOW.indexOf(newStatus);
		// Chi cho phep chuyen sang buoc ke tiep (khong cho nhay coc hoac lui trang thai)
		if (currentIndex >= 0 && newIndex == currentIndex + 1) {
			return doUpdateStatus(billId, newStatus);
		}
		return 0;
	}

	// Hoan lai so luong ton kho cho tung san pham trong hoa don bi huy
	private void restoreStock(Integer billId) {
		ProductDAO productDAO = new ProductDAO();
		List<BillDetail> details = billDetailDAO().findByBillId(billId);
		for (BillDetail detail : details) {
			productDAO.increaseStock(detail.getProductId(), detail.getQuantity());
		}
	}

	// Hoan lai luot su dung voucher (neu co) khi don hang bi huy
	private void restoreVoucher(Integer billId) {
		Bill bill = findById(billId);
		if (bill != null && bill.getVoucherCode() != null && !bill.getVoucherCode().isBlank()) {
			new VoucherDAO().decrementUsedCount(bill.getVoucherCode());
		}
	}

	private int doUpdateStatus(Integer billId, String status) {
		String sql = "UPDATE bills SET status = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, status, billId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int updateTotal(Integer billId) {
		List<BillDetail> billDetails = billDetailDAO().findByBillId(billId);
		int total = 0;
		for (BillDetail billDetail : billDetails) {
			total += billDetail.getPrice() * billDetail.getQuantity();
		}
		String sql = "UPDATE bills SET total = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, total, billId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public List<Bill> findByUserId(Integer userId) {
		String sql = "SELECT * FROM bills WHERE user_id = ? ORDER BY CASE status "
				+ "WHEN 'waiting' THEN 1 WHEN 'preparing' THEN 2 WHEN 'shipping' THEN 3 "
				+ "WHEN 'delivered' THEN 4 WHEN 'cancel' THEN 5 ELSE 6 END, id DESC";
		return findBySql(sql, userId);
	}

	// Tim kiem hoa don theo ma don hang (dung cho quan ly)
	public List<Bill> searchByCode(String code) {
		String sql = "SELECT * FROM bills WHERE code LIKE ? ORDER BY id DESC";
		return findBySql(sql, "%" + code.trim() + "%");
	}

	private static java.sql.Timestamp toTimestamp(java.util.Date date) {
		return date == null ? null : new java.sql.Timestamp(date.getTime());
	}

	private Bill mapRow(ResultSet rs) throws Exception {
		Integer id = rs.getInt("id");
		Integer userId = rs.getInt("user_id");
		String code = rs.getString("code");
		java.sql.Timestamp createdAt = rs.getTimestamp("created_at");
		int total = rs.getInt("total");
		String status = rs.getString("status");
		Bill bill = new Bill(id, userId, code, createdAt, total, status);
		bill.setReceiverName(rs.getString("receiver_name"));
		bill.setReceiverPhone(rs.getString("receiver_phone"));
		bill.setReceiverAddress(rs.getString("receiver_address"));
		bill.setVoucherCode(rs.getString("voucher_code"));
		bill.setDiscountAmount(rs.getInt("discount_amount"));
		bill.setShippingMethod(rs.getString("shipping_method"));
		bill.setShippingFee(rs.getInt("shipping_fee"));
		return bill;
	}
}
