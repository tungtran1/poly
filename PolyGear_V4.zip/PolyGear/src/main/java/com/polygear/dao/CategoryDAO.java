package com.polygear.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Category;
import com.polygear.util.JdbcUtil;

public class CategoryDAO implements CrudDAO<Category, Integer> {
	// Them moi loai phu kien dien thoai
	@Override
	public int create(Category entity) {
		String sql = "INSERT INTO categories(name, active) values (?, ?)";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getName(), entity.isActive());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Cap nhat loai phu kien dien thoai
	@Override
	public int update(Category entity) {
		String sql = "UPDATE categories SET name = ?, active = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getName(), entity.isActive(), entity.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Xoa loai phu kien dien thoai
	@Override
	public int delete(Integer id) {
		String sql = "DELETE FROM categories WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Lay danh sach loai phu kien dien thoai
	@Override
	public List<Category> findAll() {
		List<Category> list = new ArrayList<>();
		String sql = "SELECT * FROM categories";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// Lay danh sach loai phu kien dang hoat dong (dung cho trang khach hang)
	public List<Category> findAllActive() {
		List<Category> list = new ArrayList<>();
		String sql = "SELECT * FROM categories WHERE active = ?";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, 1);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// Lay thong tin loai phu kien dien thoai theo id
	@Override
	public Category findById(Integer id) {
		Category category = null;
		String sql = "SELECT * FROM categories WHERE id = ?";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, id);
			if (rs.next()) {
				category = mapRow(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return category;
	}

	@Override
	public List<Category> findBySql(String sql, Object... values) {
		List<Category> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, values);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int countProductInCategory(int categoryId) {
		int rs = 0;
		String sql = "select count(id) as num_product from products where category_id = ?";
		try {
			ResultSet resultSet = JdbcUtil.executeQuery(sql, categoryId);
			if (resultSet.next()) {
				rs = resultSet.getInt("num_product");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}

	private Category mapRow(ResultSet rs) throws Exception {
		Integer id = rs.getInt("id");
		String name = rs.getString("name");
		boolean active = rs.getBoolean("active");
		return new Category(id, name, active);
	}
}
