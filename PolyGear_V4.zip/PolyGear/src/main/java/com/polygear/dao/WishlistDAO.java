package com.polygear.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Product;
import com.polygear.entity.Wishlist;
import com.polygear.util.JdbcUtil;

/**
 * Quan ly danh sach san pham yeu thich cua khach hang.
 */
public class WishlistDAO {

	public boolean exists(Integer userId, Integer productId) {
		String sql = "SELECT id FROM wishlists WHERE user_id = ? AND product_id = ?";
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, userId, productId);
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public int add(Integer userId, Integer productId) {
		if (exists(userId, productId)) {
			return 0;
		}
		String sql = "INSERT INTO wishlists(user_id, product_id, created_at) VALUES (?, ?, GETDATE())";
		try {
			return JdbcUtil.executeUpdate(sql, userId, productId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int remove(Integer userId, Integer productId) {
		String sql = "DELETE FROM wishlists WHERE user_id = ? AND product_id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, userId, productId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Danh sach san pham yeu thich cua 1 khach hang (tra ve luon thong tin san pham)
	public List<Product> findProductsByUserId(Integer userId) {
		String sql = "SELECT p.* FROM products p INNER JOIN wishlists w ON p.id = w.product_id "
				+ "WHERE w.user_id = ? ORDER BY w.created_at DESC";
		return new ProductDAO().findBySql(sql, userId);
	}

	// Danh sach id san pham da yeu thich, dung de hien thi trang thai trai tim tren giao dien
	public List<Integer> findProductIdsByUserId(Integer userId) {
		String sql = "SELECT product_id FROM wishlists WHERE user_id = ?";
		List<Integer> ids = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, userId);
			while (rs.next()) {
				ids.add(rs.getInt("product_id"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ids;
	}
}
