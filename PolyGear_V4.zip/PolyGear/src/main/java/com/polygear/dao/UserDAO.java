package com.polygear.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.User;
import com.polygear.util.JdbcUtil;

public class UserDAO implements CrudDAO<User, Integer> {

	@Override
	public int create(User entity) {
		String sql = "INSERT INTO users(email, password, full_name, phone, role, active) values (?, ?, ?, ?, ?, ?)";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getEmail(), entity.getPassword(), entity.getFullName(),
					entity.getPhone(), entity.getRole(), entity.isActive());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int update(User entity) {
		String sql = "UPDATE users SET email = ?, password = ?, full_name = ?, phone = ?, role = ?, active = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getEmail(), entity.getPassword(), entity.getFullName(),
					entity.getPhone(), entity.getRole(), entity.isActive(), entity.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delete(Integer id) {
		String sql = "DELETE FROM users WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<User> findAll() {
		String sql = "SELECT * FROM users";
		return findBySql(sql);
	}

	@Override
	public User findById(Integer id) {
		String sql = "SELECT * FROM users WHERE id = ?";
		List<User> list = findBySql(sql, id);
		return list.isEmpty() ? null : list.get(0);
	}

	@Override
	public List<User> findBySql(String sql, Object... value) {
		List<User> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, value);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public User findByEmail(String email) {
		String sql = "SELECT * FROM users WHERE email = ?";
		List<User> list = findBySql(sql, email);
		return list.isEmpty() ? null : list.get(0);
	}

	public List<User> findByRole(int role) {
		String sql = "SELECT * FROM users WHERE role = ?";
		return findBySql(sql, role);
	}

	// Tim kiem tai khoan theo dung 1 vai tro (khach hang / nhan vien / quan tri) theo ten, email hoac sdt
	public List<User> searchByRole(int role, String keyword) {
		StringBuilder sql = new StringBuilder("SELECT * FROM users WHERE role = ?");
		List<Object> params = new ArrayList<>();
		params.add(role);
		if (keyword != null && !keyword.isBlank()) {
			sql.append(" AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)");
			String like = "%" + keyword.trim() + "%";
			params.add(like);
			params.add(like);
			params.add(like);
		}
		sql.append(" ORDER BY id DESC");
		return findBySql(sql.toString(), params.toArray());
	}

	public int updateUserInfo(User entity) {
		String sql;
		boolean changePassword = (entity.getPassword() != null && !entity.getPassword().isBlank());

		if (changePassword) {
			sql = "UPDATE users SET email = ?, password = ?, full_name = ?, phone = ?, active = ? WHERE id = ?";
		} else {
			sql = "UPDATE users SET email = ?, full_name = ?, phone = ?, active = ? WHERE id = ?";
		}

		try {
			if (changePassword) {
				return JdbcUtil.executeUpdate(sql, entity.getEmail(), entity.getPassword(), entity.getFullName(),
						entity.getPhone(), entity.isActive(), entity.getId());
			} else {
				return JdbcUtil.executeUpdate(sql, entity.getEmail(), entity.getFullName(), entity.getPhone(),
						entity.isActive(), entity.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int updateStatus(Integer id, boolean active) {
		String sql = "UPDATE users SET active = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, active, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int updatePassword(Integer id, String newPassword) {
		String sql = "UPDATE users SET password = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, newPassword, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// ==== Chuc nang "Quen mat khau" ====

	public int saveResetToken(Integer userId, String token, long expiryEpochMillis) {
		String sql = "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, token, expiryEpochMillis, userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public User findByResetToken(String token) {
		String sql = "SELECT * FROM users WHERE reset_token = ?";
		List<User> list = findBySql(sql, token);
		return list.isEmpty() ? null : list.get(0);
	}

	public int resetPasswordWithToken(Integer userId, String newPassword) {
		String sql = "UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, newPassword, userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	private User mapRow(ResultSet rs) throws Exception {
		Integer id = rs.getInt("id");
		String email = rs.getString("email");
		String password = rs.getString("password");
		String fullName = rs.getString("full_name");
		String phone = rs.getString("phone");
		int role = rs.getInt("role");
		boolean active = rs.getBoolean("active");
		String resetToken = rs.getString("reset_token");
		long resetExpiry = rs.getLong("reset_token_expiry");
		User user = new User(id, email, password, fullName, phone, role, active);
		user.setResetToken(resetToken);
		user.setResetTokenExpiry(rs.wasNull() ? null : resetExpiry);
		return user;
	}
}
