package com.polygear.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Brand;
import com.polygear.util.JdbcUtil;

public class BrandDAO implements CrudDAO<Brand, Integer> {
	// Them moi thuong hieu
	@Override
	public int create(Brand entity) {
		String sql = "INSERT INTO brands(name, active) values (?, ?)";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getName(), entity.isActive());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Cap nhat thuong hieu
	@Override
	public int update(Brand entity) {
		String sql = "UPDATE brands SET name = ?, active = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getName(), entity.isActive(), entity.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Xoa thuong hieu
	@Override
	public int delete(Integer id) {
		String sql = "DELETE FROM brands WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Lay danh sach thuong hieu
	@Override
	public List<Brand> findAll() {
		String sql = "SELECT * FROM brands";
		return findBySql(sql);
	}

	// Lay danh sach thuong hieu dang hoat dong (dung cho trang khach hang)
	public List<Brand> findAllActive() {
		String sql = "SELECT * FROM brands WHERE active = ?";
		return findBySql(sql, 1);
	}

	// Lay thong tin thuong hieu theo id
	@Override
	public Brand findById(Integer id) {
		String sql = "SELECT * FROM brands WHERE id = ?";
		List<Brand> list = findBySql(sql, id);
		return list.isEmpty() ? null : list.get(0);
	}

	@Override
	public List<Brand> findBySql(String sql, Object... values) {
		List<Brand> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, values);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int countProductInBrand(int brandId) {
		int rs = 0;
		String sql = "select count(id) as num_product from products where brand_id = ?";
		try {
			ResultSet resultSet = JdbcUtil.executeQuery(sql, brandId);
			if (resultSet.next()) {
				rs = resultSet.getInt("num_product");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}

	private Brand mapRow(ResultSet rs) throws Exception {
		Integer id = rs.getInt("id");
		String name = rs.getString("name");
		boolean active = rs.getBoolean("active");
		return new Brand(id, name, active);
	}
}
