package com.polygear.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Voucher;
import com.polygear.util.JdbcUtil;

/**
 * Quan ly ma giam gia (voucher / coupon).
 */
public class VoucherDAO implements CrudDAO<Voucher, Integer> {

	@Override
	public int create(Voucher v) {
		String sql = "INSERT INTO vouchers(code, description, discount_percent, discount_amount, min_order_value, "
				+ "max_discount, quantity, used_count, start_date, end_date, active) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)";
		try {
			return JdbcUtil.executeUpdate(sql, v.getCode().trim().toUpperCase(), v.getDescription(),
					v.getDiscountPercent(), v.getDiscountAmount(), v.getMinOrderValue(), v.getMaxDiscount(),
					v.getQuantity(), toTimestamp(v.getStartDate()), toTimestamp(v.getEndDate()), v.isActive());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int update(Voucher v) {
		String sql = "UPDATE vouchers SET code = ?, description = ?, discount_percent = ?, discount_amount = ?, "
				+ "min_order_value = ?, max_discount = ?, quantity = ?, start_date = ?, end_date = ?, active = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, v.getCode().trim().toUpperCase(), v.getDescription(),
					v.getDiscountPercent(), v.getDiscountAmount(), v.getMinOrderValue(), v.getMaxDiscount(),
					v.getQuantity(), toTimestamp(v.getStartDate()), toTimestamp(v.getEndDate()), v.isActive(),
					v.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delete(Integer id) {
		String sql = "DELETE FROM vouchers WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<Voucher> findAll() {
		return findBySql("SELECT * FROM vouchers ORDER BY id DESC");
	}

	@Override
	public Voucher findById(Integer id) {
		List<Voucher> list = findBySql("SELECT * FROM vouchers WHERE id = ?", id);
		return list.isEmpty() ? null : list.get(0);
	}

	public Voucher findByCode(String code) {
		if (code == null || code.isBlank()) {
			return null;
		}
		List<Voucher> list = findBySql("SELECT * FROM vouchers WHERE code = ?", code.trim().toUpperCase());
		return list.isEmpty() ? null : list.get(0);
	}

	public boolean codeExists(String code) {
		return findByCode(code) != null;
	}

	// Tang so lan da su dung khi 1 don hang ap dung thanh cong voucher nay
	public int incrementUsedCount(String code) {
		String sql = "UPDATE vouchers SET used_count = used_count + 1 WHERE code = ?";
		try {
			return JdbcUtil.executeUpdate(sql, code.trim().toUpperCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Hoan lai luot su dung khi don hang bi huy
	public int decrementUsedCount(String code) {
		String sql = "UPDATE vouchers SET used_count = CASE WHEN used_count > 0 THEN used_count - 1 ELSE 0 END WHERE code = ?";
		try {
			return JdbcUtil.executeUpdate(sql, code.trim().toUpperCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<Voucher> findBySql(String sql, Object... values) {
		List<Voucher> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, values);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	private static Timestamp toTimestamp(java.util.Date date) {
		return date == null ? null : new Timestamp(date.getTime());
	}

	private Voucher mapRow(ResultSet rs) throws Exception {
		Voucher v = new Voucher();
		v.setId(rs.getInt("id"));
		v.setCode(rs.getString("code"));
		v.setDescription(rs.getString("description"));
		int discountPercent = rs.getInt("discount_percent");
		v.setDiscountPercent(rs.wasNull() ? null : discountPercent);
		int discountAmount = rs.getInt("discount_amount");
		v.setDiscountAmount(rs.wasNull() ? null : discountAmount);
		v.setMinOrderValue(rs.getInt("min_order_value"));
		int maxDiscount = rs.getInt("max_discount");
		v.setMaxDiscount(rs.wasNull() ? null : maxDiscount);
		v.setQuantity(rs.getInt("quantity"));
		v.setUsedCount(rs.getInt("used_count"));
		v.setStartDate(rs.getTimestamp("start_date"));
		v.setEndDate(rs.getTimestamp("end_date"));
		v.setActive(rs.getBoolean("active"));
		return v;
	}
}
