package com.polygear.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Product;
import com.polygear.util.JdbcUtil;

public class ProductDAO implements CrudDAO<Product, Integer> {

	@Override
	public int create(Product entity) {
		String sql = "INSERT INTO products(category_id, brand_id, name, description, image, price, quantity, active, discount_price, is_flash_sale) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getCategoryId(), entity.getBrandId(), entity.getName(),
					entity.getDescription(), entity.getImage(), entity.getPrice(), entity.getQuantity(),
					entity.isActive(), entity.getDiscountPrice(), entity.isFlashSale());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int update(Product entity) {
		String sql = "UPDATE products SET category_id = ?, brand_id = ?, name = ?, description = ?, image = ?, price = ?, quantity = ?, active = ?, discount_price = ?, is_flash_sale = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getCategoryId(), entity.getBrandId(), entity.getName(),
					entity.getDescription(), entity.getImage(), entity.getPrice(), entity.getQuantity(),
					entity.isActive(), entity.getDiscountPrice(), entity.isFlashSale(), entity.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delete(Integer id) {
		String sql = "DELETE FROM products WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<Product> findAll() {
		String sql = "SELECT * FROM products";
		return findBySql(sql);
	}

	@Override
	public Product findById(Integer id) {
		String sql = "SELECT * FROM products WHERE id = ?";
		List<Product> list = findBySql(sql, id);
		return list.isEmpty() ? null : list.get(0);
	}

	@Override
	public List<Product> findBySql(String sql, Object... value) {
		List<Product> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, value);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// Danh sach phu kien dang ban, tuy chon loc theo danh muc, thuong hieu va tu khoa tim kiem
	public List<Product> findForShop(Integer categoryId, Integer brandId, String keyword) {
		return findForShop(categoryId, brandId, keyword, null, null, null);
	}

	// Giu lai overload cu (khong loc thuong hieu) de tuong thich cac noi goi cu
	public List<Product> findForShop(Integer categoryId, String keyword) {
		return findForShop(categoryId, null, keyword, null, null, null);
	}

	/**
	 * Danh sach phu kien dang ban cho khach hang, ho tro day du:
	 * - Loc theo danh muc (categoryId), thuong hieu (brandId)
	 * - Tim kiem theo ten (keyword)
	 * - Loc theo khoang gia (minPrice, maxPrice)
	 * - Sap xep (sort): price_asc, price_desc, newest, best_selling. Mac dinh: moi nhat.
	 */
	public List<Product> findForShop(Integer categoryId, Integer brandId, String keyword, Integer minPrice,
			Integer maxPrice, String sort) {
		StringBuilder sql = new StringBuilder("SELECT p.* FROM products p WHERE p.active = 1");
		List<Object> params = new ArrayList<>();

		if (categoryId != null && categoryId > 0) {
			sql.append(" AND p.category_id = ?");
			params.add(categoryId);
		}
		if (brandId != null && brandId > 0) {
			sql.append(" AND p.brand_id = ?");
			params.add(brandId);
		}
		if (keyword != null && !keyword.isBlank()) {
			sql.append(" AND p.name LIKE ?");
			params.add("%" + keyword.trim() + "%");
		}
		if (minPrice != null && minPrice > 0) {
			sql.append(" AND p.price >= ?");
			params.add(minPrice);
		}
		if (maxPrice != null && maxPrice > 0) {
			sql.append(" AND p.price <= ?");
			params.add(maxPrice);
		}

		if ("price_asc".equals(sort)) {
			sql.append(" ORDER BY p.price ASC");
		} else if ("price_desc".equals(sort)) {
			sql.append(" ORDER BY p.price DESC");
		} else if ("best_selling".equals(sort)) {
			// San pham ban chay nhat (dua tren tong so luong da ban trong cac don khong bi huy)
			sql = new StringBuilder(
					"SELECT p.*, (SELECT ISNULL(SUM(bd.quantity), 0) FROM bill_details bd "
							+ "INNER JOIN bills b ON bd.bill_id = b.id "
							+ "WHERE bd.product_id = p.id AND b.status <> 'cancel') AS sold_count "
							+ "FROM products p WHERE p.active = 1");
			params.clear();
			if (categoryId != null && categoryId > 0) {
				sql.append(" AND p.category_id = ?");
				params.add(categoryId);
			}
			if (brandId != null && brandId > 0) {
				sql.append(" AND p.brand_id = ?");
				params.add(brandId);
			}
			if (keyword != null && !keyword.isBlank()) {
				sql.append(" AND p.name LIKE ?");
				params.add("%" + keyword.trim() + "%");
			}
			if (minPrice != null && minPrice > 0) {
				sql.append(" AND p.price >= ?");
				params.add(minPrice);
			}
			if (maxPrice != null && maxPrice > 0) {
				sql.append(" AND p.price <= ?");
				params.add(maxPrice);
			}
			sql.append(" ORDER BY sold_count DESC, p.id DESC");
		} else {
			// "newest" hoac mac dinh
			sql.append(" ORDER BY p.id DESC");
		}

		return findBySql(sql.toString(), params.toArray());
	}

	// San pham dang chay Flash Sale, hien thi tren trang chu
	public List<Product> findFlashSale() {
		String sql = "SELECT * FROM products WHERE active = 1 AND is_flash_sale = 1 AND discount_price IS NOT NULL ORDER BY id DESC";
		return findBySql(sql);
	}

	// ==== Quan ly ton kho ====

	// Tru ton kho sau khi ban (khong de am, tra ve so dong bi anh huong)
	public int decreaseStock(Integer productId, int quantitySold) {
		String sql = "UPDATE products SET quantity = quantity - ? WHERE id = ? AND quantity >= ?";
		try {
			return JdbcUtil.executeUpdate(sql, quantitySold, productId, quantitySold);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Hoan lai ton kho khi hoa don bi huy
	public int increaseStock(Integer productId, int quantity) {
		String sql = "UPDATE products SET quantity = quantity + ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, quantity, productId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	private Product mapRow(ResultSet rs) throws Exception {
		Integer id = rs.getInt("id");
		Integer categoryId = rs.getInt("category_id");
		String name = rs.getString("name");
		String description = rs.getString("description");
		String image = rs.getString("image");
		int price = rs.getInt("price");
		boolean active = rs.getBoolean("active");
		Product product = new Product(id, categoryId, name, description, image, price, active);
		int brandId = rs.getInt("brand_id");
		product.setBrandId(rs.wasNull() ? null : brandId);
		product.setQuantity(rs.getInt("quantity"));
		int discountPrice = rs.getInt("discount_price");
		product.setDiscountPrice(rs.wasNull() ? null : discountPrice);
		product.setFlashSale(rs.getBoolean("is_flash_sale"));
		return product;
	}
}
