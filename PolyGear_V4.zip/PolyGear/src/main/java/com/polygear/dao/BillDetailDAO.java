package com.polygear.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.polygear.entity.Bill;
import com.polygear.entity.BillDetail;
import com.polygear.entity.Product;
import com.polygear.util.JdbcUtil;

public class BillDetailDAO implements CrudDAO<BillDetail, Integer> {
	// Khong new BillDAO() nhu field de tranh vong lap khoi tao giua 2 DAO
	private ProductDAO productDAO = new ProductDAO();

	// Lay danh sach chi tiet hoa don theo billId
	public List<BillDetail> findByBillId(Integer billId) {
		String sql = "SELECT * FROM bill_details WHERE bill_id = ?";
		return findBySql(sql, billId);
	}

	// Them phu kien vao chi tiet hoa don (dung cho quay ban hang truc tiep)
	public int addProductToBill(Integer billId, Integer productId) {
		BillDAO billDAO = new BillDAO();
		Bill bill = billDAO.findById(billId);
		if (bill == null || !bill.getStatus().equals(BillDAO.STATUS_WAITING)) {
			return 0;
		}
		String sqlCheck = "SELECT * FROM bill_details WHERE bill_id = ? AND product_id = ?";
		try {
			List<BillDetail> list = this.findBySql(sqlCheck, billId, productId);
			if (!list.isEmpty()) {
				BillDetail billDetail = list.get(0);
				return this.updateQuantity(billId, productId, billDetail.getQuantity() + 1);
			} else {
				Product product = productDAO.findById(productId);
				String sqlInsert = "INSERT INTO bill_details(bill_id, product_id, quantity, price) VALUES(?, ?, ?, ?)";
				int rs = JdbcUtil.executeUpdate(sqlInsert, billId, productId, 1, product.getPrice());
				if (rs > 0) {
					billDAO.updateTotal(billId);
				}
				return rs;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// Cap nhat so luong cua mot phu kien trong chi tiet hoa don
	public int updateQuantity(Integer billId, Integer productId, int quantity) {
		BillDAO billDAO = new BillDAO();
		Bill bill = billDAO.findById(billId);
		if (bill != null && bill.getStatus().equals(BillDAO.STATUS_WAITING)) {
			if (quantity <= 0) {
				String sql = "DELETE FROM bill_details WHERE bill_id = ? AND product_id = ?";
				try {
					int rs = JdbcUtil.executeUpdate(sql, billId, productId);
					if (rs > 0) {
						billDAO.updateTotal(billId);
					}
					return rs;
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				String sql = "UPDATE bill_details SET quantity = ? WHERE bill_id = ? AND product_id = ?";
				try {
					int rs = JdbcUtil.executeUpdate(sql, quantity, billId, productId);
					if (rs > 0) {
						billDAO.updateTotal(billId);
					}
					return rs;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return 0;
	}

	@Override
	public int create(BillDetail entity) {
		String sql = "INSERT INTO bill_details(bill_id, product_id, quantity, price) values(?, ?, ?, ?)";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getBillId(), entity.getProductId(), entity.getQuantity(),
					entity.getPrice());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int update(BillDetail entity) {
		String sql = "UPDATE bill_details SET bill_id = ?, product_id = ?, quantity = ?, price = ? WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, entity.getBillId(), entity.getProductId(), entity.getQuantity(),
					entity.getPrice(), entity.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delete(Integer id) {
		String sql = "DELETE FROM bill_details WHERE id = ?";
		try {
			return JdbcUtil.executeUpdate(sql, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// SUA LOI: ban goc tra ve null
	@Override
	public List<BillDetail> findAll() {
		String sql = "SELECT * FROM bill_details";
		return findBySql(sql);
	}

	// SUA LOI: ban goc tra ve null
	@Override
	public BillDetail findById(Integer id) {
		String sql = "SELECT * FROM bill_details WHERE id = ?";
		List<BillDetail> list = findBySql(sql, id);
		return list.isEmpty() ? null : list.get(0);
	}

	// SUA LOI: ban goc tra ve null khien findByBillId() luon bi NullPointerException
	@Override
	public List<BillDetail> findBySql(String sql, Object... value) {
		List<BillDetail> list = new ArrayList<>();
		try {
			ResultSet rs = JdbcUtil.executeQuery(sql, value);
			while (rs.next()) {
				list.add(mapRow(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	private BillDetail mapRow(ResultSet rs) throws Exception {
		Integer id = rs.getInt("id");
		Integer billId = rs.getInt("bill_id");
		Integer productId = rs.getInt("product_id");
		int quantity = rs.getInt("quantity");
		int price = rs.getInt("price");
		return new BillDetail(id, billId, productId, quantity, price);
	}
}
