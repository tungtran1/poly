# PolyGear – Website bán phụ kiện điện thoại

Dự án Java Web (Servlet + JSP + JDBC, Jakarta EE 10 / Tomcat 10.1+, SQL Server) đã được **sửa lại toàn bộ, hết lỗi code** và bổ sung đầy đủ các chức năng: giỏ hàng, quên mật khẩu, lọc theo loại phụ kiện, hóa đơn.

## 1. Các lỗi đã sửa

- **pom.xml**: khai báo trùng 2 phiên bản Lombok gây lỗi khi build → chỉ giữ lại 1 bản (1.18.34).
- **BillDAO / BillDetailDAO**: các hàm `findAll()`, `findById()`, `findBySql()` bản gốc `return null` → gây `NullPointerException` bất cứ khi nào được gọi (kể cả khi xem hóa đơn). Đã viết lại đầy đủ.
- **ProductServlet**: form sửa phụ kiện gửi hidden field `productId` nhưng servlet đọc tham số `id` → luôn cập nhật sai sản phẩm (id = 0). Đã đồng bộ tên tham số `id` xuyên suốt (sửa, xoá).
- **FileUtil.upload()**: tạo thư mục trùng với đường dẫn file (thay vì tạo thư mục cha) → upload ảnh luôn thất bại. Đã sửa lại tạo đúng thư mục cha trước khi ghi file.
- **StatisticDAO**: định dạng ngày `to_date` bị dùng nhầm cho cả `from_date` → đã sửa.
- **created_at** của hóa đơn đổi từ `DATE` sang `DATETIME` để giữ đúng giờ đặt hàng.

## 2. Các chức năng mới

| Chức năng | Mô tả |
|---|---|
| **Giỏ hàng** | `/gio-hang` – thêm/sửa/xoá số lượng, không cần đăng nhập vẫn thêm được vào giỏ. |
| **Thanh toán** | `/thanh-toan` – yêu cầu đăng nhập, nhập thông tin người nhận, tạo hóa đơn từ giỏ hàng. |
| **Hóa đơn** | `/don-hang` (danh sách đơn của khách), `/hoa-don?id=` (chi tiết, có nút In hóa đơn). Admin xem toàn bộ tại `/manager/bills`. |
| **Lọc theo loại phụ kiện** | `/san-pham?categoryId=` – sidebar chọn loại, kèm ô tìm kiếm theo tên. |
| **Đăng ký tài khoản** | `/dang-ky` |
| **Quên mật khẩu** | `/quen-mat-khau` → gửi email chứa link (30 phút) → `/dat-lai-mat-khau?token=...` để đặt mật khẩu mới. |
| **Thông tin cá nhân / Đổi mật khẩu** | `/edit-profile`, `/change-pass` |

## 3. Cấu hình trước khi chạy

### 3.1. Cơ sở dữ liệu
Chạy file `polygear.sql` trên SQL Server (SSMS / Azure Data Studio) để tạo database `polygear` + dữ liệu mẫu.

Sửa thông tin kết nối trong `src/main/java/com/polygear/util/JdbcUtil.java` (host, database, username, password) cho đúng máy của bạn.

Tài khoản mẫu:
- Quản trị viên: `admin@gmail.com` / `123456`
- Khách hàng: `khachhang@gmail.com` / `123456`

### 3.2. Gửi email "Quên mật khẩu" (tuỳ chọn)
Mở `src/main/resources/mail.properties` và điền SMTP thật (ví dụ Gmail + App Password):

```
mail.smtp.host=smtp.gmail.com
mail.smtp.port=587
mail.username=your-email@gmail.com
mail.password=your-app-password
```

**Nếu không cấu hình**, hệ thống vẫn hoạt động: sau khi bấm "Quên mật khẩu", link đặt lại mật khẩu sẽ hiển thị thẳng trên màn hình (chế độ demo) để bạn vẫn test được chức năng mà không cần email thật.

### 3.3. Build & chạy
Import project vào Eclipse/IntelliJ dạng Maven project, build lại (`mvn clean package`), deploy file `.war` lên Tomcat 10.1+ (Jakarta EE 10), hoặc Run as → Run on Server nếu dùng Eclipse có cấu hình sẵn Tomcat.

Truy cập: `http://localhost:8080/PolyGear/`

## 5. Cập nhật mới: Quản lý khách hàng, tồn kho, thương hiệu

| Tính năng | Mô tả |
|---|---|
| **Quản lý tồn kho** | Bảng `products` có thêm cột `quantity`. Khi đặt hàng thành công, hệ thống tự trừ kho (`ProductDAO.decreaseStock`); khi admin **hủy hóa đơn** đã hoàn thành, kho được hoàn lại tự động. Trang `/san-pham` và giỏ hàng không cho mua vượt số lượng tồn. Trang `/manager/products` hiển thị số lượng tồn, cảnh báo "sắp hết"/"hết hàng". |
| **Thương hiệu** | Bảng `brands` mới (Samsung, Apple, Baseus, Anker, Ugreen...). Quản lý tại `/manager/brands` (thêm/sửa/ẩn). Sản phẩm gắn `brand_id`, khách hàng lọc theo thương hiệu tại `/san-pham?brandId=`. |
| **Tìm kiếm & lọc sản phẩm** | Trang quản lý `/manager/products` có thêm ô tìm theo tên + lọc theo danh mục/thương hiệu (trước đó chỉ có ở trang khách hàng). |
| **Quản lý khách hàng** | Trang `/manager/staff` bổ sung: tìm kiếm theo tên/email/SĐT, nút **xóa** tài khoản (xóa hẳn nếu chưa từng mua hàng, chỉ khóa nếu đã có lịch sử mua để giữ dữ liệu hóa đơn), nút xem **lịch sử mua hàng** (dẫn tới `/manager/bills?userId=`). |
| **Hóa đơn** | `/manager/bills` có thêm ô tìm theo mã đơn và nút **hủy đơn nhanh** ngay trong danh sách. |

**Lưu ý khi cập nhật CSDL**: file `polygear.sql` đã được sửa để tạo thêm bảng `brands` và cột `quantity`, `brand_id` trong `products`. Chỉ cần chạy lại toàn bộ file này (nó tự `DROP DATABASE` rồi tạo lại) là có đủ schema + dữ liệu mẫu mới. Nếu bạn đã có dữ liệu thật muốn giữ lại, hãy tự viết `ALTER TABLE` thay vì chạy lại từ đầu.

## 6. Cấu trúc thư mục chính


```
src/main/java/com/polygear/
  entity/    - các lớp thực thể (User, Product, Category, Bill, BillDetail, CartItem...)
  dao/       - tầng truy xuất dữ liệu
  servlet/   - các servlet xử lý nghiệp vụ
  util/      - tiện ích dùng chung (JDBC, upload file, gửi mail, filter...)
src/main/webapp/views/ - toàn bộ giao diện JSP
polygear.sql           - script tạo database + dữ liệu mẫu
```

## 3. Bản cập nhật V2 – Bổ sung chức năng nâng cao

Đợt cập nhật này bổ sung các chức năng theo yêu cầu:

| Chức năng | Ghi chú |
|---|---|
| **Tìm kiếm nâng cao** | `/san-pham?keyword=&minPrice=&maxPrice=&sort=` – tìm theo tên, lọc theo khoảng giá. |
| **Sắp xếp** | `sort=price_asc / price_desc / newest / best_selling`. |
| **Bộ lọc** | Theo danh mục, thương hiệu (đã có) + khoảng giá (mới). |
| **Cảnh báo tồn kho** | Badge "Sắp hết hàng" khi `quantity <= 5`, "Hết hàng" khi bằng 0; dashboard hiển thị tổng số sản phẩm sắp hết. |
| **Đánh giá & bình luận** | `POST /san-pham/danh-gia` – chỉ khách đã mua và nhận hàng (status = delivered) mới được đánh giá 1 lần/sản phẩm. Bảng `reviews`. |
| **Flash Sale + Banner** | Trang chủ hiển thị khu Flash Sale (`products.is_flash_sale`, `discount_price`), cấu hình trong Quản lý phụ kiện. |
| **Danh sách yêu thích** | `/yeu-thich` – yêu cầu đăng nhập. Bảng `wishlists`. |
| **Mã giảm giá (Voucher)** | Áp dụng ở giỏ hàng/thanh toán, quản lý tại `/manager/vouchers`. Bảng `vouchers`. |
| **Trạng thái đơn hàng** | Mở rộng từ 3 lên 5 trạng thái: Chờ xác nhận → Đang chuẩn bị → Đang giao → Đã giao (huỷ được ở bất kỳ bước nào trước "Đã giao", hoàn lại tồn kho + lượt voucher khi huỷ). |
| **Dashboard quản trị** | `/manager/dashboard` – tổng doanh thu, đơn hàng, khách hàng, sản phẩm, top 5 bán chạy, doanh thu 7 ngày gần nhất. |
| **Validate dữ liệu** | Đã có sẵn (trùng email, giá/số lượng hợp lệ) + thêm validate mã voucher trùng, giá Flash Sale phải nhỏ hơn giá gốc. |
| **Responsive** | Toàn bộ giao diện dùng Bootstrap 5 (đã responsive sẵn cho điện thoại/tablet). |
| **Trang lỗi thân thiện** | 404/500 (có sẵn) + giỏ hàng rỗng, thanh toán thất bại hiển thị thông báo rõ ràng ngay trên trang. |

### Chưa triển khai trong bản này (đề xuất làm tiếp)
- **Nhiều ảnh/sản phẩm**: hiện mỗi sản phẩm vẫn 1 ảnh đại diện; cần thêm bảng `product_images` + gallery ở trang chi tiết.
- **Phân quyền 3 cấp (Admin / Nhân viên / Khách hàng)**: hiện chỉ có 2 cấp (Admin toàn quyền / Khách hàng). Muốn tách quyền Nhân viên (chỉ xử lý đơn hàng, không quản lý voucher/dashboard) cần đổi cột `users.role` từ BIT sang INT và cập nhật `AuthFilter`.

### Cập nhật database
File `polygear.sql` đã được cập nhật đầy đủ (chạy lại từ đầu sẽ tạo DB mới có tất cả bảng/cột mới: `wishlists`, `reviews`, `vouchers`, `products.discount_price`, `products.is_flash_sale`, `bills.voucher_code`, `bills.discount_amount`, `bills.status` mở rộng 5 giá trị). Nếu đã có DB cũ, cần chạy `DROP DATABASE polygear` trước hoặc tự ALTER thủ công theo các câu lệnh tương ứng trong file.

## 4. Bản cập nhật V3 – Hủy đơn cho khách hàng + Phân quyền 3 cấp

### Khách hàng tự hủy đơn hàng
- Tại trang "Đơn hàng của tôi" (`/don-hang`) và trang chi tiết hóa đơn (`/hoa-don?id=`), khách hàng có nút **Hủy đơn hàng**.
- Chỉ được hủy khi đơn đang ở trạng thái **Chờ xác nhận** hoặc **Đang chuẩn bị**. Khi đơn đã **Đang giao** trở đi, khách phải liên hệ cửa hàng để được hỗ trợ.
- Khi hủy: tồn kho được hoàn lại, lượt sử dụng voucher (nếu có) cũng được hoàn lại — dùng chung logic với `BillDAO.updateStatus`.

### Phân quyền 3 cấp: Quản trị viên / Nhân viên / Khách hàng
Cột `users.role` đổi từ `BIT` sang `INT`:
- `0` = **Khách hàng** – chỉ mua sắm, không vào được khu quản trị.
- `1` = **Quản trị viên (Admin)** – toàn quyền.
- `2` = **Nhân viên (Staff)** – quyền hạn chế, do Admin tạo tài khoản (không tự đăng ký được).

| Khu vực quản trị | Admin | Nhân viên |
|---|---|---|
| Dashboard tổng quan | ✅ | ✅ |
| Quản lý phụ kiện | ✅ | ✅ |
| Quản lý hóa đơn (xử lý đơn hàng) | ✅ | ✅ |
| Quản lý khách hàng (xem/khóa) | ✅ | ✅ |
| Quản lý loại phụ kiện / thương hiệu | ✅ | ❌ |
| Quản lý mã giảm giá | ✅ | ❌ |
| Quản lý nhân viên | ✅ | ❌ |

Tài khoản demo:
- Admin: `admin@gmail.com` / `123456`
- Nhân viên: `nhanvien@gmail.com` / `123456`
- Khách hàng: `khachhang@gmail.com` / `123456`

Nhân viên truy cập nhầm khu vực chỉ dành cho Admin sẽ thấy trang báo lỗi **403 – Không có quyền truy cập** (`views/error/403.jsp`), thay vì bị đá về trang đăng nhập.

## 5. Bản cập nhật V4 – Thu hẹp quyền Nhân viên, phí vận chuyển, biểu đồ doanh thu

### Thu hẹp quyền Nhân viên
Nhân viên (role = 2) giờ **chỉ** được vào:
- `/manager/bills` – xử lý đơn hàng (đây là công việc chính)
- `/manager/customers` – **chỉ xem**, không được khóa/mở khóa tài khoản (nút khóa chỉ hiện với Admin)

Nhân viên **không còn** được vào: Dashboard doanh thu, Quản lý phụ kiện, Danh mục, Thương hiệu, Voucher, Quản lý nhân viên. Vào nhầm sẽ thấy trang 403.

### Phí vận chuyển / đơn vị giao hàng
- Trang thanh toán (`/thanh-toan`) cho khách chọn 1 trong 3 phương thức giao hàng, phí tính lại phía server (không tin dữ liệu client gửi lên):
  - Nhận tại cửa hàng – miễn phí
  - Giao hàng tiêu chuẩn (Giao Hàng Tiết Kiệm) – 20.000đ
  - Giao hàng nhanh (Giao Hàng Nhanh) – 35.000đ
- Tổng tiền đơn hàng = Tạm tính − Giảm giá + Phí vận chuyển, cập nhật trực tiếp bằng JS khi đổi phương thức.
- Hóa đơn (khách hàng + quản lý) hiển thị đầy đủ: đơn vị vận chuyển, phí ship, tách riêng từng dòng.
- Danh sách phương thức giao hàng định nghĩa tại `util/ShippingUtil.java`, muốn thêm/sửa đơn vị vận chuyển chỉ cần sửa 1 chỗ này.
- DB: bảng `bills` thêm cột `shipping_method`, `shipping_fee`.

### Biểu đồ doanh thu trực quan
Dashboard (`/manager/dashboard`, chỉ Admin) dùng Chart.js (CDN) thêm:
- Biểu đồ cột: doanh thu 7 ngày gần nhất
- Biểu đồ tròn (doughnut): tỷ trọng số lượng bán của Top 5 sản phẩm bán chạy
